package stepdefs;


import static io.restassured.RestAssured.given;
import io.restassured.RestAssured;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import org.junit.Assert;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.config.SSLConfig;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import config.constants;


public class APITestDefs {

	private Response response;
	private String url;
	
	
	@Given("the apis are up and running for \"(.*)\"")
	public void the_apis_are_up_and_running(String url)throws Throwable{
		
		this.url = url;
		
	  response = given().config(RestAssured.config().sslConfig( new SSLConfig().relaxedHTTPSValidation())).when().get(url);
		
	   Assert.assertEquals(404, response.getStatusCode());
	}


	
	@When("a user performs and get a request to \"(.*)\"")
	public void a_user_performs_get_a_request(String ID)throws Throwable{
		url = url + ID;
	}

	@And("and perform the request")
	public void and_perform_the_request()throws Throwable{
		System.out.println("URL " + this.url);
		
			response = given().config(RestAssured.config().sslConfig( new SSLConfig().relaxedHTTPSValidation())).when().get(url);
			
	}
	
	
	@Then("the status code is (\\d+)")
	public void verify_status_code(int statusCode)throws Throwable{
		response.then().statusCode(statusCode);
		Assert.assertEquals(statusCode, response.getStatusCode());	
		
	}
	
	@And("I should see the json response for \"([^\"]*)\" and compare with the DB value \"([^\"]*)\" and \"([^\"]*)\"$")
	public void I_should_see_the_json_response_for_and_compare_with_the_DB_value_and(String key,String DBName, String Query) throws Throwable{
		
		      String DBValue = null;
		      System.out.println("response: " + response.prettyPrint());
		      
		      Class.forName(constants.JDBCDriver);	
			  Connection conn = DriverManager.getConnection("jdbc:" + constants.ServerName + ";user=" + constants.DBUser +";password=" + constants.DBPWD + ";database=" +DBName);
			  Statement sta = conn.createStatement();  			 			  
			  ResultSet rs = sta.executeQuery(Query);
			  while (rs.next()) {
				 DBValue =rs.getString(1);
			  }
			  String json = response.asString();
			  JsonPath jp = new JsonPath(json);
			  Assert.assertEquals(DBValue, jp.get(key));
				
}
}