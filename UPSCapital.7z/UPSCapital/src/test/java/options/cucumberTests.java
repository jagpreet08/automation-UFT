package options;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		plugin = {"html:target/cucumber-pretty", "json:target/cucumber.json" },
		features = {"src/test/resources/features/ApiTest.feature"},
		glue = {"stepdefs"}
		   )

public class cucumberTests {}