package config;

public class constants {
	
	public static final String JDBCDriver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	public static final String ServerName = "sqlserver://SVRT00008949.TUS.AMS1907.COM";
	public static final String DBUser = "qateam49" ;
	public static final String DBPWD = "Test1ngTe@m";

}
