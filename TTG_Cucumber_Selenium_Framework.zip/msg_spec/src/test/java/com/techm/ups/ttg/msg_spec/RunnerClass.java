package com.techm.ups.ttg.msg_spec;

import org.junit.runner.RunWith;

import com.techm.ups.ttg.reports.RerunningCucumber;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;



@RunWith(Cucumber.class)
@CucumberOptions
(
		monochrome	=	true,
		
		strict		=	true,
		
		plugin		=	{
							"rerun:target/rerun.txt"
						},
		
		features =	{
						"classpath:features"
					},
					
		glue =		{
						"classpath:com.techm.ups.ttg.glue"
					},
					
		format = 	{ 
						"pretty", "html:target/site/cucumber-pretty", 
						"json:target/cucumber.json"
					},
					
		tags =		{	
							//"@TestCase_EndtoEnd_Case1,@TestCase_EndtoEnd_Case2"
						"@TestCase_EndtoEnd_Case0,@TestCase_EndtoEnd_Case1,@TestCase_EndtoEnd_Case2,@TestCase_EndtoEnd_Case3"
						//"@TestCase_EndtoEnd_Case3"
					}



)
public class RunnerClass 
{
	

}
