package com.techm.ups.ttg.msg_spec;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
    monochrome = true,
    features = "@target/rerun.txt", 
    format = {"pretty", "html:target/rerun/site/cucumber-pretty",
            "json:target/cucumber.json"}
  )
public class FailedRunnerClass {

}
