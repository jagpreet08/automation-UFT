package com.techm.ups.ttg.glue;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;
import gherkin.formatter.model.Feature;
import gherkin.formatter.model.Step;
import groovy.lang.Lazy;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import junit.framework.Assert;

import org.joda.time.DateTime;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;


import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import com.github.mkolisnyk.cucumber.assertions.LazyAssert;

import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import com.google.common.collect.Lists; 
import com.techm.ups.ttg.config.GBS_MSG;
import com.techm.ups.ttg.utils.ExcelWriter;
import com.techm.ups.ttg.utils.Wrapper;

public class BrokerageDataManagement   {
	
	public static Properties prop = new Properties();
	OutputStream output = null;
	
	
		DateFormat dateFormat = new SimpleDateFormat("dd_mm_yyyy_hh_mm");
		Date date = new Date();

		String dateformates=dateFormat.format(date);

		//String FILENAME = "D:\\Chandrakanth\\TTG\\BDM_Search_Shipment_"+dateformates+".properties";
		String FILENAME = System.getProperty("user.dir")+"/target/BDM_Search_Shipment_"+dateformates+".properties";
		
	public  static List<HashMap<String,String>> customer_details_values;
	/*public class Customer{


		public String cmfAccountNumber;
		public String customerName;

		
		public Customer(String cmfAccountNumber,String customerName)
		{
			this.cmfAccountNumber=cmfAccountNumber;
			this.customerName=customerName;
		}
	}*/

	public Wrapper mywrapper= new Wrapper();
	HashMap<String,String> bdm_fields_values=new HashMap<String,String>();
	private int count;

	@Then("^Click on the Continue to this website$")
	public void click_on_continue_to_this_website()
	{
		mywrapper.javascriptEx_Click(BaseClass.driver,BaseClass.OBJECT.getProperty("bdm_continue_tothis_website_link"));
	}

	@Given("^enter valid credentials in the BDM Application$")
	public void enter_valid_credentails() throws InterruptedException
	{
		mywrapper.hardWait(5000);
		System.out.println("Enter the Valid Credentials");
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("bdm_username_textbox"),BaseClass.datamap.get(BaseClass.tempindex).get("username"));
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("bdm_password_textbox"),BaseClass.datamap.get(BaseClass.tempindex).get("password"));
		try {  
            byte[] screenshot = ((TakesScreenshot) BaseClass.driver).getScreenshotAs(OutputType.BYTES);  
            System.out.println(BaseClass.scenario.getName());
            BaseClass.scenario.embed(screenshot, "image/png");  
          
        } catch (WebDriverException wde) {  
            System.err.println(wde.getMessage());  
        } catch (ClassCastException cce) {  
            cce.printStackTrace();  
        }  
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("bdm_sign_button"));
		System.out.println("Clicked on the Login button sucessfully");
	}
	
	
	@Then("^Navigate from Shipment menu to Shipment submenu$")
	public void navigate_from_menu_to_submenu() throws InterruptedException
	{
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("bdm_menu_shipment_link"));
		mywrapper.hardWait(5000);
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("bdm_shipment_submenu_shipment_link"));
		
		BaseClass.scenario.write("Navigated Shipment menu to Shipment Submenu");
		
	}


	@Then("^Navigate from Customer menu to Customer submenu$")
	public void navigate_from_menu_to_submenu1() throws InterruptedException
	{
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("bdm_customer_menu"));
		mywrapper.hardWait(5000);
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("bdm_customer_menu_customer_submenu_link"));
	}


	@Then("^search the existing shipment and click on the searched shipment number$")
	public void searchShipment() throws InterruptedException
	{
		 DateFormat dateFormat1 = new SimpleDateFormat("MM/dd/yyyy");
		 Date startdate = new DateTime().minusMonths(1).toDate();
		 Date enddate = new DateTime().toDate();
		 String startdateformat=dateFormat1.format(startdate);
		 String enddateformat=dateFormat1.format(enddate);
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("bdm_shipment_search_button"));
		mywrapper.hardWait(5000);
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("bdm_searchshipment_userid_textbox"),"bdm");
		mywrapper.javaScriptExec_SendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("bdm_searchshipment_startdate"),startdateformat);
		mywrapper.javaScriptExec_SendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("bdm_searchshipment_enddate"),enddateformat);
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("bdm_searchshipment_userid_textbox"));
		mywrapper.hardWait(2000);
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("bdm_searchshipment_search_button"));
		mywrapper.hardWait(5000);
		/*mywrapper.waitForElementClickable(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_searchshipmentnumber_radiobutton"), 60, 5);*/
		/*mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("bdm_searchshipmentnumber_radiobutton"));
		mywrapper.hardWait(5000);*/
	}


	@Then("^store all the properties present in the Shipment screen1$")
	public void storeValues()
	{


		System.out.println("Station Code Value \t:\t"+mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_stationcode_dropdown")));
		System.out.println("IOR Account Value \t:\t"+mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ioraccount_textbox")));
		System.out.println("Entry Port Value \t:\t"+mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_entryport_textbox")));
		System.out.println("Estimated Arrival Date Value \t:\t"+mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_estarrivaldate_textbox")));
		System.out.println("Cer to for grin Value \t:\t"+mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_estarrivaltime_textbox")));
		System.out.println("Entry Port Value \t:\t"+mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_certoforgind_dropdown")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_linerelind_checkbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_actarrivaldate_textbox")));
		System.out.println(mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_servicelevel_dropdown")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_importdate_textbox")));
		System.out.println(mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_importcountry_dropdown")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_personincharge_textbox")));
		System.out.println(mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_reconcillationtype_dropdown")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_reconcillation_checkbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipmentnumber_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_brokerrefnumber")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_userid_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipmentdate_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipmentstatus_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_importorshipment_checkbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shippername_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_address_textarea")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_department_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_entrylevelmid_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_contactname_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_city_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_fax_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_telephone_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_email_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_country_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_state_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_postalcode_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_name_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_address_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_department_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_taxid_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_contactname_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_city_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_telephone_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_state_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_fax_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_country_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_email_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_postalcode_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_checkbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_address_textarea")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_accountnumber_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_department_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_taxid_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_contactname_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_telephone_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_city_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_fax_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_state_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_email_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_country_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_postalcode_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_checkbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_address_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_accountnumber_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_department_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_taxid_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_contactname_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_telephone_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_city_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_fax_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_state_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_emailid_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_country_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_postalcode_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_name_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_address_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_department_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_division_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_contactname_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_city_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_telephone_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_state_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_fax_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_postalcode_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_email_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_country_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_name_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_address_textarea")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_department")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_entrylevelmid_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_contactname_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_city_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_telephone_exporter")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_telephone_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_state_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_fax_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_postalcode_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_email_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_country_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_address_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_department_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_entrylevel_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_contactname_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_city_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_telephone_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_state_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_fax_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_postalcode_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_email_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_country_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_origincountry_dropdown")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_portoflanding_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_exportcountry_dropdown")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_exportport_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_lastforeignport_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_portoflanding_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_exportdate_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_inbondcarrier_textbox")));
		System.out.println(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_inboundportofdistination_textbox")));



	}




	@Then("^store all the properties present in the Shipment screen$")
	public void storeBDMintoPropertiesFiles() throws InterruptedException, IOException
	{
		//BaseClass.newtable_BDMValues();
		BaseClass.newtable();
		mywrapper.hardWait(5000);
		try

		{
			mywrapper.waitForElementVisible(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_department_textbox"));
		}
		catch(StaleElementReferenceException e){
			mywrapper.hardWait(5000);
		}
		catch(ElementNotVisibleException e)
		{
			mywrapper.hardWait(5000);
			new WebDriverWait(BaseClass.driver, 30).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(BaseClass.OBJECT.getProperty("bdm_shipment_shipper_department_textbox"))));
		}
		try{
			String ExcelFileName = "D:\\Chandrakanth\\TTG\\BDM_Search_Shipment_"+dateformates+".xlsx";
			output = new FileOutputStream(FILENAME);
			ExcelWriter.createWorkbook(ExcelFileName);
			ExcelWriter writer= new ExcelWriter(ExcelFileName);
			String mysheetname="BDM_"+dateformates;
			writer.addSheet(mysheetname);

			/*
			bdm_fields_values.put("bdm_shipment_stationcode_dropdown",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_stationcode_dropdown")));
			bdm_fields_values.put("bdm_shipment_ioraccount_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ioraccount_textbox")));
			bdm_fields_values.put("bdm_shipment_entryport_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_entryport_textbox")));
			bdm_fields_values.put("bdm_shipment_estarrivaldate_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_estarrivaldate_textbox")));
			bdm_fields_values.put("bdm_shipment_estarrivaltime_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_estarrivaltime_textbox")));
			bdm_fields_values.put("bdm_shipment_certoforgind_dropdown",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_certoforgind_dropdown")));
			bdm_fields_values.put("bdm_shipment_linerelind_checkbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_linerelind_checkbox")));
			bdm_fields_values.put("bdm_shipment_actarrivaldate_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_actarrivaldate_textbox")));
			bdm_fields_values.put("bdm_shipment_servicelevel_dropdown",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_servicelevel_dropdown")));
			bdm_fields_values.put("bdm_shipment_importdate_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_importdate_textbox")));
			bdm_fields_values.put("bdm_shipment_importcountry_dropdown",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_importcountry_dropdown")));
			bdm_fields_values.put("bdm_shipment_personincharge_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_personincharge_textbox")));
			bdm_fields_values.put("bdm_shipment_reconcillationtype_dropdown",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_reconcillationtype_dropdown")));
			bdm_fields_values.put("bdm_shipment_reconcillation_checkbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_reconcillation_checkbox")));
			bdm_fields_values.put("bdm_shipment_shipmentnumber_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipmentnumber_textbox")));
			bdm_fields_values.put("bdm_shipment_brokerrefnumber",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_brokerrefnumber")));
			bdm_fields_values.put("bdm_shipment_userid_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_userid_textbox")));
			bdm_fields_values.put("bdm_shipment_shipmentdate_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipmentdate_textbox")));
			bdm_fields_values.put("bdm_shipment_shipmentstatus_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipmentstatus_textbox")));
			bdm_fields_values.put("bdm_shipment_importorshipment_checkbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_importorshipment_checkbox")));
			bdm_fields_values.put("bdm_shipment_shippername_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shippername_textbox")));
			bdm_fields_values.put("bdm_shipment_address_textarea",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_address_textarea")));
			bdm_fields_values.put("bdm_shipment_shipper_department_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_department_textbox")));
			bdm_fields_values.put("bdm_shipment_shipper_entrylevelmid_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_entrylevelmid_textbox")));
			bdm_fields_values.put("bdm_shipment_shipper_contactname_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_contactname_textbox")));
			bdm_fields_values.put("bdm_shipment_shipper_city_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_city_textbox")));
			bdm_fields_values.put("bdm_shipment_shipper_fax_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_fax_textbox")));
			bdm_fields_values.put("bdm_shipment_shipper_telephone_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_telephone_textbox")));
			bdm_fields_values.put("bdm_shipment_shipper_email_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_email_textbox")));
			bdm_fields_values.put("bdm_shipment_shipper_country_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_country_textbox")));
			bdm_fields_values.put("bdm_shipment_shipper_state_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_state_textbox")));
			bdm_fields_values.put("bdm_shipment_shipper_postalcode_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_postalcode_textbox")));
			bdm_fields_values.put("bdm_shipment_ior_name_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_name_textbox")));
			bdm_fields_values.put("bdm_shipment_ior_address_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_address_textbox")));
			bdm_fields_values.put("bdm_shipment_ior_department_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_department_textbox")));
			bdm_fields_values.put("bdm_shipment_ior_taxid_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_taxid_textbox")));
			bdm_fields_values.put("bdm_shipment_ior_contactname_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_contactname_textbox")));
			bdm_fields_values.put("bdm_shipment_ior_city_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_city_textbox")));
			bdm_fields_values.put("bdm_shipment_ior_telephone_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_telephone_textbox")));
			bdm_fields_values.put("bdm_shipment_ior_state_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_state_textbox")));
			bdm_fields_values.put("bdm_shipment_ior_fax_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_fax_textbox")));



			bdm_fields_values.put("bdm_shipment_ior_country_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_country_textbox")));
			bdm_fields_values.put("bdm_shipment_ior_email_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_email_textbox")));
			bdm_fields_values.put("bdm_shipment_ior_postalcode_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_postalcode_textbox")));
			bdm_fields_values.put("bdm_shipment_consignee_checkbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_checkbox")));
			bdm_fields_values.put("bdm_shipment_consignee_address_textarea",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_address_textarea")));
			bdm_fields_values.put("bdm_shipment_consignee_accountnumber_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_accountnumber_textbox")));
			bdm_fields_values.put("bdm_shipment_consignee_department_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_department_textbox")));
			bdm_fields_values.put("bdm_shipment_consignee_taxid_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_taxid_textbox")));
			bdm_fields_values.put("bdm_shipment_consignee_contactname_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_contactname_textbox")));
			bdm_fields_values.put("bdm_shipment_consignee_telephone_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_telephone_textbox")));
			bdm_fields_values.put("bdm_shipment_consignee_city_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_city_textbox")));
			bdm_fields_values.put("bdm_shipment_consignee_fax_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_fax_textbox")));
			bdm_fields_values.put("bdm_shipment_consignee_state_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_state_textbox")));
			bdm_fields_values.put("bdm_shipment_consignee_email_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_email_textbox")));
			bdm_fields_values.put("bdm_shipment_consignee_country_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_country_textbox")));
			bdm_fields_values.put("bdm_shipment_consignee_postalcode_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_postalcode_textbox")));
			bdm_fields_values.put("bdm_shipment_payer_checkbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_checkbox")));
			bdm_fields_values.put("bdm_shipment_payer_address_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_address_textbox")));
			bdm_fields_values.put("bdm_shipment_payer_accountnumber_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_accountnumber_textbox")));
			bdm_fields_values.put("bdm_shipment_payer_department_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_department_textbox")));
			bdm_fields_values.put("bdm_shipment_payer_taxid_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_taxid_textbox")));
			bdm_fields_values.put("bdm_shipment_payer_contactname_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_contactname_textbox")));
			bdm_fields_values.put("bdm_shipment_payer_telephone_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_telephone_textbox")));
			bdm_fields_values.put("bdm_shipment_payer_city_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_city_textbox")));
			bdm_fields_values.put("bdm_shipment_payer_fax_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_fax_textbox")));
			bdm_fields_values.put("bdm_shipment_payer_state_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_state_textbox")));
			bdm_fields_values.put("bdm_shipment_payer_emailid_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_emailid_textbox")));
			bdm_fields_values.put("bdm_shipment_payer_country_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_country_textbox")));
			bdm_fields_values.put("bdm_shipment_payer_postalcode_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_postalcode_textbox")));
			bdm_fields_values.put("bdm_shipment_shipto_name_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_name_textbox")));
			bdm_fields_values.put("bdm_shipment_shipto_address_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_address_textbox")));
			bdm_fields_values.put("bdm_shipment_shipto_department_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_department_textbox")));
			bdm_fields_values.put("bdm_shipment_shipto_division_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_division_textbox")));
			bdm_fields_values.put("bdm_shipment_shipto_contactname_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_contactname_textbox")));
			bdm_fields_values.put("bdm_shipment_shipto_city_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_city_textbox")));
			bdm_fields_values.put("bdm_shipment_shipto_telephone_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_telephone_textbox")));
			bdm_fields_values.put("bdm_shipment_shipto_state_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_state_textbox")));
			bdm_fields_values.put("bdm_shipment_shipto_fax_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_fax_textbox")));
			bdm_fields_values.put("bdm_shipment_shipto_postalcode_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_postalcode_textbox")));
			bdm_fields_values.put("bdm_shipment_shipto_email_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_email_textbox")));
			bdm_fields_values.put("bdm_shipment_shipto_country_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_country_textbox")));
			bdm_fields_values.put("bdm_shipment_exporter_name_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_name_textbox")));
			bdm_fields_values.put("bdm_shipment_exporter_address_textarea",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_address_textarea")));
			bdm_fields_values.put("bdm_shipment_exporter_department",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_department")));
			bdm_fields_values.put("bdm_shipment_exporter_entrylevelmid_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_entrylevelmid_textbox")));
			bdm_fields_values.put("bdm_shipment_exporter_contactname_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_contactname_textbox")));
			bdm_fields_values.put("bdm_shipment_exporter_city_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_city_textbox")));
			bdm_fields_values.put("bdm_shipment_exporter_telephone_exporter",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_telephone_exporter")));
			bdm_fields_values.put("bdm_shipment_exporter_telephone_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_telephone_textbox")));
			bdm_fields_values.put("bdm_shipment_exporter_state_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_state_textbox")));
			bdm_fields_values.put("bdm_shipment_exporter_fax_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_fax_textbox")));
			bdm_fields_values.put("bdm_shipment_exporter_postalcode_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_postalcode_textbox")));
			bdm_fields_values.put("bdm_shipment_exporter_email_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_email_textbox")));
			bdm_fields_values.put("bdm_shipment_exporter_country_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_country_textbox")));
			bdm_fields_values.put("bdm_shipment_submitter_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_textbox")));
			bdm_fields_values.put("bdm_shipment_submitter_address_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_address_textbox")));
			bdm_fields_values.put("bdm_shipment_submitter_department_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_department_textbox")));
			bdm_fields_values.put("bdm_shipment_submitter_entrylevel_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_entrylevel_textbox")));
			bdm_fields_values.put("bdm_shipment_submitter_contactname_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_contactname_textbox")));
			bdm_fields_values.put("bdm_shipment_submitter_city_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_city_textbox")));
			bdm_fields_values.put("bdm_shipment_submitter_telephone_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_telephone_textbox")));
			bdm_fields_values.put("bdm_shipment_submitter_state_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_state_textbox")));
			bdm_fields_values.put("bdm_shipment_submitter_fax_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_fax_textbox")));
			bdm_fields_values.put("bdm_shipment_submitter_postalcode_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_postalcode_textbox")));
			bdm_fields_values.put("bdm_shipment_submitter_email_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_email_textbox")));
			bdm_fields_values.put("bdm_shipment_submitter_country_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_country_textbox")));
			bdm_fields_values.put("bdm_shipment_port_origincountry_dropdown",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_origincountry_dropdown")));
			bdm_fields_values.put("bdm_shipment_port_portoflanding_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_portoflanding_textbox")));
			bdm_fields_values.put("bdm_shipment_port_exportcountry_dropdown",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_exportcountry_dropdown")));
			bdm_fields_values.put("bdm_shipment_port_exportport_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_exportport_textbox")));
			bdm_fields_values.put("bdm_shipment_port_lastforeignport_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_lastforeignport_textbox")));
			bdm_fields_values.put("bdm_shipment_port_portoflanding_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_portoflanding_textbox")));
			bdm_fields_values.put("bdm_shipment_port_exportdate_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_exportdate_textbox")));
			bdm_fields_values.put("bdm_shipment_port_inbondcarrier_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_inbondcarrier_textbox")));
			bdm_fields_values.put("bdm_shipment_port_inboundportofdistination_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_inboundportofdistination_textbox")));



			 */


			/*
			 * 
			 * 
			 * 
			 * 
			 * 
			 * *******/








			prop.setProperty("bdm_shipment_stationcode_dropdown",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_stationcode_dropdown")));
			prop.setProperty("bdm_shipment_ioraccount_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ioraccount_textbox")));
			prop.setProperty("bdm_shipment_entryport_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_entryport_textbox")));
			prop.setProperty("bdm_shipment_estarrivaldate_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_estarrivaldate_textbox")));
			prop.setProperty("bdm_shipment_estarrivaltime_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_estarrivaltime_textbox")));
			prop.setProperty("bdm_shipment_certoforgind_dropdown",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_certoforgind_dropdown")));
			prop.setProperty("bdm_shipment_linerelind_checkbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_linerelind_checkbox")));
			prop.setProperty("bdm_shipment_actarrivaldate_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_actarrivaldate_textbox")));
			prop.setProperty("bdm_shipment_servicelevel_dropdown",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_servicelevel_dropdown")));
			prop.setProperty("bdm_shipment_importdate_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_importdate_textbox")));
			prop.setProperty("bdm_shipment_importcountry_dropdown",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_importcountry_dropdown")));
			prop.setProperty("bdm_shipment_personincharge_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_personincharge_textbox")));
			prop.setProperty("bdm_shipment_reconcillationtype_dropdown",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_reconcillationtype_dropdown")));
			prop.setProperty("bdm_shipment_reconcillation_checkbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_reconcillation_checkbox")));
			prop.setProperty("bdm_shipment_shipmentnumber_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipmentnumber_textbox")));
			prop.setProperty("bdm_shipment_brokerrefnumber",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_brokerrefnumber")));
			prop.setProperty("bdm_shipment_userid_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_userid_textbox")));
			prop.setProperty("bdm_shipment_shipmentdate_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipmentdate_textbox")));
			prop.setProperty("bdm_shipment_shipmentstatus_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipmentstatus_textbox")));
			prop.setProperty("bdm_shipment_importorshipment_checkbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_importorshipment_checkbox")));
			prop.setProperty("bdm_shipment_shippername_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shippername_textbox")));
			prop.setProperty("bdm_shipment_address_textarea",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_address_textarea")));
			prop.setProperty("bdm_shipment_shipper_department_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_department_textbox")));
			prop.setProperty("bdm_shipment_shipper_entrylevelmid_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_entrylevelmid_textbox")));
			prop.setProperty("bdm_shipment_shipper_contactname_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_contactname_textbox")));
			prop.setProperty("bdm_shipment_shipper_city_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_city_textbox")));
			prop.setProperty("bdm_shipment_shipper_fax_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_fax_textbox")));
			prop.setProperty("bdm_shipment_shipper_telephone_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_telephone_textbox")));
			prop.setProperty("bdm_shipment_shipper_email_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_email_textbox")));
			prop.setProperty("bdm_shipment_shipper_country_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_country_textbox")));
			prop.setProperty("bdm_shipment_shipper_state_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_state_textbox")));
			prop.setProperty("bdm_shipment_shipper_postalcode_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_postalcode_textbox")));
			prop.setProperty("bdm_shipment_ior_name_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_name_textbox")));
			prop.setProperty("bdm_shipment_ior_address_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_address_textbox")));
			prop.setProperty("bdm_shipment_ior_department_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_department_textbox")));
			prop.setProperty("bdm_shipment_ior_taxid_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_taxid_textbox")));
			prop.setProperty("bdm_shipment_ior_contactname_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_contactname_textbox")));
			prop.setProperty("bdm_shipment_ior_city_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_city_textbox")));
			prop.setProperty("bdm_shipment_ior_telephone_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_telephone_textbox")));
			prop.setProperty("bdm_shipment_ior_state_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_state_textbox")));
			prop.setProperty("bdm_shipment_ior_fax_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_fax_textbox")));
			prop.setProperty("bdm_shipment_ior_country_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_country_textbox")));
			prop.setProperty("bdm_shipment_ior_email_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_email_textbox")));
			prop.setProperty("bdm_shipment_ior_postalcode_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_postalcode_textbox")));
			prop.setProperty("bdm_shipment_consignee_checkbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_checkbox")));
			prop.setProperty("bdm_shipment_consignee_address_textarea",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_address_textarea")));
			prop.setProperty("bdm_shipment_consignee_accountnumber_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_accountnumber_textbox")));
			prop.setProperty("bdm_shipment_consignee_department_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_department_textbox")));
			prop.setProperty("bdm_shipment_consignee_taxid_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_taxid_textbox")));
			prop.setProperty("bdm_shipment_consignee_contactname_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_contactname_textbox")));
			prop.setProperty("bdm_shipment_consignee_telephone_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_telephone_textbox")));
			prop.setProperty("bdm_shipment_consignee_city_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_city_textbox")));
			prop.setProperty("bdm_shipment_consignee_fax_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_fax_textbox")));
			prop.setProperty("bdm_shipment_consignee_state_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_state_textbox")));
			prop.setProperty("bdm_shipment_consignee_email_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_email_textbox")));
			prop.setProperty("bdm_shipment_consignee_country_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_country_textbox")));
			prop.setProperty("bdm_shipment_consignee_postalcode_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_postalcode_textbox")));
			prop.setProperty("bdm_shipment_payer_checkbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_checkbox")));
			prop.setProperty("bdm_shipment_payer_address_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_address_textbox")));
			prop.setProperty("bdm_shipment_payer_accountnumber_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_accountnumber_textbox")));
			prop.setProperty("bdm_shipment_payer_department_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_department_textbox")));
			prop.setProperty("bdm_shipment_payer_taxid_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_taxid_textbox")));
			prop.setProperty("bdm_shipment_payer_contactname_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_contactname_textbox")));
			prop.setProperty("bdm_shipment_payer_telephone_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_telephone_textbox")));
			prop.setProperty("bdm_shipment_payer_city_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_city_textbox")));
			prop.setProperty("bdm_shipment_payer_fax_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_fax_textbox")));
			prop.setProperty("bdm_shipment_payer_state_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_state_textbox")));
			prop.setProperty("bdm_shipment_payer_emailid_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_emailid_textbox")));
			prop.setProperty("bdm_shipment_payer_country_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_country_textbox")));
			prop.setProperty("bdm_shipment_payer_postalcode_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_postalcode_textbox")));
			prop.setProperty("bdm_shipment_shipto_name_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_name_textbox")));
			prop.setProperty("bdm_shipment_shipto_address_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_address_textbox")));
			prop.setProperty("bdm_shipment_shipto_department_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_department_textbox")));
			prop.setProperty("bdm_shipment_shipto_division_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_division_textbox")));
			prop.setProperty("bdm_shipment_shipto_contactname_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_contactname_textbox")));
			prop.setProperty("bdm_shipment_shipto_city_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_city_textbox")));
			prop.setProperty("bdm_shipment_shipto_telephone_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_telephone_textbox")));
			prop.setProperty("bdm_shipment_shipto_state_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_state_textbox")));
			prop.setProperty("bdm_shipment_shipto_fax_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_fax_textbox")));
			prop.setProperty("bdm_shipment_shipto_postalcode_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_postalcode_textbox")));
			prop.setProperty("bdm_shipment_shipto_email_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_email_textbox")));
			prop.setProperty("bdm_shipment_shipto_country_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_country_textbox")));
			prop.setProperty("bdm_shipment_exporter_name_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_name_textbox")));
			prop.setProperty("bdm_shipment_exporter_address_textarea",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_address_textarea")));
			prop.setProperty("bdm_shipment_exporter_department",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_department")));
			prop.setProperty("bdm_shipment_exporter_entrylevelmid_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_entrylevelmid_textbox")));
			prop.setProperty("bdm_shipment_exporter_contactname_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_contactname_textbox")));
			prop.setProperty("bdm_shipment_exporter_city_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_city_textbox")));
			prop.setProperty("bdm_shipment_exporter_telephone_exporter",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_telephone_exporter")));
			prop.setProperty("bdm_shipment_exporter_telephone_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_telephone_textbox")));
			prop.setProperty("bdm_shipment_exporter_state_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_state_textbox")));
			prop.setProperty("bdm_shipment_exporter_fax_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_fax_textbox")));
			prop.setProperty("bdm_shipment_exporter_postalcode_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_postalcode_textbox")));
			prop.setProperty("bdm_shipment_exporter_email_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_email_textbox")));
			prop.setProperty("bdm_shipment_exporter_country_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_country_textbox")));
			prop.setProperty("bdm_shipment_submitter_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_textbox")));
			prop.setProperty("bdm_shipment_submitter_address_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_address_textbox")));
			prop.setProperty("bdm_shipment_submitter_department_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_department_textbox")));
			prop.setProperty("bdm_shipment_submitter_entrylevel_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_entrylevel_textbox")));
			prop.setProperty("bdm_shipment_submitter_contactname_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_contactname_textbox")));
			prop.setProperty("bdm_shipment_submitter_city_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_city_textbox")));
			prop.setProperty("bdm_shipment_submitter_telephone_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_telephone_textbox")));
			prop.setProperty("bdm_shipment_submitter_state_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_state_textbox")));
			prop.setProperty("bdm_shipment_submitter_fax_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_fax_textbox")));
			prop.setProperty("bdm_shipment_submitter_postalcode_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_postalcode_textbox")));
			prop.setProperty("bdm_shipment_submitter_email_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_email_textbox")));
			prop.setProperty("bdm_shipment_submitter_country_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_country_textbox")));
			prop.setProperty("bdm_shipment_port_origincountry_dropdown",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_origincountry_dropdown")));
			prop.setProperty("bdm_shipment_port_portoflanding_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_portoflanding_textbox")));
			prop.setProperty("bdm_shipment_port_exportcountry_dropdown",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_exportcountry_dropdown")));
			prop.setProperty("bdm_shipment_port_exportport_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_exportport_textbox")));
			prop.setProperty("bdm_shipment_port_lastforeignport_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_lastforeignport_textbox")));
			prop.setProperty("bdm_shipment_port_portoflanding_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_portoflanding_textbox")));
			prop.setProperty("bdm_shipment_port_exportdate_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_exportdate_textbox")));
			prop.setProperty("bdm_shipment_port_inbondcarrier_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_inbondcarrier_textbox")));
			prop.setProperty("bdm_shipment_port_inboundportofdistination_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_inboundportofdistination_textbox")));


			prop.setProperty("bdm_shipment_shipmentdescription_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipmentdescription_textbox")));
			prop.setProperty("bdm_shipment_shipmentvalue_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipmentvalue_textbox")));
			prop.setProperty("bdm_shipment_shipmentvalue_gdropdown",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipmentvalue_gdropdown")));
			prop.setProperty("bdm_shipment_firmcode_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_firmcode_textbox")));
			prop.setProperty("bdm_shipment_totalqty_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_totalqty_textbox")));
			prop.setProperty("bdm_shipment_quntity_dropdown",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_quntity_dropdown")));
			prop.setProperty("bdm_shipment_totalgrossweight_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_totalgrossweight_textbox")));
			prop.setProperty("bdm_shipment_totalgrossweight_dropdown",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_totalgrossweight_dropdown")));
			prop.setProperty("bdm_shipment_totalgrossweight_stateofdes_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_totalgrossweight_stateofdes_textbox")));
			prop.setProperty("bdm_shipment_shipmentinstruction_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipmentinstruction_textbox")));
			prop.setProperty("bdm_shipment_modeoftransport_dropdown",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_modeoftransport_dropdown")));
			prop.setProperty("bdm_shipment_totalnetweight_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_totalnetweight_textbox")));
			prop.setProperty("bdm_shipment_totalnetweight_dropdown",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_totalnetweight_dropdown")));
			prop.setProperty("bdm_shipment_freightcharge_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_freightcharge_textbox")));
			prop.setProperty("bdm_shipment_freightcharge_dropdown",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_freightcharge_dropdown")));
			prop.setProperty("bdm_shipment_insurancecharge_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_insurancecharge_textbox")));
			prop.setProperty("bdm_shipment_insurancecharge_dropdown",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_insurancecharge_dropdown")));
			prop.setProperty("bdm_shipment_date",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_date")));
			prop.setProperty("bdm_shipment_entrytype_dropdown",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_entrytype_dropdown")));
			prop.setProperty("bdm_shipment_voyage_txtbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_voyage_txtbox")));
			prop.setProperty("bdm_shipment_vesselname_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_vesselname_textbox")));
			prop.setProperty("bdm_shipment_importerref_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_importerref_textbox")));
			prop.setProperty("bdm_shipment_marknumber_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_marknumber_textbox")));
			prop.setProperty("bdm_shipment_customerrefernce_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_customerrefernce_textbox")));
			prop.setProperty("bdm_shipment_manifestdate_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_manifestdate_textbox")));
			prop.setProperty("bdm_shipment_govtcontract_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_govtcontract_textbox")));
			prop.setProperty("bdm_shipment_railcarnumber_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_railcarnumber_textbox")));
			prop.setProperty("bdm_shipment_masterpro_textbox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_masterpro_textbox")));

			/*	
			if(mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_outboundidentifer_dropdown"))!=null)
			{
				prop.setProperty("bdm_shipment_outboundidentifer_dropdown",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_outboundidentifer_dropdown")));
			}

			else
			{
				prop.setProperty("bdm_shipment_outboundidentifer_dropdown","");
			}*/


			prop.setProperty("bdm_shipment_lastfreed_textbpox",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_lastfreed_textbpox")));
			prop.store(output, null);

		} 
		catch (IOException io)
		{
			io.printStackTrace();
		}
		finally
		{
			if (output != null) 
			{
				try 
				{
					output.close();
				} 
				catch (IOException e) 
				{
					e.printStackTrace();
				}
			}

		}
		
		
		
		/* Set<String> keys = prop.stringPropertyNames();
		    for (String key : keys) {
		    	BaseClass.addrowBDMValues(key,  prop.getProperty(key));
		      System.out.println(key + " : " + prop.getProperty(key));
		    }*/
	}

	@Then("^Get the number of radiobuttons in the ShipmentTable$")
	public void getShipmentRadioButtons()
	{
		List<WebElement> shipmentradiobutton=BaseClass.driver.findElements(By.xpath("//input[@type='radio' and @name='item.ShipmentId']"));
		System.out.println(shipmentradiobutton.size());
		mywrapper.MoveToElementAndClick(BaseClass.driver, shipmentradiobutton.get(1));
		//	System.out.println(shipmentradiobutton.size());

	}

	@Then("^Validate the LastFreeDate field$")
    public void Validate_the_LastFreeDate_field() throws InterruptedException
    {
                    if(BaseClass.driver.findElement(By.id("LastFreeDate"))!= null){
                                    mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("bdm_shipment_field_lastfreedate"),"10/06/2017");
                                    mywrapper.hardWait(5000);
                                    System.out.println("LastFreeDate Field is Present and entering the date in the MM/DD/YYYY format");
                                    }else{
                                    System.out.println("LastFreeDate Field is Absent");
                                    }
                    }
    
    
    @Then("^Logout from the application$")
    public void Logout_from_the_application() throws InterruptedException
    {
                    mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("bdm_LogOff"));
                    mywrapper.hardWait(5000);
    }
    


	@Then("^search the existing customer and click on the edit action test$")
	public void search_existing_customer_click_edit1() throws InterruptedException
	{

	

		//customer_search=	table.asList(Customer.class);


		/*for(int j=0;j<customer_search.size();j++)
		{*/
			/*System.out.println(customer_search.get(j).cmfAccountNumber.toString());
			System.out.println(customer_search.get(j).customerName.toString());*/
		mywrapper.hardWait(5000);
			mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("bdm_searchcustomer_cmfaccountnumber_textbox"),"535359053");
			//mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("bdm_searchcustomer_customer_textbox"),customer_search.get(j).cmfAccountNumber.toString());
			mywrapper.javascriptEx_Click(BaseClass.driver,BaseClass.OBJECT.getProperty("bdm_searchcustomer_search_button"));
			System.out.println("Clicked on the Login button sucessfully");

			mywrapper.hardWait(5000);
			List<WebElement> elements= BaseClass.driver.findElements(By.xpath("//table[@id='tblcustomerSearch']//th"));
			int col=0;
			for(int i=0;i<elements.size();i++)
			{
				if(elements.get(i).getText().trim().contains("status"))
				{
					col=i;
					break;
				}
			}

			elements= BaseClass.driver.findElements(By.xpath("//table[@id='tblcustomerSearch']//th"));

			int actcol=0;
			for(int i=0;i<elements.size();i++)
			{
				if(elements.get(i).getText().trim().contains("Action"))
				{
					actcol=i;
					break;
				}
			}

			String tablerowsxpath="//table[@id='tblcustomerSearch']//tr";

			List<WebElement> tablerows= BaseClass.driver.findElements(By.xpath(tablerowsxpath));

			for(int i=1;i<elements.size();i++)
			{
				//col=8;
				String status_rowxpath="("+tablerowsxpath+")["+i+"]/td["+col+"]";
				if(BaseClass.driver.findElement(By.xpath(status_rowxpath)).getText().trim().equalsIgnoreCase("active"))
				{
					String action_rowxpath=tablerowsxpath+"["+i+"]//td["+actcol+"]//button";
					BaseClass.driver.findElement(By.xpath(action_rowxpath)).click();
					break;

				}

			}


		/*}	*/

	}


	
	
	@Then("^search the existing customer and click on the edit action$")
	public void search_existing_customer_click_edit(DataTable customerIDs) throws InterruptedException
	{
		for (Map<String, String> data : customerIDs.asMaps(String.class, String.class)) {
			System.out.println("Customer ID is\t:\t["+data.get("Customer_ID")+"]");
		
			mywrapper.hardWait(5000);
			mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("bdm_searchcustomer_cmfaccountnumber_textbox"),data.get("Customer_ID"));
			mywrapper.javascriptEx_Click(BaseClass.driver,BaseClass.OBJECT.getProperty("bdm_searchcustomer_search_button"));
			mywrapper.hardWait(10000);
			String rows="//table[@id='tblcustomerSearch']//tr";
			List<WebElement> elements2= BaseClass.driver.findElements(By.xpath(rows));
			System.out.println(elements2.size());
		
			int mycolumn=0;
			for(int i=1;i<elements2.size();i++)
			{
				String myXpath="(//table[@id='tblcustomerSearch']//tr)["+i+"]//td[12]//button";
				mywrapper.javascriptEx_Click(BaseClass.driver,myXpath);
				mywrapper.hardWait(10000);
				if(mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_updatecustomer_cmfstatus_textbox")).equalsIgnoreCase("active"))
					break;
				else
				{
					BaseClass.driver.navigate().back();
				}
				mywrapper.hardWait(5000);
			}
			
			String myXpath="(//table[@id='tblcustomerSearch']//tr["+mycolumn+"]//td)[12]//button";
			System.out.println(myXpath);
			
			List<WebElement> elements= BaseClass.driver.findElements(By.xpath(myXpath));
			System.out.println(elements.size());
			mywrapper.hardWait(5000);
			
		

			

		}
	}
	
	
	
	@Then("^Compare the Values of Consignee section present in the BDM Application with respective to Flat File$")
	public void validateConsigneeSectionWRTFlatFile() throws Throwable
	{
		try 
		{
			FileInputStream in = new FileInputStream(FILENAME);
			try 
			{
				prop.load(in);
			} 
			catch (IOException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	//	BaseClass.newtable();


		/*String consginee_checbox	=	prop.getProperty("bdm_shipment_consignee_checkbox");
		String consginee_address	=	prop.getProperty("bdm_shipment_consignee_address_textarea");
		String consginee_accountNumber	=	prop.getProperty("bdm_shipment_consignee_accountnumber_textbox");
		String consginee_department	=	prop.getProperty("bdm_shipment_consignee_department_textbox");
		String consginee_taxid	=	prop.getProperty("bdm_shipment_consignee_taxid_textbox");
		String consginee_contactname	=	prop.getProperty("bdm_shipment_consignee_contactname_textbox");
		String consginee_telephone	=	prop.getProperty("bdm_shipment_consignee_telephone_textbox");
		String consginee_city	=	prop.getProperty("bdm_shipment_consignee_city_textbox");
		String consginee_fax	=	prop.getProperty("bdm_shipment_consignee_fax_textbox");
		String consginee_state	=	prop.getProperty("bdm_shipment_consignee_state_textbox");
		String consginee_email	=	prop.getProperty("bdm_shipment_consignee_email_textbox");
		String consginee_country	=	prop.getProperty("bdm_shipment_consignee_country_textbox");
		String consginee_postcalcode	=	prop.getProperty("bdm_shipment_consignee_postalcode_textbox");
		*/
		SoftAssert sa= new SoftAssert();
		
		HashMap<String,String> consigneedetails=GBS_MSG.getConsigneeDetailsFromFlatFile();
		
	//	LazyAssert.assertEquals(consigneedetails.get("ConsigneerecordType"),(prop.getProperty("bdm_shipment_consignee_checkbox")));
		//assertEquals(consigneedetails.get("ConsigneerecordType"),prop.getProperty("bdm_shipment_consignee_address_textarea"));
	/*	LazyAssert.assertEquals("",consigneedetails.get("ConsigneePartyAccountNumber"),prop.getProperty("bdm_shipment_consignee_accountnumber_textbox"));
		LazyAssert.assertEquals(consigneedetails.get("ConsigneecontactDepartment"),prop.getProperty("bdm_shipment_consignee_department_textbox"));
		//assertEquals(consigneedetails.get("ConsigneerecordType"),prop.getProperty("bdm_shipment_consignee_taxid_textbox"));
		LazyAssert.assertEquals(consigneedetails.get("ConsigneecontactName"),prop.getProperty("bdm_shipment_consignee_contactname_textbox"));
		LazyAssert.assertEquals(consigneedetails.get("ConsigneeTelpehone"),prop.getProperty("bdm_shipment_consignee_telephone_textbox"));
		LazyAssert.assertEquals(consigneedetails.get("ConsigneeCity"),prop.getProperty("bdm_shipment_consignee_city_textbox"));
		LazyAssert.assertEquals(consigneedetails.get("ConsigneeContactFacsimile"),prop.getProperty("bdm_shipment_consignee_fax_textbox"));
		LazyAssert.assertEquals(consigneedetails.get("ConsigneeState"),prop.getProperty("bdm_shipment_consignee_state_textbox"));
		LazyAssert.assertEquals(consigneedetails.get("ConsigneeContactEmail"),prop.getProperty("bdm_shipment_consignee_email_textbox"));
		LazyAssert.assertEquals(consigneedetails.get("ConsigneeCountry"),prop.getProperty("bdm_shipment_consignee_country_textbox"));
		LazyAssert.assertEquals(consigneedetails.get("ConsigneePostalcode"),prop.getProperty("bdm_shipment_consignee_postalcode_textbox"));*/

	/*	LazyAssert.assertEquals("",consigneedetails.get("ConsigneePostalcode"),prop.getProperty("bdm_shipment_consignee_postalcode_textbox"));*/
		
		mywrapper.MoveToElement(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_department_textbox"));
		mywrapper.customTakeScreenShot(BaseClass.driver);
		/*count = 0;
		boolean verificationstatus=false;
		if(!(consigneedetails.get("ConsigneePartyAccountNumber").equalsIgnoreCase(prop.getProperty("bdm_shipment_consignee_accountnumber_textbox"))))
		{
			BaseClass.addrow("Consignee Party AccountNumber", consigneedetails.get("ConsigneePartyAccountNumber"), prop.getProperty("bdm_shipment_consignee_accountnumber_textbox"), "Fail");
			count++;
			verificationstatus=false;
			BaseClass.verificationErrors.append("The Expected Account Number for the consignee present into Flat File is ["+consigneedetails.get("ConsigneePartyAccountNumber")+"].But in the BDM Application Actual Account Number is ["+prop.getProperty("bdm_shipment_consignee_accountnumber_textbox")+"]\n");
			//BaseClass.addrow("Consignee Account Number ", consigneedetails.get("ConsigneePartyAccountNumber"), prop.getProperty("bdm_shipment_consignee_accountnumber_textbox"), "Failed");
		//	throw new Exception("The Expected Account Number for the consignee present into Flat File is ["+consigneedetails.get("ConsigneePartyAccountNumber")+"].But in the BDM Application Actual Account Number is ["+prop.getProperty("bdm_shipment_consignee_accountnumber_textbox")+"]\n");
		}
		else
		{
			BaseClass.addrow("Consignee Party AccountNumber", consigneedetails.get("ConsigneePartyAccountNumber"), prop.getProperty("bdm_shipment_consignee_accountnumber_textbox"), "Pass");
		}
		if(!(consigneedetails.get("ConsigneePostalcode").equalsIgnoreCase(prop.getProperty("bdm_shipment_consignee_postalcode_textbox"))))
		{
			BaseClass.addrow("Consignee Postal code", consigneedetails.get("ConsigneePostalcode"), prop.getProperty("bdm_shipment_consignee_postalcode_textbox"), "Fail");
			count++;
			verificationstatus=false;
			BaseClass.verificationErrors.append("The Expected Postal Code for the consignee present into Flat File is ["+consigneedetails.get("ConsigneePostalcode")+"].But in the BDM Application Actual postal code is ["+prop.getProperty("bdm_shipment_consignee_postalcode_textbox")+"]\n");
			//BaseClass.addrow("Consignee Postal Code ", consigneedetails.get("ConsigneePostalcode"), prop.getProperty("bdm_shipment_consignee_postalcode_textbox"), "Failed");
		//	throw new Exception("The Expected Postal Code for the consignee present into Flat File is ["+consigneedetails.get("ConsigneePostalcode")+"].But in the BDM Application Actual postal code is ["+prop.getProperty("bdm_shipment_consignee_postalcode_textbox")+"]\n");
		}
		else
		{
			BaseClass.addrow("Consignee Postal code", consigneedetails.get("ConsigneePostalcode"), prop.getProperty("bdm_shipment_consignee_postalcode_textbox"), "Pass");
		}
		if(!(consigneedetails.get("ConsigneeCountry").equalsIgnoreCase(prop.getProperty("bdm_shipment_consignee_country_textbox"))))
		{
			BaseClass.addrow("Consignee Country", consigneedetails.get("ConsigneeCountry"), prop.getProperty("bdm_shipment_consignee_country_textbox"), "Fail");
			count++;
			verificationstatus=false;
			BaseClass.verificationErrors.append("The Expected Country for the consignee present into Flat File is ["+consigneedetails.get("ConsigneeCountry")+"].But in the BDM Application Actual Country is ["+prop.getProperty("bdm_shipment_consignee_country_textbox")+"]\n");
		//	BaseClass.addrow("Consignee Postal Code ", consigneedetails.get("ConsigneeCountry"), prop.getProperty("bdm_shipment_consignee_country_textbox"), "Failed");
			//throw new Exception("The Expected Country for the consignee present into Flat File is ["+consigneedetails.get("ConsigneeCountry")+"].But in the BDM Application Actual Country is ["+prop.getProperty("bdm_shipment_consignee_country_textbox")+"]\n");
			
		}
		else
		{
			BaseClass.addrow("Consignee Country", consigneedetails.get("ConsigneeCountry"), prop.getProperty("bdm_shipment_consignee_country_textbox"), "Pass");
		}
		if(!(consigneedetails.get("ConsigneeContactEmail").equalsIgnoreCase(prop.getProperty("bdm_shipment_consignee_email_textbox"))))
		{
			BaseClass.addrow("Consignee Contact Email", consigneedetails.get("ConsigneeContactEmail"), prop.getProperty("bdm_shipment_consignee_email_textbox"), "Fail");
			count++;
			verificationstatus=false;
		//	BaseClass.addrow("Consignee Email ", consigneedetails.get("ConsigneeContactEmail"), prop.getProperty("bdm_shipment_consignee_email_textbox"), "Failed");
			BaseClass.verificationErrors.append("The Expected Email for the consignee present into Flat File is ["+consigneedetails.get("ConsigneeContactEmail")+"].But in the BDM Application Actual Email is ["+prop.getProperty("bdm_shipment_consignee_email_textbox")+"]\n");
		//	throw new Exception("The Expected Email for the consignee present into Flat File is ["+consigneedetails.get("ConsigneeContactEmail")+"].But in the BDM Application Actual Email is ["+prop.getProperty("bdm_shipment_consignee_email_textbox")+"]\n");
			
		}
		else
		{
			BaseClass.addrow("Consignee Contact Email", consigneedetails.get("ConsigneeContactEmail"), prop.getProperty("bdm_shipment_consignee_email_textbox"), "Pass");
		}
		if(!(consigneedetails.get("ConsigneeState").equalsIgnoreCase(prop.getProperty("bdm_shipment_consignee_state_textbox"))))
		{
			BaseClass.addrow("Consignee State", consigneedetails.get("ConsigneeState"), prop.getProperty("bdm_shipment_consignee_state_textbox"), "Fail");
			count++;
			verificationstatus=false;
		//	BaseClass.addrow("Consignee ConsigneeState ", consigneedetails.get("ConsigneeState"), prop.getProperty("bdm_shipment_consignee_state_textbox"), "Failed");
			BaseClass.verificationErrors.append("The Expected state for the consignee present into Flat File is ["+consigneedetails.get("ConsigneeState")+"].But in the BDM Application Actual state is ["+prop.getProperty("bdm_shipment_consignee_state_textbox")+"]\n");
			//throw new Exception("The Expected state for the consignee present into Flat File is ["+consigneedetails.get("ConsigneeState")+"].But in the BDM Application Actual state is ["+prop.getProperty("bdm_shipment_consignee_state_textbox")+"]\n");
		}
		else
		{
			BaseClass.addrow("Consignee State", consigneedetails.get("ConsigneeState"), prop.getProperty("bdm_shipment_consignee_state_textbox"), "Pass");
		}
		if(!(consigneedetails.get("ConsigneeContactFacsimile").equalsIgnoreCase(prop.getProperty("bdm_shipment_consignee_fax_textbox"))))
		{
			BaseClass.addrow("Consignee Contact Facsimile", consigneedetails.get("ConsigneeContactFacsimile"), prop.getProperty("bdm_shipment_consignee_fax_textbox"), "Fail");
			count++;
			verificationstatus=false;
			//BaseClass.addrow("Consignee Fax ", consigneedetails.get("ConsigneeContactFacsimile"), prop.getProperty("bdm_shipment_consignee_fax_textbox"), "Failed");
			BaseClass.verificationErrors.append("The Expected Fax for the consignee present into Flat File is ["+consigneedetails.get("ConsigneeContactFacsimile")+"].But in the BDM Application Actual Fax is ["+prop.getProperty("bdm_shipment_consignee_fax_textbox")+"]\n");
		//	throw new Exception("The Expected Fax for the consignee present into Flat File is ["+consigneedetails.get("ConsigneeContactFacsimile")+"].But in the BDM Application Actual Fax is ["+prop.getProperty("bdm_shipment_consignee_fax_textbox")+"]\n");
			
			//new Exception("The Expected Fax for the consignee present into Flat File is ["+consigneedetails.get("ConsigneeContactFacsimile")+"].But in the BDM Application Actual Fax is ["+prop.getProperty("bdm_shipment_consignee_fax_textbox")+"]\n");
		}
		else
		{
			BaseClass.addrow("Consignee Contact Facsimile", consigneedetails.get("ConsigneeContactFacsimile"), prop.getProperty("bdm_shipment_consignee_fax_textbox"), "Pass");
		}
		if(!(consigneedetails.get("ConsigneeCity").equalsIgnoreCase(prop.getProperty("bdm_shipment_consignee_city_textbox"))))
		{
			BaseClass.addrow("Consignee City", consigneedetails.get("ConsigneeCity"), prop.getProperty("bdm_shipment_consignee_city_textbox"), "Fail");
			count++;
			verificationstatus=false;
			//BaseClass.addrow("Consignee City ", consigneedetails.get("ConsigneeCity"), prop.getProperty("bdm_shipment_consignee_city_textbox"), "Failed");
			BaseClass.verificationErrors.append("The Expected City for the consignee present into Flat File is ["+consigneedetails.get("ConsigneeCity")+"].But in the BDM Application Actual City is ["+prop.getProperty("bdm_shipment_consignee_city_textbox")+"]\n");
		//	throw new Exception("The Expected City for the consignee present into Flat File is ["+consigneedetails.get("ConsigneeCity")+"].But in the BDM Application Actual City is ["+prop.getProperty("bdm_shipment_consignee_city_textbox")+"]\n");
		}
		else
		{
			BaseClass.addrow("Consignee City", consigneedetails.get("ConsigneeCity"), prop.getProperty("bdm_shipment_consignee_city_textbox"), "Pass");
		}
		if(!(consigneedetails.get("ConsigneecontactName").equalsIgnoreCase(prop.getProperty("bdm_shipment_consignee_contactname_textbox"))))
		{
			BaseClass.addrow("Consignee Contact Name", consigneedetails.get("ConsigneecontactName"), prop.getProperty("bdm_shipment_consignee_contactname_textbox"), "Fail");
			count++;
			verificationstatus=false;
			//BaseClass.addrow("Consignee Contact Name ", consigneedetails.get("ConsigneecontactName"), prop.getProperty("bdm_shipment_consignee_contactname_textbox"), "Failed");
			BaseClass.verificationErrors.append("The Expected Contact Name for the consignee present into Flat File is ["+consigneedetails.get("ConsigneecontactName")+"].But in the BDM Application Actual Contact Name is ["+prop.getProperty("bdm_shipment_consignee_contactname_textbox")+"]\n");
		}
		else
		{
			BaseClass.addrow("Consignee Contact Name", consigneedetails.get("ConsigneecontactName"), prop.getProperty("bdm_shipment_consignee_contactname_textbox"), "Pass");
		}
		
		*/
		
		
		testa();
		
		
		
		if(count>1){
			BaseClass.status=false;
			fail();
		}
		else
		{
			BaseClass.status=true;
		}
		
	
	}
	

	@Then("^store all the business information present in the update customer screen$")
	public void customer_search_details()
	{
		
		
		HashMap<String,String > customers=new HashMap<String,String>();
		
		customers.put("AccountNumber", mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_updatecustomer_accountnumber_textbox").toString().trim()));
		customers.put("CustomerNumber", mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_updatecustomer_customername_textbox").toString().trim()));
		customers.put("TaxID", mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_updatecustomer_taxid_textbox").toString().trim()));
		customers.put("AddressLine1", mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_updatecustomer_addressline1_textbox").toString().trim()));
		customers.put("AddressLine2", mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_updatecustomer_addressline2_textbox").toString().trim()));
		customers.put("AddressLine3", mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_updatecustomer_addressline3_textbox").toString().trim()));
		customers.put("City", mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_updatecustomer_city_textbox").toString().trim()));
		customers.put("State", mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_updatecustomer_state_textbox").toString().trim()));
		customers.put("zipcode", mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_updatecustomer_postalcode_textbox").toString().trim()));
		customers.put("country", mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_updatecustomer_country_listbox").toString().trim()));
		customers.put("contactName", mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_updatecustomer_contactname_textbox").toString().trim()));
		customers.put("contactdeparyment", mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_updatecustomer_contactdepartment_textbox").toString().trim()));
		customers.put("contactPhoneNumber", mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_updatecustomer_contactphonenumber_textbox").toString().trim()));
		customers.put("cmfstatus", mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_updatecustomer_cmfstatus_textbox").toString().trim()));
		customers.put("latestcmfupdate", mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_updatecustomer_latestcmfupdate_textbox").toString().trim()));
		customers.put("bdmupdatedby", mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_updatecustomer_bdmupdatedby_textbox").toString().trim()));
		customers.put("latestbdmupdate", mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_updatecustomer_latestbdmupdate_textbox").toString().trim()));
		
		
		System.out.println(customers);
		
		
		
		
	}


	
	@When("^get the Values of WayBill Table$")
	public void getWayBillDetails()
	{
		List<WebElement> wayDetailsHeaderColumns=BaseClass.driver.findElements(By.xpath(BaseClass.OBJECT.getProperty("bdm_shipment_waybill_headers")));
		List<WebElement> wayDetailsRows=BaseClass.driver.findElements(By.xpath("//div[@id='waybillTable']//table//tbody//tr"));
		String myXpath=BaseClass.OBJECT.getProperty("bdm_shipment_waybill_rows");
		for(int j=1;j<=wayDetailsRows.size();j++)
		{
			for(int i=1;i<=wayDetailsHeaderColumns.size()-4;i++)
			{
				String getXpathaa="("+myXpath+"["+j+"]//td)["+i+"]";
				System.out.print(BaseClass.driver.findElement(By.xpath(getXpathaa)).getText()+"\t:\t");
				
			}
			System.out.println("\n");
		}
		
	}
	
	
	
	

	@When("^get the Values of Container Table$")
	public void getContainerDetails()
	{
		
		try
		{
			List<WebElement> wayDetailsHeaderColumns=BaseClass.driver.findElements(By.xpath(BaseClass.OBJECT.getProperty("bdm_shipment_containers_headers")));
			List<WebElement> wayDetailsRows=BaseClass.driver.findElements(By.xpath(BaseClass.OBJECT.getProperty("bdm_shipment_containers_rows")));
			String myXpath=BaseClass.OBJECT.getProperty("bdm_shipment_waybill_rows");
			for(int j=1;j<=wayDetailsRows.size();j++)
			{
				for(int i=1;i<=wayDetailsHeaderColumns.size()-4;i++)
				{
					String getXpathaa="("+myXpath+"["+j+"]//td)["+i+"]";
					System.out.print(BaseClass.driver.findElement(By.xpath(getXpathaa)).getText()+"\t:\t");

				}
				System.out.print("\n");
			}
		}
		catch(Exception e)
		{
			System.out.println("There is no weblements");
		}
		
	}
	
	
	
	@Then("^Print the Values of Manifest Data$")
	public void getManifestInformation()
	{
		try 
		{
			FileInputStream in = new FileInputStream(FILENAME);
			try 
			{
				prop.load(in);
			} 
			catch (IOException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(prop.getProperty("bdm_shipment_shipmentdescription_textbox"));
		System.out.println(prop.getProperty("bdm_shipment_shipmentvalue_textbox"));
		System.out.println(prop.getProperty("bdm_shipment_shipmentvalue_gdropdown"));
		System.out.println(prop.getProperty("bdm_shipment_firmcode_textbox"));
		System.out.println(prop.getProperty("bdm_shipment_totalqty_textbox"));
		System.out.println(prop.getProperty("bdm_shipment_quntity_dropdown"));
		System.out.println(prop.getProperty("bdm_shipment_totalgrossweight_textbox"));
		System.out.println(prop.getProperty("bdm_shipment_totalgrossweight_dropdown"));
		System.out.println(prop.getProperty("bdm_shipment_totalgrossweight_stateofdes_textbox"));
		System.out.println(prop.getProperty("bdm_shipment_shipmentinstruction_textbox"));
		System.out.println(prop.getProperty("bdm_shipment_modeoftransport_dropdown"));
		System.out.println(prop.getProperty("bdm_shipment_totalnetweight_textbox"));
		System.out.println(prop.getProperty("bdm_shipment_totalnetweight_dropdown"));
		System.out.println(prop.getProperty("bdm_shipment_freightcharge_textbox"));
		System.out.println(prop.getProperty("bdm_shipment_freightcharge_dropdown"));
		System.out.println(prop.getProperty("bdm_shipment_insurancecharge_textbox"));
		System.out.println(prop.getProperty("bdm_shipment_insurancecharge_dropdown"));
		System.out.println(prop.getProperty("bdm_shipment_date"));
		System.out.println(prop.getProperty("bdm_shipment_entrytype_dropdown"));
		System.out.println(prop.getProperty("bdm_shipment_voyage_txtbox"));
		System.out.println(prop.getProperty("bdm_shipment_vesselname_textbox"));
		System.out.println(prop.getProperty("bdm_shipment_importerref_textbox"));
		System.out.println(prop.getProperty("bdm_shipment_marknumber_textbox"));
		System.out.println(prop.getProperty("bdm_shipment_customerrefernce_textbox"));
		
		System.out.println(prop.getProperty("bdm_shipment_manifestdate_textbox"));
		System.out.println(prop.getProperty("bdm_shipment_govtcontract_textbox"));
		System.out.println(prop.getProperty("bdm_shipment_railcarnumber_textbox"));
		System.out.println(prop.getProperty("bdm_shipment_masterpro_textbox"));
		System.out.println(prop.getProperty("bdm_shipment_outboundidentifer_dropdown"));
		System.out.println(prop.getProperty("bdm_shipment_lastfreed_textbpox"));
		System.out.println(prop.getProperty(""));
		
	}
	
	
	
	
	
	public void validateValues(Object expected,Object actual)
	{
		
		
		
		HashMap<String,String> PayerDetails=GBS_MSG.getPayerDetails();
		
		
		
		PayerDetails.get("PayerrecordType");
		PayerDetails.get("PayerUniquePartyRecord");
		PayerDetails.get("PayerPartyAccountNumber");
		PayerDetails.get("PayerCompanyName");
		if(PayerDetails.get("PayerPartyAddress1")==prop.getProperty("bdm_shipment_payer_address_textbox"))
		{
			
		}
		/*PayerDetails.get("PayerPartyAddress2"),prop.getProperty("bdm_shipment_payer_address_textbox"));
		PayerDetails.get("PayerPartyAddress3"),prop.getProperty("bdm_shipment_payer_address_textbox"));
		PayerDetails.get("PayerCity"),prop.getProperty("bdm_shipment_payer_city_textbox"))
		PayerDetails.get("PayerState"),prop.getProperty("bdm_shipment_payer_state_textbox"));
		PayerDetails.get("PayerPostalcode"),prop.getProperty("bdm_shipment_payer_postalcode_textbox"));
		PayerDetails.get("PayerCountry"),prop.getProperty("bdm_shipment_payer_country_textbox"));
		PayerDetails.get("PayerTelpehone"),prop.getProperty("bdm_shipment_payer_telephone_textbox"));
		PayerDetails.get("PayercontactName"),prop.getProperty("bdm_shipment_payer_contactname_textbox"));
		PayerDetails.get("PayercontactDepartment"),prop.getProperty("bdm_shipment_payer_department_textbox"));
		//PayerDetails.get("PayerContactDivision");
		PayerDetails.get("PayerContactEmail"),prop.getProperty("bdm_shipment_payer_emailid_textbox"));
		PayerDetails.get("PayerContactTeplehone"),prop.getProperty("bdm_shipment_payer_telephone_textbox"));
		PayerDetails.get("PayerContactFacsimile"),prop.getProperty("bdm_shipment_payer_fax_textbox"));*/
		//PayerDetails.get("PayerCarrierCode");
	//	PayerDetails.get("PayerCarrierName");
		
	}
	
	
	public StringBuffer getValidation(String expected,String actual)
	{
		
		
		Scenario  scenario;
		
		return null;
		
	}
	
	
	
	
	
	
	public void validateFieldLevel(String FieldName,String FlatfileValue,String BDMElementValue) throws IOException
	{
		if(FlatfileValue.equals(BDMElementValue))
		{
			BaseClass.addrow(FieldName,FlatfileValue,BDMElementValue,"PASS");
		}
		else
		{
			BaseClass.addrow(FieldName,FlatfileValue,BDMElementValue,"FAIL");
			count++;
			BaseClass.verificationErrors.append("The Expected ["+FieldName+"] present into Flat File is ["+FlatfileValue+"].But in the BDM Application it displays as ["+BDMElementValue+"]\n");
		}
	}
	
	
	public void testa() throws IOException
	{		

		validateFieldLevel("Station Code","Need to check with flat file",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_stationcode_dropdown")));
		validateFieldLevel("IOR Account Number","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ioraccount_textbox")));
		validateFieldLevel("Entry Port","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_entryport_textbox")));
		validateFieldLevel("Est Arrival Date","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_estarrivaldate_textbox")));
		validateFieldLevel("Est Arrival Time","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_estarrivaltime_textbox")));
		validateFieldLevel("Cert. of Orig. Ind","Need to check with flat file",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_certoforgind_dropdown")));
		validateFieldLevel("Line Rel. Ind","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_linerelind_checkbox")));
		validateFieldLevel("Act Arrival Date","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_actarrivaldate_textbox")));
		validateFieldLevel("Service Level","Need to check with flat file",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_servicelevel_dropdown")));
		validateFieldLevel("Import Date","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_importdate_textbox")));
		validateFieldLevel("Import Country","Need to check with flat file",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_importcountry_dropdown")));
		validateFieldLevel("Person In Charge","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_personincharge_textbox")));
		validateFieldLevel("Reconciliation Type","Need to check with flat file",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_reconcillationtype_dropdown")));
		validateFieldLevel("Reconciliation","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_reconcillation_checkbox")));
		validateFieldLevel("Shipment Number","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipmentnumber_textbox")));
		validateFieldLevel("Broker Ref Number","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_brokerrefnumber")));
		validateFieldLevel("User Id","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_userid_textbox")));
		validateFieldLevel("Shipment Date","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipmentdate_textbox")));
		validateFieldLevel("Shipment Status","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipmentstatus_textbox")));



		validateFieldLevel("Shipper Same as IOR",GBS_MSG.ShipperDetails.get("ShipperrecordType"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_importorshipment_checkbox")));
		validateFieldLevel("Shipper Name",GBS_MSG.ShipperDetails.get("ShipperUniquePartyRecord"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shippername_textbox")));
		validateFieldLevel("Shipper Address",GBS_MSG.ShipperDetails.get("ShipperPartyAddress1")+"\n"+GBS_MSG.ShipperDetails.get("ShipperPartyAddress2")+"\n"+GBS_MSG.ShipperDetails.get("ShipperPartyAddress3"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_address_textarea")));
		validateFieldLevel("Shipper Department","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_department_textbox")));
			//	validateFieldLevel("Shipper Entry Level MID","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_entrylevelmid_textbox")));
		validateFieldLevel("Shipper Contact Name",GBS_MSG.ShipperDetails.get("ShippercontactName"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_contactname_textbox")));
		validateFieldLevel("Shipper City",GBS_MSG.ShipperDetails.get("ShipperCity"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_city_textbox")));
		validateFieldLevel("Shipper FAX",GBS_MSG.ShipperDetails.get("ShipperContactFacsimile"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_fax_textbox")));
		validateFieldLevel("Shipper Telephone",GBS_MSG.ShipperDetails.get("ShipperContactTeplehone"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_telephone_textbox")));
		validateFieldLevel("Shipper Email",GBS_MSG.ShipperDetails.get("ShipperContactEmail"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_email_textbox")));
		validateFieldLevel("Shipper Country",GBS_MSG.ShipperDetails.get("ShipperCountry"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_country_textbox")));
		validateFieldLevel("Shipper State",GBS_MSG.ShipperDetails.get("ShipperState"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_state_textbox")));
		validateFieldLevel("Shipper Postal Code",GBS_MSG.ShipperDetails.get("ShipperPostalcode"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipper_postalcode_textbox")));


		validateFieldLevel("IOR Name",GBS_MSG.IORDetails.get("IORCompanyName"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_name_textbox")));
		validateFieldLevel("IOR Address",GBS_MSG.IORDetails.get("IORPartyAddress1")+"\n"+GBS_MSG.IORDetails.get("IORPartyAddress2")+"\n"+GBS_MSG.IORDetails.get("IORPartyAddress3"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_address_textbox")));
		validateFieldLevel("IOR Department",GBS_MSG.IORDetails.get("IORcontactDepartment"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_department_textbox")));
				//validateFieldLevel("IOR TaxId",GBS_MSG.IORDetails.get("IORrecordType"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_taxid_textbox")));
		validateFieldLevel("IOR Contact Name",GBS_MSG.IORDetails.get("IORcontactName"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_contactname_textbox")));
		validateFieldLevel("IOR City",GBS_MSG.IORDetails.get("IORCity"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_city_textbox")));
		validateFieldLevel("IOR Telephone",GBS_MSG.IORDetails.get("IORTelpehone"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_telephone_textbox")));
		validateFieldLevel("IOR State",GBS_MSG.IORDetails.get("IORState"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_state_textbox")));
		validateFieldLevel("IOR FAX",GBS_MSG.IORDetails.get("IORContactFacsimile"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_fax_textbox")));
		validateFieldLevel("IOR Country",GBS_MSG.IORDetails.get("IORrecordType"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_country_textbox")));
		validateFieldLevel("IOR Email",GBS_MSG.IORDetails.get("IORCountry"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_email_textbox")));
		validateFieldLevel("IOR Postal Code",GBS_MSG.IORDetails.get("IORPostalcode"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_ior_postalcode_textbox")));



		validateFieldLevel("Consignee Same as IOR",GBS_MSG.ConsigneeDetails.get("ConsigneerecordType"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_checkbox")));
		validateFieldLevel("Consignee Address",GBS_MSG.ConsigneeDetails.get("ConsigneePartyAddress1")+"\n"+GBS_MSG.ConsigneeDetails.get("ConsigneePartyAddress2")+"\n"+GBS_MSG.ConsigneeDetails.get("ConsigneePartyAddress3"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_address_textarea")));
		validateFieldLevel("Consignee Account Number",GBS_MSG.ConsigneeDetails.get("ConsigneePartyAccountNumber"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_accountnumber_textbox")));
		validateFieldLevel("Consignee Department",GBS_MSG.ConsigneeDetails.get("ConsigneecontactDepartment"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_department_textbox")));
					validateFieldLevel("Consignee TaxId","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_taxid_textbox")));
		validateFieldLevel("Consignee Contact Name",GBS_MSG.ConsigneeDetails.get("ConsigneecontactName"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_contactname_textbox")));
		validateFieldLevel("Consignee Telephone",GBS_MSG.ConsigneeDetails.get("ConsigneeContactTeplehone"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_telephone_textbox")));
		validateFieldLevel("Consignee City",GBS_MSG.ConsigneeDetails.get("ConsigneeCity"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_city_textbox")));
		validateFieldLevel("Consignee FAX",GBS_MSG.ConsigneeDetails.get("ConsigneeState"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_fax_textbox")));
		validateFieldLevel("Consignee State",GBS_MSG.ConsigneeDetails.get("ConsigneeCity"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_state_textbox")));
		validateFieldLevel("Consignee Email",GBS_MSG.ConsigneeDetails.get("ConsigneeContactEmail"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_email_textbox")));
		validateFieldLevel("Consignee Country",GBS_MSG.ConsigneeDetails.get("ConsigneeCountry"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_country_textbox")));
		validateFieldLevel("Consignee Postal Code",GBS_MSG.ConsigneeDetails.get("ConsigneePostalcode"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_consignee_postalcode_textbox")));



		validateFieldLevel("Payer Same as IOR",GBS_MSG.PayerDetails.get("PayerrecordType"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_checkbox")));
		validateFieldLevel("Payer Address",GBS_MSG.PayerDetails.get("PayerPartyAddress1")+"\n"+GBS_MSG.PayerDetails.get("PayerPartyAddress2")+"\n"+GBS_MSG.PayerDetails.get("PayerPartyAddress3"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_address_textbox")));
		validateFieldLevel("Payer Account Number",GBS_MSG.PayerDetails.get("PayerPartyAccountNumber"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_accountnumber_textbox")));
		validateFieldLevel("Payer Department",GBS_MSG.PayerDetails.get("PayercontactDepartment"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_department_textbox")));
		validateFieldLevel("Payer TaxId","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_taxid_textbox")));
		validateFieldLevel("Payer Contact Name",GBS_MSG.PayerDetails.get("PayercontactName"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_contactname_textbox")));
		validateFieldLevel("Payer Telephone",GBS_MSG.PayerDetails.get("PayerContactTeplehone"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_telephone_textbox")));
		validateFieldLevel("Payer City",GBS_MSG.PayerDetails.get("PayerCity"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_city_textbox")));
		validateFieldLevel("Payer FAX",GBS_MSG.PayerDetails.get("PayerContactFacsimile"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_fax_textbox")));
		validateFieldLevel("Payer State",GBS_MSG.PayerDetails.get("PayerState"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_state_textbox")));
		validateFieldLevel("Payer Email",GBS_MSG.PayerDetails.get("PayerContactEmail"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_emailid_textbox")));
		validateFieldLevel("Payer Country",GBS_MSG.PayerDetails.get("PayerCountry"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_country_textbox")));
		validateFieldLevel("Payer Postal Code",GBS_MSG.PayerDetails.get("PayerPostalcode"),mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_payer_postalcode_textbox")));


		validateFieldLevel("Ship To Name","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_name_textbox")));
		validateFieldLevel("Ship To Address","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_address_textbox")));
		validateFieldLevel("Ship To Department","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_department_textbox")));
		validateFieldLevel("Ship To Division","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_division_textbox")));
		validateFieldLevel("Ship To Contact Name","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_contactname_textbox")));
		validateFieldLevel("Ship To City","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_city_textbox")));
		validateFieldLevel("Ship To Telephone","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_telephone_textbox")));
		validateFieldLevel("Ship To State","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_state_textbox")));
		validateFieldLevel("Ship To FAX","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_fax_textbox")));
		validateFieldLevel("Ship To Postal Code","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_postalcode_textbox")));
		validateFieldLevel("Ship To Email","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_email_textbox")));
		validateFieldLevel("Ship To Country","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipto_country_textbox")));




		validateFieldLevel("Exporter Name","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_name_textbox")));
		validateFieldLevel("Exporter Address","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_address_textarea")));
		validateFieldLevel("Exporter Department","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_department")));
		validateFieldLevel("Exporter Entry Level MID","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_entrylevelmid_textbox")));
		validateFieldLevel("Exporter Contact Name","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_contactname_textbox")));
		validateFieldLevel("Exporter City","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_city_textbox")));
		validateFieldLevel("Exporter Telephone","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_telephone_exporter")));
		//validateFieldLevel("bdm_shipment_exporter_telephone_textbox","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_telephone_textbox")));
		validateFieldLevel("Exporter State","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_state_textbox")));
		validateFieldLevel("Exporter FAX","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_fax_textbox")));
		validateFieldLevel("Exporter Postal Code","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_postalcode_textbox")));
		validateFieldLevel("Exporter Email","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_email_textbox")));
		validateFieldLevel("Exporter Country","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_exporter_country_textbox")));



		validateFieldLevel("Submitter Name","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_textbox")));
		validateFieldLevel("Submitter Address","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_address_textbox")));
		validateFieldLevel("Submitter Department","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_department_textbox")));
		validateFieldLevel("Submitter Entry Level MID","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_entrylevel_textbox")));
		validateFieldLevel("Submitter Contact Name","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_contactname_textbox")));
		validateFieldLevel("Submitter City","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_city_textbox")));
		validateFieldLevel("Submitter Telephone","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_telephone_textbox")));
		validateFieldLevel("Submitter State","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_state_textbox")));
		validateFieldLevel("Submitter FAX","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_fax_textbox")));
		validateFieldLevel("Submitter Postal Code","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_postalcode_textbox")));
		validateFieldLevel("Submitter Email","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_email_textbox")));
		validateFieldLevel("Submitter Country","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_submitter_country_textbox")));




		validateFieldLevel("Origin Country","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_origincountry_dropdown")));
		validateFieldLevel("Port of Lading","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_portoflanding_textbox")));
		validateFieldLevel("Export Country","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_exportcountry_dropdown")));
		validateFieldLevel("Export Ports","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_exportport_textbox")));
		validateFieldLevel("Last Foreign Port","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_lastforeignport_textbox")));
		validateFieldLevel("Port of Unlading","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_portoflanding_textbox")));
		validateFieldLevel("Export Date","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_exportdate_textbox")));
		validateFieldLevel("In-Bond Carrier","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_inbondcarrier_textbox")));
		validateFieldLevel("In-Bond Port of Destination","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_port_inboundportofdistination_textbox")));


		validateFieldLevel("Shipment Description","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipmentdescription_textbox")));
		validateFieldLevel("Shipment Value","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipmentvalue_textbox")));
		validateFieldLevel("Shipment Weight","Need to check with flat file",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipmentvalue_gdropdown")));
		validateFieldLevel("Firms Code","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_firmcode_textbox")));
		validateFieldLevel("Total Qty","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_totalqty_textbox")));
		validateFieldLevel("Total Qty Weight","Need to check with flat file",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_quntity_dropdown")));
		validateFieldLevel("Total gross Weight","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_totalgrossweight_textbox")));
		validateFieldLevel("Total gross Weight Value","Need to check with flat file",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_totalgrossweight_dropdown")));
		validateFieldLevel("State of Dest","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_totalgrossweight_stateofdes_textbox")));
		validateFieldLevel("Shipment Instructions","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_shipmentinstruction_textbox")));
		validateFieldLevel("Mode of Transport","Need to check with flat file",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_modeoftransport_dropdown")));
		validateFieldLevel("Total Net weight","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_totalnetweight_textbox")));
		validateFieldLevel("Total Net weight Value","Need to check with flat file",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_totalnetweight_dropdown")));
		validateFieldLevel("Freight Charge","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_freightcharge_textbox")));
		validateFieldLevel("Freight Charge Value","Need to check with flat file",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_freightcharge_dropdown")));
		validateFieldLevel("Insurance Charge","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_insurancecharge_textbox")));
		validateFieldLevel("Insurance Charge Value","Need to check with flat file",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_insurancecharge_dropdown")));
		validateFieldLevel("Est Entry Date","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_date")));
		validateFieldLevel("Entry Type","Need to check with flat file",mywrapper.getSelectedValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_entrytype_dropdown")));
		validateFieldLevel("voyage/Flight","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_voyage_txtbox")));
		validateFieldLevel("Vessel Name","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_vesselname_textbox")));
		validateFieldLevel("Importer Ref","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_importerref_textbox")));
		validateFieldLevel("Marks & Numbers","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_marknumber_textbox")));
		validateFieldLevel("Customer Reference","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_customerrefernce_textbox")));
		validateFieldLevel("Manifest Date","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_manifestdate_textbox")));
		validateFieldLevel("Govt. Contract","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_govtcontract_textbox")));
		validateFieldLevel("bdm_shipment_raRail Car Numberilcarnumber_textbox","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_railcarnumber_textbox")));
		validateFieldLevel("MasterPro","Need to check with flat file",mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("bdm_shipment_masterpro_textbox")));}
}
