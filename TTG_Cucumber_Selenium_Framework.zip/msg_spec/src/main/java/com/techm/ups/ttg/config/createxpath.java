package com.techm.ups.ttg.config;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import com.techm.ups.ttg.utils.RandomClass;
import com.techm.ups.ttg.utils.Read_xls;

public class createxpath {
	
	static DateFormat dateFormat = new SimpleDateFormat("dd_mm_yyyy_hh_mm");
	static Date date = new Date();

	static String dateformates=dateFormat.format(date);
	private static final String FILENAME = "D:\\Chandrakanth\\TTG\\xpath_"+dateformates+".txt";

	static StringBuilder sb;

	static BufferedWriter bw = null;
	static FileWriter fw=null;
	static RandomClass randomvalues;
	static String Values;
	public static void main(String[] arg)
	{
		try
		{
			fw =  new FileWriter(FILENAME,true);

			bw = new BufferedWriter(fw);
			sb = new StringBuilder();
			Read_xls read= new Read_xls("D:\\Chandrakanth\\TTG\\ObjectRepositry\\Search_customer.xls");
			int rowcount=read.getRowCount("Sheet1");
			System.out.println("The Number of Rows in the each Sheet [Sheet1] is \t:\t"+rowcount);
			HashMap<String,String> xpaths= new HashMap<String,String>();
			String keys="";
			String correspondingvalue="";
			String keyvalues="";
			for(int rows=2;rows<=rowcount;rows++)
			{
				keys=read.getCellData("Sheet1", "UserDefined", rows).toString().trim();
				correspondingvalue=read.getCellData("Sheet1", "Xpath", rows).toString().trim();
				xpaths.put(keys, correspondingvalue);
				keyvalues=keys+"="+correspondingvalue;
				sb.append(keyvalues+"\n");
				//Values=ListofSegments.get(i).toString();
				//System.out.println("The TestData Generated for Each Column ["+read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows)+"] and the Value is ["+Values+"]");


			}


			System.out.println("_______________________________");
			System.out.println(sb);
			bw.append(sb.toString());
			System.out.println("_______________________________");
		}
		catch (IOException e) {

			e.printStackTrace();

		} finally {

			try {

				if (bw != null)
					bw.close();

				if (fw != null)
					fw.close();

			} catch (IOException ex) {

				ex.printStackTrace();

			}

		}
	}

}
