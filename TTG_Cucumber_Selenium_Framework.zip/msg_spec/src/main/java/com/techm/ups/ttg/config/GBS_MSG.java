package com.techm.ups.ttg.config;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

import org.apache.log4j.Logger;

import com.github.javafaker.Faker;
import com.techm.ups.ttg.glue.BaseClass;
import com.techm.ups.ttg.utils.ExcelWriter;
import com.techm.ups.ttg.utils.RandomClass;
import com.techm.ups.ttg.utils.Read_xls;



public class GBS_MSG 
{
	
	public static HashMap<String,String> ShipperDetails;
	public static HashMap<String,String> ConsigneeDetails;
	public static HashMap<String,String> IORDetails;
	public static HashMap<String,String> PayerDetails;
	private static Logger oLog = Logger.getLogger(GBS_MSG.class);
	static String Identifier_filepath=System.getProperty("user.dir")+"/src/test/resources/TestData/Identifers.xlsx";
	static String frame_filepath=System.getProperty("user.dir")+"/src/test/resources/TestData/TTG_FRAMEWORK.xlsx";
	static DateFormat dateFormat = new SimpleDateFormat("dd_mm_yyyy_hh_mm");
	static Date date = new Date();

	static String dateformates=dateFormat.format(date);

	/*public static final String FILENAME = "D:\\Chandrakanth\\TTG\\FlatFile_"+dateformates+".txt";
	public static final String FILENAME_Excel = "D:\\Chandrakanth\\TTG\\FlatFile_"+dateformates+".xlsx";
	*/
	
	public static final String FILENAME = System.getProperty("user.dir")+"/target/FlatFile_"+dateformates+".txt";;
	public static final String FILENAME_Excel = System.getProperty("user.dir")+"/target/FlatFile_"+dateformates+".xlsx";
	public static StringBuilder sb;

	static BufferedWriter bw = null;
	static FileWriter fw=null;
	static RandomClass randomvalues;
	static String Values;
	public static String test()
	{
		Faker faker = new Faker(new Locale("en-US"));

		try
		{
			fw =  new FileWriter(FILENAME,true);
			bw = new BufferedWriter(fw);
			HashMap<String,Integer> identifer_map=new HashMap<String,Integer>();
			sb = new StringBuilder();
			Read_xls read= new Read_xls(frame_filepath);
			Read_xls read_iterator= new Read_xls(Identifier_filepath);
			/*Read_xls read= new Read_xls("D:\\Chandrakanth\\TTG\\TTG_FRAMEWORK.xlsx");
			Read_xls read_iterator= new Read_xls("D:\\Chandrakanth\\TTG\\Identifers.xlsx");*/
			int iterators_count=read_iterator.getRowCount("POC");
		/*	System.out.println(iterators_count);*/


			//FileOutputStream fileOut = new FileOutputStream(FILENAME_Excel);
			ExcelWriter writer=new ExcelWriter(FILENAME_Excel);
			Set<String> SheetNames= new TreeSet<String>();
			int totalnumberofrecords=0;
			for(int i=1;i<iterators_count;i++)
			{
				/*System.out.println(read_iterator.getCellData("POC", i, 1).trim().toString() );
				System.out.println(Integer.parseInt(read_iterator.getCellData("POC", i, 3)));*/
				SheetNames.add(read_iterator.getCellData("POC", i, 1).trim().toString());
				identifer_map.put(read_iterator.getCellData("POC", i, 1), Integer.parseInt(read_iterator.getCellData("POC", i, 3)));
				if(!(read_iterator.getCellData("POC", i, 1).equalsIgnoreCase("A")||read_iterator.getCellData("POC", i, 1).equalsIgnoreCase("Z")))
				{
					totalnumberofrecords=totalnumberofrecords+Integer.parseInt(read_iterator.getCellData("POC", i, 3));
				}
			}
			System.out.println("Total Count is\t:\t"+totalnumberofrecords);

			int row=0;
			for (String stock : SheetNames) 
			{
			/*	System.out.println(stock); */
				writer.addSheet(stock);

				List<String> readsheetNames=read.getSheetNames();
				List<String> data_element_values=new ArrayList<String>();
				for(int i=0;i<readsheetNames.size();i++)
				{
					if(readsheetNames.get(i).trim().equalsIgnoreCase(stock))
					{
						data_element_values=read.getColumnData(stock, "DATA_ELEMENT");
						for(int j=0;j<data_element_values.size();j++)
						{
							writer.setCellDataColNo(stock, j, 1, data_element_values.get(j).toString());
						}
					}
				}
			}

		/*	System.out.println(identifer_map);*/
			List<String> ListofSegments=read.getSheetNames();
		/*	System.out.println(ListofSegments);*/
			for(int i=0;i<ListofSegments.size();i++)
			{
				int rowcount=read.getRowCount(ListofSegments.get(i).toString());
			/*	System.out.println("The Number of Rows in the each Sheet ["+ListofSegments.get(i).toString()+"] are \t:\t"+rowcount);
				
				System.out.println(identifer_map.get(ListofSegments.get(i).toString().trim()));*/
				int IterationValue=identifer_map.get(ListofSegments.get(i).toString().trim());
				for(int iteration_count=1;iteration_count<=IterationValue;iteration_count++)
				{
					for(int rows=2;rows<=rowcount;rows++)
					{

						if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Record_ID"))
						{
							Values=ListofSegments.get(i).toString();
						/*	System.out.println("The TestData Generated for Each Column ["+read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows)+"] and the Value is ["+Values+"]");*/
						}
						else if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("party account number"))
						{
							if(iteration_count==1||iteration_count==5||iteration_count==9||iteration_count==13)
							{
								Values="535359053";
							}
							else if(iteration_count==2||iteration_count==6||iteration_count==10||iteration_count==14)
							{
								Values="708590617";
							}
							else if(iteration_count==3||iteration_count==7||iteration_count==11||iteration_count==15)
							{
								Values="545035867";
							}
							else if(iteration_count==4||iteration_count==8||iteration_count==12||iteration_count==16)
							{
								Values="701708950";
							}
							else
							{
								Values=generateData(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows),read.getCellData(ListofSegments.get(i).toString(), "TYPE", rows),Integer.parseInt(read.getCellData(ListofSegments.get(i).toString(), "Max_Size", rows)));
							}
						}
						else if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).contains("Party Address Line 1"))
						{
							Values=truncate(faker.address().streetAddress(), Integer.parseInt(read.getCellData(ListofSegments.get(i).toString(), "Max_Size", rows)));
						}
						else if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).contains("Party Address Line 2"))
						{
							Values=truncate(faker.address().secondaryAddress(), Integer.parseInt(read.getCellData(ListofSegments.get(i).toString(), "Max_Size", rows)));
						}
						else if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).contains("Party Address Line 3"))
						{
							Values=truncate(faker.address().streetSuffix(), Integer.parseInt(read.getCellData(ListofSegments.get(i).toString(), "Max_Size", rows)));
						}
						else if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Company Name"))
						{
							if(iteration_count==1||iteration_count==5||iteration_count==9||iteration_count==13)
							{
								Values="ARROW INTERNATIONAL";
							}
							else if(iteration_count==2||iteration_count==6||iteration_count==10||iteration_count==14)
							{
								Values="LEAR MEXICAN SEATING CORP";
							}
							else if(iteration_count==3||iteration_count==7||iteration_count==11||iteration_count==15)
							{
								Values="SADDLECREEK WHSE";
							}
							else if(iteration_count==4||iteration_count==8||iteration_count==12||iteration_count==16)
							{
								Values="PARAGON TRADE BRANDS % SADDLECREEK WHSE";
							}
							else
							{
								Values=faker.company().name();
							}
						}
						else if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Contact Telephone Number")  ||
								read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Contact Facsimile Line Number")  ||
								read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Company Telephone Number")
								)
						{
							Values=randomvalues.generateRandomNumber(10);
						}
						
						else if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("City"))
						{
							if(iteration_count==1||iteration_count==5||iteration_count==9||iteration_count==13)
							{
								Values="CLEVELAND";
							}
							else if(iteration_count==2||iteration_count==6||iteration_count==10||iteration_count==14)
							{
								Values="SOUTHFIELD";
							}
							else if(iteration_count==3||iteration_count==7||iteration_count==11||iteration_count==15)
							{
								Values="MACON";
							}
							else if(iteration_count==4||iteration_count==8||iteration_count==12||iteration_count==16)
							{
								Values="MACON";
							}
							else
							{
								Values=faker.address().city();
							}
						}
						else if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).contains("State"))
						{
							if(iteration_count==1||iteration_count==5||iteration_count==9||iteration_count==13)
							{
								Values="US";
							}
							else if(iteration_count==2||iteration_count==6||iteration_count==10||iteration_count==14)
							{
								Values="MI";
							}
							else if(iteration_count==3||iteration_count==7||iteration_count==11||iteration_count==15)
							{
								Values="GA";
							}
							else if(iteration_count==4||iteration_count==8||iteration_count==12||iteration_count==16)
							{
								Values="GA";
							}
							else{
							Values=faker.address().stateAbbr();
							}
							
						}
						
						else if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Postal Code"))
						{

							if(iteration_count==1||iteration_count==5||iteration_count==9||iteration_count==13)
							{
								Values="US44144";
							}
							else if(iteration_count==2||iteration_count==6||iteration_count==10||iteration_count==14)
							{
								Values="48033-4248";
							}
							else if(iteration_count==3||iteration_count==7||iteration_count==11||iteration_count==15)
							{
								Values="31201";
							}
							else if(iteration_count==4||iteration_count==8||iteration_count==12||iteration_count==16)
							{
								Values="31201";
							}
							else{
							Values=faker.address().zipCode();
							}
						}
						else if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Country Code"))
						{
							Values=faker.address().countryCode();
						}
						else if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Contact Name"))
						{
							Values=faker.address().firstName();
						}
						else if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Contact Department"))
						{
							Values=truncate(faker.commerce().department(),Integer.parseInt(read.getCellData(ListofSegments.get(i).toString(), "Max_Size", rows)));
						}
						else if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Contact Division"))
						{
							Values=truncate(faker.company().industry(),Integer.parseInt(read.getCellData(ListofSegments.get(i).toString(), "Max_Size", rows)));
						}
						else if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Contact Email Address"))
						{
							String suffix="@ups.com";
							Values=faker.name().firstName()+suffix;
						}
						else if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Total Records"))
						{
							Values= String.format("%05d", totalnumberofrecords);
						}
						else if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Commercial Location Saturday Delivery Eligibility Indicator"))
						{
							String alphabet = "10";
							Random rn = new Random();
							String myValue=Character.toString(alphabet.charAt(rn.nextInt(alphabet.length())));
						//	System.out.println(myValue);

							Values=myValue;
						}
						else if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Shipment Type Code"))
						{
							String alphabet = "ldn";
							Random rn = new Random();
							String myValue=Character.toString(alphabet.charAt(rn.nextInt(alphabet.length())));
						//	 System.out.println(myValue);
							Values=myValue;
						}
						else if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Departure Location Type Code")  ||
								read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Origin Location Type Code")  ||
								read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Arrival Location Type Code")
								)
						{
							List<String> alphabet = new ArrayList<String>();
							alphabet.add("AIRPORT");
							alphabet.add("RAIL");
							alphabet.add("OCEAN");
							alphabet.add("GROUND");
							
							
							Random rn = new Random();
							 int index = rn.nextInt(alphabet.size());

							 String item = alphabet.get(index);

							// System.out.println(item);
							Values=item;
						}
						
						else if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Document Type"))
						{
							String item = null;
							if(ListofSegments.get(i).toString().equalsIgnoreCase("SH16"))
							{
								List<String> alphabet = new ArrayList<String>();
								alphabet.add("MAWB");
								alphabet.add("STO");
								alphabet.add("SGS");
								alphabet.add("HBN");
								alphabet.add("SHBN");
								alphabet.add("SNO");
								alphabet.add("TGS");
								alphabet.add("CCD");
								alphabet.add("INB");
								alphabet.add("IMR");
								alphabet.add("MTP");
								alphabet.add("PAPS");
								alphabet.add("VOY");
								Random rn = new Random();
								int index = rn.nextInt(alphabet.size());

								item = alphabet.get(index);

								System.out.println(item);
								Values=item;
							}
							else if (ListofSegments.get(i).toString().equalsIgnoreCase("IE34"))
							{
								Values="";
							}
							else if (ListofSegments.get(i).toString().equalsIgnoreCase("GA34"))
							{
								Values="";
							}

						}
						else if (read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Consolidated Clearance Indicator")||
								read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Split Indicator") ||
								read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Export Document Flag") ||
								read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Return Shipment Indicator") ||
								read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Hazardous Material Aircraft Indicator") ||
								read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Address Correction Indicator") ||
								read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Related Party Indicator")
								)
						{
							String alphabet = "01";
							Random rn = new Random();
							String myValue=Character.toString(alphabet.charAt(rn.nextInt(alphabet.length())));
							//System.out.println(myValue);
							Values=myValue;
						}
						else if (read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Lead Shipment Indicator"))
						{
							String alphabet = "01";
							Random rn = new Random();
							String myValue=Character.toString(alphabet.charAt(rn.nextInt(alphabet.length())));
							//System.out.println(myValue);
							Values=myValue;
						}
						else if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Export Sort Type Code")  ||
								read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Import Sort Type Code")  ||
								read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Organization Number")
								)
						{
							List<String> alphabet = new ArrayList<String>();
							alphabet.add("00");
							alphabet.add("01");
							Random rn = new Random();
							 int index = rn.nextInt(alphabet.size());

							 String item = alphabet.get(index);

							// System.out.println(item);
							Values=item;
						}
						
						else if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Carrier Code Identifier"))
						{
							List<String> alphabet = new ArrayList<String>();
							alphabet.add("IATA");
							alphabet.add("SCAC");
							Random rn = new Random();
							 int index = rn.nextInt(alphabet.size());

							 String item = alphabet.get(index);

							// System.out.println(item);
							Values=item;
						}
						
						else if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Location Type Source Text"))
						{
							List<String> alphabet = new ArrayList<String>();
							alphabet.add("Schedule D Port Code");
							alphabet.add("Schedule K Port Code");
							alphabet.add("IATA Code");
							alphabet.add("UN Location Code");
							Random rn = new Random();
							 int index = rn.nextInt(alphabet.size());

							 String item = alphabet.get(index);

							// System.out.println(item);
							Values=item;
						}
						else if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Billing Term Type"))
						{
							List<String> alphabet = new ArrayList<String>();
							alphabet.add("PDC");
							alphabet.add("PDP");
							alphabet.add("PDD");
							alphabet.add("PDU");
							Random rn = new Random();
							 int index = rn.nextInt(alphabet.size());

							 String item = alphabet.get(index);

							// System.out.println(item);
							Values=item;
						}
						else if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Duty Percent")	||
								read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("CVD Duty Percent")	||
								read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("ADD Duty Percent")
								)
						{
							Random rn = new Random();
							int maximum=100;
							int minimum=0;
							int range = maximum - minimum + 1;
							int randomNum =  rn.nextInt(range) + minimum;
							Values=String.valueOf(randomNum);
						}
						else if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Trade Direct Marketing Product Type Code"))
						{
							List<String> alphabet = new ArrayList<String>();
							alphabet.add("TDC");
							alphabet.add("TDO");
							alphabet.add("TDA");
							Random rn = new Random();
							 int index = rn.nextInt(alphabet.size());

							 String item = alphabet.get(index);

							// System.out.println(item);
							Values=item;
						}
						else if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Reconciliation Applied Code"))
						{
							List<String> alphabet = new ArrayList<String>();
							alphabet.add("Y");
							alphabet.add("N");
							Random rn = new Random();
							 int index = rn.nextInt(alphabet.size());
							 String item = alphabet.get(index);
							// System.out.println(item);
							Values=item;
						}
						else if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Certificate of Origin Type Code"))
						{
							List<String> alphabet = new ArrayList<String>();
							alphabet.add("C");
							alphabet.add("TD");
							alphabet.add("T1");
							alphabet.add("T2");
							alphabet.add("X");
							Random rn = new Random();
							 int index = rn.nextInt(alphabet.size());

							 String item = alphabet.get(index);

							// System.out.println(item);
							Values=item;
						}
						else if(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows).equalsIgnoreCase("Service Type Code"))
						{
							
							if(ListofSegments.get(i).toString().equalsIgnoreCase("IE34"))
							{
							List<String> alphabet = new ArrayList<String>();
							alphabet.add("01");
							alphabet.add("02");
							alphabet.add("03");
							Random rn = new Random();
							 int index = rn.nextInt(alphabet.size());

							 String item = alphabet.get(index);

							// System.out.println(item);
							Values=item;
							}
							else if(ListofSegments.get(i).toString().equalsIgnoreCase("WB01"))
							{
								List<String> alphabet = new ArrayList<String>();
								alphabet.add("001");
								alphabet.add("002");
								alphabet.add("003");
								Random rn = new Random();
								 int index = rn.nextInt(alphabet.size());

								 String item = alphabet.get(index);

								// System.out.println(item);
								Values=item;
							}
						}
						else
						{
							Values=generateData(read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows),read.getCellData(ListofSegments.get(i).toString(), "TYPE", rows),Integer.parseInt(read.getCellData(ListofSegments.get(i).toString(), "Max_Size", rows)));
						/*	System.out.println("The TestData Generated for Each Column ["+read.getCellData(ListofSegments.get(i).toString(), "DATA_ELEMENT", rows)+"] and the Value is ["+Values+"]");*/
						}
						//read.setCellDataUsingColumnIndex(ListofSegments.get(i).toString(), iteration_count+5, rows-1, Values);
						writer.setCellDataColNo(ListofSegments.get(i).toString(),rows-2 ,iteration_count+1 , Values);
						
						if(rows==rowcount)
						{
							sb.append(Values);
						}
						else
						{
							sb.append(Values+"|");

						}
				

					}

					sb.append("\n");
				
				}
			}
			oLog.info("_______________________________");
			oLog.info(sb);
			oLog.info("_______________________________");
			
			System.out.println("_______________________________");
			System.out.println(sb);
			bw.append(sb.toString());
			System.out.println("_______________________________");
		}
		catch (IOException e) {

			e.printStackTrace();

		} 
		finally 
		{

			try 
			{

				if (bw != null)
					bw.close();

				if (fw != null)
					fw.close();
			
			}
			catch (IOException ex)
			{
				ex.printStackTrace();
			}
			
		}
		
		
		return sb.toString();
	}

	
	public static String generateData(String data_element,String type,int max_size)
	{
		String Value="";
		randomvalues= new RandomClass();

		switch(type.toLowerCase())
		{
		case "Text":
		case "text":
		case "TEXT":
			//System.out.print("And The Format given is ["+data_Type+"]");
			Value=randomvalues.generateRandomString(max_size);

			break;
		case "time":
		case "TIME":
		case "Time":
			//System.out.print("And The Format given is ["+type+"] and the format should be hhmm");
			DateFormat dateFormat = new SimpleDateFormat("HHmmss");
			Date date = new Date();
			//System.out.println(dateFormat.format(date));
			Value=dateFormat.format(date);

			break;
		case "date":
		case "DATE":
		case "Date":
			//System.out.print("And The Format given is ["+type+"] and the format should be yyyyddmm");

		//	System.out.print("And The Format given is ["+type+"] and the format should be hhmm");
			dateFormat = new SimpleDateFormat("yyyyddMM");
			date = new Date();
			System.out.println(dateFormat.format(date)); //20171509
			Value=dateFormat.format(date);
			break;

		case "Number":
		case "number":
		case "NUMBER":
			//System.out.print("And The Format given is ["+type+"]");
			Value=randomvalues.generateRandomNumber(max_size);
			break;
		}


		return Value;

	}
	
	
	public static void main(String[] arg)
	{
		GBS_MSG.test();
		//GBS_MSG1_testing gsb= new GBS_MSG1_testing();
		GBS_MSG.getConsigneeDetailsFromFlatFile();
		GBS_MSG.getShipperDetails();
		GBS_MSG.getIORDetails();
		GBS_MSG.getPayerDetails();
	}
	
	
	public static HashMap<String,String> getConsigneeDetailsFromFlatFile()
	{
		ConsigneeDetails= new HashMap<String,String>();
		Read_xls read= new Read_xls(FILENAME_Excel);
		
		ConsigneeDetails.put("ConsigneerecordType",read.getCellData("BP01", "Record_ID", 3));
		ConsigneeDetails.put("ConsigneeUniquePartyRecord",read.getCellData("BP01", "Unique Party Record Identifier Number", 3));
		ConsigneeDetails.put("ConsigneePartyAccountNumber",read.getCellData("BP01", "Party Account Number", 3));
		ConsigneeDetails.put("ConsigneeCompanyName",read.getCellData("BP01", "Company Name", 3));
		ConsigneeDetails.put("ConsigneePartyAddress1",read.getCellData("BP01", "Party Address Line 1", 3));
		ConsigneeDetails.put("ConsigneePartyAddress2",read.getCellData("BP01", "Party Address Line 2", 3));
		ConsigneeDetails.put("ConsigneePartyAddress3",read.getCellData("BP01", "Party Address Line 3", 3));
		ConsigneeDetails.put("ConsigneeCity",read.getCellData("BP01", "City", 3));
		ConsigneeDetails.put("ConsigneeState",read.getCellData("BP01", "State/Province", 3));
		ConsigneeDetails.put("ConsigneePostalcode",read.getCellData("BP01", "Postal Code", 3));
		ConsigneeDetails.put("ConsigneeCountry",read.getCellData("BP01", "Country Code", 3));
		ConsigneeDetails.put("ConsigneeTelpehone",read.getCellData("BP01", "Company Telephone Number", 3));
		ConsigneeDetails.put("ConsigneecontactName",read.getCellData("BP01", "Contact Name", 3));
		ConsigneeDetails.put("ConsigneecontactDepartment",read.getCellData("BP01", "Contact Department", 3));
		ConsigneeDetails.put("ConsigneeContactDivision",read.getCellData("BP01", "Contact Division", 3));
		ConsigneeDetails.put("ConsigneeContactEmail",read.getCellData("BP01", "Contact Email Address", 3));
		ConsigneeDetails.put("ConsigneeContactTeplehone",read.getCellData("BP01", "Contact Telephone Number", 3));
		ConsigneeDetails.put("ConsigneeContactFacsimile",read.getCellData("BP01", "Contact Facsimile Line Number", 3));
		ConsigneeDetails.put("ConsigneeCarrierCode",read.getCellData("BP01", "Carrier Code", 3));
		ConsigneeDetails.put("ConsigneeCarrierName",read.getCellData("BP01", "Carrier Name", 3));
		return ConsigneeDetails;
	}
	
	
	
	public static HashMap<String,String>  getShipperDetails()	
	{
		
		ShipperDetails= new HashMap<String,String>();
		Read_xls read= new Read_xls(FILENAME_Excel);
		
		ShipperDetails.put("ShipperrecordType",read.getCellData("BP01", "Record_ID", 2));
		ShipperDetails.put("ShipperUniquePartyRecord",read.getCellData("BP01", "Unique Party Record Identifier Number", 2));
		ShipperDetails.put("ShipperPartyAccountNumber",read.getCellData("BP01", "Party Account Number", 2));
		ShipperDetails.put("ShipperCompanyName",read.getCellData("BP01", "Company Name", 2));
		ShipperDetails.put("ShipperPartyAddress1",read.getCellData("BP01", "Party Address Line 1", 2));
		ShipperDetails.put("ShipperPartyAddress2",read.getCellData("BP01", "Party Address Line 2", 2));
		ShipperDetails.put("ShipperPartyAddress3",read.getCellData("BP01", "Party Address Line 3", 2));
		ShipperDetails.put("ShipperCity",read.getCellData("BP01", "City", 2));
		ShipperDetails.put("ShipperState",read.getCellData("BP01", "State/Province", 2));
		ShipperDetails.put("ShipperPostalcode",read.getCellData("BP01", "Postal Code", 2));
		ShipperDetails.put("ShipperCountry",read.getCellData("BP01", "Country Code", 2));
		ShipperDetails.put("ShipperTelpehone",read.getCellData("BP01", "Company Telephone Number", 2));
		ShipperDetails.put("ShippercontactName",read.getCellData("BP01", "Contact Name", 2));
		ShipperDetails.put("ShippercontactDepartment",read.getCellData("BP01", "Contact Department", 2));
		ShipperDetails.put("ShipperContactDivision",read.getCellData("BP01", "Contact Division", 2));
		ShipperDetails.put("ShipperContactEmail",read.getCellData("BP01", "Contact Email Address", 2));
		ShipperDetails.put("ShipperContactTeplehone",read.getCellData("BP01", "Contact Telephone Number", 2));
		ShipperDetails.put("ShipperContactFacsimile",read.getCellData("BP01", "Contact Facsimile Line Number", 2));
		ShipperDetails.put("ShipperCarrierCode",read.getCellData("BP01", "Carrier Code", 2));
		ShipperDetails.put("ShipperCarrierName",read.getCellData("BP01", "Carrier Name", 2));
		return ShipperDetails;
	}
	
	
	
	public static HashMap<String,String> getIORDetails()
	{
		IORDetails = new HashMap<String,String>();
		Read_xls read= new Read_xls(FILENAME_Excel);
		
		IORDetails.put("IORrecordType",read.getCellData("BP01", "Record_ID", 4));
		IORDetails.put("IORUniquePartyRecord",read.getCellData("BP01", "Unique Party Record Identifier Number", 4));
		IORDetails.put("IORPartyAccountNumber",read.getCellData("BP01", "Party Account Number", 4));
		IORDetails.put("IORCompanyName",read.getCellData("BP01", "Company Name", 4));
		IORDetails.put("IORPartyAddress1",read.getCellData("BP01", "Party Address Line 1", 4));
		IORDetails.put("IORPartyAddress2",read.getCellData("BP01", "Party Address Line 2", 4));
		IORDetails.put("IORPartyAddress3",read.getCellData("BP01", "Party Address Line 3", 4));
		IORDetails.put("IORCity",read.getCellData("BP01", "City", 4));
		IORDetails.put("IORState",read.getCellData("BP01", "State/Province", 4));
		IORDetails.put("IORPostalcode",read.getCellData("BP01", "Postal Code", 4));
		IORDetails.put("IORCountry",read.getCellData("BP01", "Country Code", 4));
		IORDetails.put("IORTelpehone",read.getCellData("BP01", "Company Telephone Number", 4));
		IORDetails.put("IORcontactName",read.getCellData("BP01", "Contact Name", 4));
		IORDetails.put("IORcontactDepartment",read.getCellData("BP01", "Contact Department", 4));
		IORDetails.put("IORContactDivision",read.getCellData("BP01", "Contact Division", 4));
		IORDetails.put("IORContactEmail",read.getCellData("BP01", "Contact Email Address", 4));
		IORDetails.put("IORContactTeplehone",read.getCellData("BP01", "Contact Telephone Number", 4));
		IORDetails.put("IORContactFacsimile",read.getCellData("BP01", "Contact Facsimile Line Number", 4));
		IORDetails.put("IORCarrierCode",read.getCellData("BP01", "Carrier Code", 4));
		IORDetails.put("IORCarrierName",read.getCellData("BP01", "Carrier Name", 4));
		return IORDetails;
		
	/*	System.out.println(IORrecordType);
		System.out.println(IORUniquePartyRecord);
		System.out.println(IORPartyAccountNumber);
		System.out.println(IORCompanyName);
		System.out.println(IORPartyAddress1);
		System.out.println(IORPartyAddress2);
		System.out.println(IORPartyAddress3);
		System.out.println(IORCity);
		System.out.println(IORState);
		System.out.println(IORPostalcode);
		System.out.println(IORCountry);
		System.out.println(IORTelpehone);
		System.out.println(IORcontactName);
		System.out.println(IORcontactDepartment);
		System.out.println(IORContactDivision);
		System.out.println(IORContactEmail);
		System.out.println(IORContactTeplehone);
		System.out.println(IORContactFacsimile);
		System.out.println(IORCarrierCode);
		System.out.println(IORCarrierName);*/
	
	}
	
	public static HashMap<String,String> getPayerDetails()
	{
		PayerDetails = new HashMap<String,String>();
		Read_xls read= new Read_xls(FILENAME_Excel);
		
		PayerDetails.put("PayerrecordType",read.getCellData("BP01", "Record_ID", 5));
		PayerDetails.put("PayerUniquePartyRecord",read.getCellData("BP01", "Unique Party Record Identifier Number", 5));
		PayerDetails.put("PayerPartyAccountNumber",read.getCellData("BP01", "Party Account Number", 5));
		PayerDetails.put("PayerCompanyName",read.getCellData("BP01", "Company Name", 5));
		PayerDetails.put("PayerPartyAddress1",read.getCellData("BP01", "Party Address Line 1", 5));
		PayerDetails.put("PayerPartyAddress2",read.getCellData("BP01", "Party Address Line 2", 5));
		PayerDetails.put("PayerPartyAddress3",read.getCellData("BP01", "Party Address Line 3", 5));
		PayerDetails.put("PayerCity",read.getCellData("BP01", "City", 5));
		PayerDetails.put("PayerState",read.getCellData("BP01", "State/Province", 5));
		PayerDetails.put("PayerPostalcode",read.getCellData("BP01", "Postal Code", 5));
		PayerDetails.put("PayerCountry",read.getCellData("BP01", "Country Code", 5));
		PayerDetails.put("PayerTelpehone",read.getCellData("BP01", "Company Telephone Number", 5));
		PayerDetails.put("PayercontactName",read.getCellData("BP01", "Contact Name", 5));
		PayerDetails.put("PayercontactDepartment",read.getCellData("BP01", "Contact Department", 5));
		PayerDetails.put("PayerContactDivision",read.getCellData("BP01", "Contact Division", 5));
		PayerDetails.put("PayerContactEmail",read.getCellData("BP01", "Contact Email Address", 5));
		PayerDetails.put("PayerContactTeplehone",read.getCellData("BP01", "Contact Telephone Number", 5));
		PayerDetails.put("PayerContactFacsimile",read.getCellData("BP01", "Contact Facsimile Line Number", 5));
		PayerDetails.put("PayerCarrierCode",read.getCellData("BP01", "Carrier Code", 5));
		PayerDetails.put("PayerCarrierName",read.getCellData("BP01", "Carrier Name", 5));
		
		return PayerDetails;
	
	}
	
	public static String truncate(String value, int length)
	{
	  if (value != null && value.length() > length)
	    value = value.substring(0, length);
	  return value;
	}

}
