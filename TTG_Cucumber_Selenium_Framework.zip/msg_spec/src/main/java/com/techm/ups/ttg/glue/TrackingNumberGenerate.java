package com.techm.ups.ttg.glue;



import static org.testng.Assert.assertEquals;
import groovy.lang.Lazy;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;







import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import junit.framework.Assert;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.github.mkolisnyk.cucumber.assertions.LazyAssert;
import com.google.common.io.Files;
import com.techm.ups.ttg.utils.Read_xls;
import com.techm.ups.ttg.utils.Wrapper;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class TrackingNumberGenerate {
	private Logger oLog = Logger.getLogger(TrackingNumberGenerate.class);
	static DateFormat dateFormat = new SimpleDateFormat("dd_mm_yyyy_hh_mm");
	static Date date = new Date();

	static String dateformates=dateFormat.format(date);
	private static final String unique_trackingNumber = "D:\\Chandrakanth\\TTG\\xpath_"+dateformates+".txt";

	static StringBuilder sb;

	static BufferedWriter bw = null;
	static FileWriter fw=null;
	public Wrapper mywrapper= new Wrapper();
	public static HashMap<Integer, String> generateTrackingNumber = new HashMap<Integer, String>();
	public static List<String> uniqueTrackingNumber = new ArrayList<String>();
	public static List<String> ExistingTrackingNumber = new ArrayList<String>();
	public static String selectedTrackingNumber;
	//static String generateTrackingNumber=System.getProperty("user.dir")+"/src/test/resources/TestData/HMMS_Application.xlsx";

	@Given("^Enter valid credentials in HMMS Application$")
	public void enter_valid_credentails() throws  InterruptedException
	{
		System.out.println("Enter the Valid Credentials");
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("hmms_username_textbox"),BaseClass.datamap.get(BaseClass.tempindex).get("username"));
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("hmms_password_textbox"),BaseClass.datamap.get(BaseClass.tempindex).get("password"));
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("hmms_login_button"));
		mywrapper.hardWait(5000);		
	}


	@Given("^Enter valid to generate Tracking Number$")
	public void enter_valid_data_to_generate_trackingMumber() throws InterruptedException
	{
		mywrapper.hardWait(5000);
		System.out.println("Enter the Valid Credentials");
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("trackinggen_quantity_textbox"),BaseClass.datamap.get(BaseClass.tempindex).get("Quantity"));
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("trackinggen_shippernumber_textbox"),BaseClass.datamap.get(BaseClass.tempindex).get("Shipper_Number"));
		mywrapper.SelectUsingValue(BaseClass.driver,BaseClass.OBJECT.getProperty("trackinggen_servicecode_listbox"),BaseClass.datamap.get(BaseClass.tempindex).get("Service_Code"));
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("trackinggen_idnumber_textbox"),BaseClass.datamap.get(BaseClass.tempindex).get("ID_Number"));
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("trackinggen_generate_button"));


		System.out.println("Clicked generate button successfully");
	}


	@Then("^store the tracking number$")
	public void getTrackingNumber() throws InterruptedException
	{
		//Read_xls read= new Read_xls(generateTrackingNumber);
		mywrapper.hardWait(5000);
		String trackingNumber=mywrapper.getText(BaseClass.driver,BaseClass.OBJECT.getProperty("trackinggen_results_textarea"));
		String[] values=trackingNumber.split("\n");
		for(int i=0;i<values.length;i++)
		{
			generateTrackingNumber.put(i, values[i]);
			System.out.println(values[i]);
			/*read.setCellData("TrackingNumber_Generator", "Results", 2, values[i]);
			read.setCellData("SmallPackageShip_Maintenance", "ShipmentNumber", 2, values[i]);*/

		}
	}


	@Then("^Navigate to create shipment$")
	public void navigate_to_Shipment() throws InterruptedException
	{
		mywrapper.click(BaseClass.driver,"//a[text()='Create']");
		mywrapper.hardWait(5000);

	}

	@Then("^Navigate to locate shipment$")
	public void navigate_to_locate_Shipment() throws InterruptedException
	{
		mywrapper.click(BaseClass.driver,"//span[text()='Small Package']/ancestor::table[1]/following-sibling::div[1]//a[text()='Locate']");
		mywrapper.hardWait(5000);

	}
	
	@Then("^Enter generated tracking number and validate that tracking number is not available into the Database$")
	public void validateGenerateTrackingNumber() throws InterruptedException
	{
		
		int count=generateTrackingNumber.size();
		for(int i=0;i<count;i++)
		{
			String shipmentNumber=generateTrackingNumber.get(i).toString();
			
			mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("locateshipment_trackingnumber_textbox"),shipmentNumber);
			mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("locateshipment_startdate_textbox"),"01/01/1753");
			mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("locateshipment_enddate_textbox"),"01/01/2500");
			mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("locateshipment_search_button"));
			mywrapper.hardWait(2000);
			try
			{
				List<WebElement> rwcount=BaseClass.driver.findElements(By.xpath("//table[@id='ctl00_bodyContent_uSmPkgLocateGrid']//tr"));
				if(rwcount.size()==1)
				{
					System.out.println("The current value is not available into the database");
					uniqueTrackingNumber.add(shipmentNumber);
					break;
				}
				else if(rwcount.size()>1)
				{
					System.out.println("Tracking Number ["+shipmentNumber+"] is already present into the Database.");
					ExistingTrackingNumber.add(shipmentNumber);
				}
			}
			catch(Exception e)
			{
			///
			}
			
		}
		
	if(ExistingTrackingNumber.size()==count)
	{
		System.out.println("All Shipment Number generated Already present into database. Please change the ID Number Value or Service Code");
	}
	
		
	}
	
	
	
	@Then("^Enter generated tracking number and validate that tracking number is available into the Database$")
	public void validatecreatedShipmentNumber() throws InterruptedException
	{
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("locateshipment_trackingnumber_textbox"),selectedTrackingNumber);
		//mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("locateshipment_startdate_textbox"),"01/01/1753");
		//mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("locateshipment_enddate_textbox"),"01/01/2500");
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("locateshipment_search_button"));
		mywrapper.hardWait(2000);
		try
		{
			List<WebElement> rwcount=BaseClass.driver.findElements(By.xpath("//table[@id='ctl00_bodyContent_uSmPkgLocateGrid']//tr"));
			if(rwcount.size()==1)
			{
				System.out.println("The current value is not available into the database");
				oLog.error("The Created Tracking Number["+selectedTrackingNumber+"] is not added into the Database");
				//Assert.fail("The Created Tracking Number["+selectedTrackingNumber+"] is not added into the Database");
				LazyAssert.fail("The Created Tracking Number["+selectedTrackingNumber+"] is not added into the Database");
			}
			else if(rwcount.size()>1)
			{
				System.out.println("Tracking Number ["+selectedTrackingNumber+"] is added into the Database.");
				oLog.info("The Created Tracking Number["+selectedTrackingNumber+"] is added into the Database");
				//LazyAssert.assertTrue("The Created Tracking Number["+selectedTrackingNumber+"] is added into the Database");
			}
		}
		catch(Exception e)
		{
			///
		}


	}
	
	
	@Then("^Enter the required fields in the Small Package Shipment Maintenance screen$")
	public void valid_details() throws InterruptedException
	{
		
		//uniqueTrackingNumber
		Random random = new Random();
		String TrackingNumberValue=uniqueTrackingNumber.get(random.nextInt(uniqueTrackingNumber.size())).toString();
		selectedTrackingNumber=uniqueTrackingNumber.get(0).toString();
		System.out.println(TrackingNumberValue);
		oLog.info("Tracking Number is ["+TrackingNumberValue+"]");
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("smallpackageshipmaintenance_shipmentnumber_textbox"),selectedTrackingNumber);
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("smallpackageshipmaintenance_packageweightvalue_textbox"),BaseClass.datamap.get(BaseClass.tempindex).get("PackageWeight"));
		mywrapper.SelectUsingText(BaseClass.driver,BaseClass.OBJECT.getProperty("smallpackageshipmaintenance_packageweightunit_dropdown"),BaseClass.datamap.get(BaseClass.tempindex).get("PackageUnit"));
		mywrapper.SelectUsingText(BaseClass.driver,BaseClass.OBJECT.getProperty("smallpackageshipmaintenance_aircraftlimitation_dropdown"),BaseClass.datamap.get(BaseClass.tempindex).get("AircraftLimitation"));
		mywrapper.hardWait(5000);
		try{
			String errormessage=mywrapper.getText(BaseClass.driver, BaseClass.OBJECT.getProperty("smallpackageshipmaintenance_error_message_label"));
			System.out.println(errormessage);
			oLog.info("Error Message is ["+errormessage+"]");
			if(errormessage.trim().equalsIgnoreCase("Chemical Table Type could not be determined. Validations will not run until a selection is made."))
			{
				mywrapper.SelectUsingText(BaseClass.driver,BaseClass.OBJECT.getProperty("smallpackageshipmaintenance_regulationset_dropdown"),BaseClass.datamap.get(BaseClass.tempindex).get("RegulationSet"));
				mywrapper.hardWait(5000);
				mywrapper.SelectUsingText(BaseClass.driver,BaseClass.OBJECT.getProperty("smallpackageshipmaintenance_chemicaltable_dropdown"),BaseClass.datamap.get(BaseClass.tempindex).get("ChemicalTable"));
			}
		}
		catch(Exception e)
		{
			///
		}
		//System.out.println("here");

	}


	@And("^Click on the Add Basic Description button$")
	public void clickonAddBAsicDescription() throws InterruptedException
	{
		mywrapper.hardWait(5000);
		mywrapper.javascriptEx_Click(BaseClass.driver,"//input[@value='Add Basic Description' and @type='submit']");
		mywrapper.hardWait(5000);
	}


	@Then("^Search for the UNID and select the UNID$")
	public void searchUNID() throws InterruptedException
	{
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("chemicaltablesearch_unid_textbox"),BaseClass.datamap.get(BaseClass.tempindex).get("UNID"));
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("chemicaltablesearch_search_button"));
		mywrapper.hardWait(5000);
		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("chemicaltablesearch_select_link"));
		mywrapper.hardWait(5000);
	}

	@Then("^Enter the Values into the required fields of Shipment Basic Description popup window$")
	public void enter_required_values_basicdesc() throws InterruptedException
	{
		mywrapper.SelectUsingText(BaseClass.driver,BaseClass.OBJECT.getProperty("shipmentbasicdescription_proper_dropdown"),BaseClass.datamap.get(BaseClass.tempindex).get("Proper"));
		mywrapper.hardWait(3000);
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("shipmentbasicdescription_packagecount_textbox"),BaseClass.datamap.get(BaseClass.tempindex).get("PackingCount"));
		mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("shipmentbasicdescription_netquantity_textbox"),BaseClass.datamap.get(BaseClass.tempindex).get("NetQuantity"));
		mywrapper.SelectUsingText(BaseClass.driver,BaseClass.OBJECT.getProperty("shipmentbasicdescription_packageunits_dropdown"),BaseClass.datamap.get(BaseClass.tempindex).get("NetQuantityUnits"));
		mywrapper.SelectUsingText(BaseClass.driver,BaseClass.OBJECT.getProperty("shipmentbasicdescription_packagetype_dropdown"),BaseClass.datamap.get(BaseClass.tempindex).get("PackageType"));

		mywrapper.click(BaseClass.driver,BaseClass.OBJECT.getProperty("shipmentbasicdescription_save_button"));

		mywrapper.hardWait(5000);

	}
	
	@Then("^Validate the Audit Status shows as \"(.*?)\"$")
	public void validateAuditStatus(String StatusValue)
	{
		String actualValue=mywrapper.getTextBoxValue(BaseClass.driver, BaseClass.OBJECT.getProperty("smallpackageshipmaintenance_auditstatus_label")).trim().toString();
		if(StatusValue.equalsIgnoreCase(actualValue))
		{
			oLog.info("Audit Status is ["+StatusValue+"]");
		}
		else
		{
			oLog.error("Audit Status is Failed. The Expected is["+StatusValue+"] But the Actual Audit Status shows as ["+actualValue+"]");
		}
		
		
	}
	
	@Then("^Click Accept and accept the certificate$")
	public void clickAcceptandClickAcceptCertificate() throws InterruptedException
	{
		mywrapper.click(BaseClass.driver,"//input[@value='Accept']");
		mywrapper.hardWait(3000);
		try
		{
			WebDriverWait AlertWait=new WebDriverWait(BaseClass.driver,30);
			AlertWait.until(ExpectedConditions.alertIsPresent());
			mywrapper.AcceptAlertIfPresent(BaseClass.driver);
		}
		catch(Exception e)
		{

		}
	}
}
