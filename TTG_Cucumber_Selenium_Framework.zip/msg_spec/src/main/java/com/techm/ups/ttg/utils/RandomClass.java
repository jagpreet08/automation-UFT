package com.techm.ups.ttg.utils;

import org.apache.commons.lang.RandomStringUtils;

public class RandomClass {

	
	
	public String generateRandomString(int length){
	    return RandomStringUtils.randomAlphabetic(length);
	} 

	//for numbers
	public String generateRandomNumber(int length){
	    return RandomStringUtils.randomNumeric(length);
	}  

}
