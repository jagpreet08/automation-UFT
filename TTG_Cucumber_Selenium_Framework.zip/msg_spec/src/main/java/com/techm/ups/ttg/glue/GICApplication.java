package com.techm.ups.ttg.glue;



import static org.testng.Assert.assertSame;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.fail;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;







import java.nio.file.Paths;
import java.util.Scanner;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.asserts.SoftAssert;

import com.github.mkolisnyk.cucumber.assertions.LazyAssert;
import com.github.mkolisnyk.cucumber.assertions.LazyAssertionError;
import com.google.common.io.Files;
import com.techm.ups.ttg.config.GBS_MSG;
import com.techm.ups.ttg.utils.Wrapper;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import java.awt.datatransfer.*;
import java.awt.event.KeyEvent;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
public class GICApplication {


	public Wrapper mywrapper= new Wrapper();

	public static String flatfile_value;
	@Given("^create Flat file creation$")
	public void create_flate_file()
	{
		try
		{
			flatfile_value=GBS_MSG.test();
			//	flatfile_value=GBS_MSG.test();
			System.out.println(flatfile_value);

			GBS_MSG.getShipperDetails();
			GBS_MSG.getConsigneeDetailsFromFlatFile();
			GBS_MSG.getIORDetails();
			GBS_MSG.getPayerDetails();
			BaseClass.verificationErrors.append(flatfile_value);
			BaseClass.status=true;

		}
		catch(Exception e)
		{
			BaseClass.verificationErrors.append(e);
			BaseClass.status=false;
		}


	}
	@Given("^enter valid credentials$")
	public void enter_valid_credentails() throws Throwable 
	{
		try
		{
			System.out.println("Enter the Valid Credentials");
			mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("gic_username_textbox"),BaseClass.datamap.get(BaseClass.tempindex).get("username"));
			mywrapper.clearAndSendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("gic_password_textbox"),BaseClass.datamap.get(BaseClass.tempindex).get("password"));
			mywrapper.javascriptEx_Click(BaseClass.driver,BaseClass.OBJECT.getProperty("gic_login_button"));
			mywrapper.hardWait(5000);	
			BaseClass.status=true;
		}
		catch(Exception e)
		{
			BaseClass.verificationErrors.append(e);
			BaseClass.status=false;
		}
	}

	@Then("^Click on the Test Facility Image$")
	public void click_on_the_test_facility_image() throws InterruptedException
	{
		try
		{
			mywrapper.hardWait(5000);
			mywrapper.javascriptEx_Click(BaseClass.driver, BaseClass.OBJECT.getProperty("gic_yourapplication_testfacility_button"));

		}
		catch(Exception e)
		{
			BaseClass.verificationErrors.append(e);
			BaseClass.status=false;
		}
	}

	@And("^Navigate to Test Facility Test Screen$")
	public void navigate_to_test_facility_test_Screen() throws InterruptedException
	{try
	{
		mywrapper.SwitchToWindowViaWindowTitle(BaseClass.driver, "Test Facility");

		mywrapper.hardWait(5000);
	}
	catch(Exception e)
	{
		BaseClass.verificationErrors.append(e);
		BaseClass.status=false;
	}
	}

	@Then("^Enter the required Fields in the Test Facility screen at Test Tab$")
	public void enter_required_fields_in_testTab() throws InterruptedException
	{
		try
		{
			mywrapper.SelectUsingText(BaseClass.driver, BaseClass.OBJECT.getProperty("gic_test_environment_listbox"), BaseClass.datamap.get(BaseClass.tempindex).get("Environment"));
			mywrapper.hardWait(5000);
			//mywrapper.waitForElementtobeSelected(BaseClass.driver, BaseClass.OBJECT.getProperty("gic_test_jmsQueueAlias_listbox"), 30, 5);
			//	mywrapper.SelectUsingText(BaseClass.driver, BaseClass.OBJECT.getProperty("gic_test_jmsQueueAlias_listbox"), BaseClass.datamap.get(BaseClass.tempindex).get("JMS_Queue_Alias"));
			mywrapper.SelectUsingText(BaseClass.driver, BaseClass.OBJECT.getProperty("gic_test_sourcelocationid_listbox"), BaseClass.datamap.get(BaseClass.tempindex).get("Source_LocationID"));
			//mywrapper.hardWait(5000);
			//mywrapper.SelectUsingText(BaseClass.driver, BaseClass.OBJECT.getProperty("gic_test_targetlocationid_listbox"), BaseClass.datamap.get(BaseClass.tempindex).get("Destination_LocationID"));
		}
		catch(Exception e)
		{
			BaseClass.verificationErrors.append(e);
			BaseClass.status=false;
		}
	}
	@And("^Upload the Flatfile and send to the GIC Application$")
	public void upload_flatFile() throws Exception
	{
		try{
			mywrapper.hardWait(2000);
			/*mywrapper.javascriptEx_Click(BaseClass.driver, "//input[@value='Upload Payload']");
		//mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("gic_test_uploadPayload_button"));
		mywrapper.hardWait(5000);
		//WebElement element = BaseClass.driver.findElement(By.xpath("//input[@id='uploadPanel_Form:j_id273']"));
		WebElement element = BaseClass.driver.findElement(By.xpath("//input[@id='uploadPanel_Form:j_id273']"));
		Actions builder = new Actions(BaseClass.driver);

		builder.doubleClick(element).perform();
		mywrapper.hardWait(5000);
		try {
			//Process p=Runtime.getRuntime().exec("D:\\commandLine.exe"+" D:/GBSP_MS_FLAT_FILE_QA_DATA.txt");
			//Process p=Runtime.getRuntime().exec("D:\\from_testing.exe"+GBS_MSG1_testing.FILENAME);
			Process p=Runtime.getRuntime().exec("D:\\Demo\\upload.exe"+" "+"D:\\GBSP_MS_FLAT_FILE_QA_DATA.txt");
			p.waitFor();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

			 */
			mywrapper.click(BaseClass.driver, BaseClass.OBJECT.getProperty("gic_test_payload_textarea"));
			WebElement element = BaseClass.driver.findElement(By.xpath(BaseClass.OBJECT.getProperty("gic_test_payload_textarea")));
			Actions builder = new Actions(BaseClass.driver);
			builder.click(element).build().perform();
			copy(GBS_MSG.sb.toString().trim());
			mywrapper.javascriptEx_Click(BaseClass.driver,BaseClass.OBJECT.getProperty("gic_test_payload_textarea"));
			paste();
			mywrapper.hardWait(4000);
			mywrapper.javascriptEx_Click(BaseClass.driver,BaseClass.OBJECT.getProperty("gic_test_generateMetaData_button"));
			mywrapper.hardWait(4000);
			mywrapper.javascriptEx_Click(BaseClass.driver,BaseClass.OBJECT.getProperty("gic_test_send_button"));
			mywrapper.hardWait(4000);
			System.out.println(mywrapper.getText(BaseClass.driver, "//span/ul/li[contains(text(),'Message sent successfully for TrackingID')]").split("TrackingID: ")[1].split("to ENV:")[0].trim());
			String Value=mywrapper.getText(BaseClass.driver, "//span/ul/li[contains(text(),'Message sent successfully for TrackingID')]").split("TrackingID: ")[1].split("to ENV:")[0].trim();
			BaseClass.verificationErrors.append("The Tracking Number is ["+Value+"]");
			System.out.println("completed");

			
			mywrapper.hardWait(2000);
			/*	mywrapper.javaScriptExec_SendKeys(BaseClass.driver,BaseClass.OBJECT.getProperty("gic_test_payload_textarea"),flatfile_value);
		mywrapper.hardWait(2000);
		System.out.println("complted");
			mywrapper.close(BaseClass.driver);
			mywrapper.hardWait(2000);
			mywrapper.SwitchToWindowViaWindowTitle(BaseClass.driver, "GICMiddleware");*/
			BaseClass.status=true;
		}
		catch(Exception e)
		{
			BaseClass.verificationErrors.append(e);
			BaseClass.status=false;
		}
	}

	@Then("^Click Logout$")
	public void click_logout() throws InterruptedException
	{
		try
		{
			mywrapper.hardWait(2000);
			mywrapper.javascriptEx_Click(BaseClass.driver, "//a[@id='menuLogoutId']");
			mywrapper.hardWait(5000);
			mywrapper.SwitchToDefaultWindow(BaseClass.driver);
			BaseClass.status=true;
		}
		catch(Exception e)
		{
			BaseClass.verificationErrors.append(e);
			BaseClass.status=false;
		}
	}
	public static void copy(String text)
	{
		Clipboard clipboard = getSystemClipboard();

		clipboard.setContents(new StringSelection(text), null);
	}

	public static void paste() throws AWTException
	{
		Robot robot = new Robot();

		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyRelease(KeyEvent.VK_V);
	}

	public static String get() throws Exception
	{
		Clipboard systemClipboard = getSystemClipboard();
		DataFlavor dataFlavor = DataFlavor.stringFlavor;

		if (systemClipboard.isDataFlavorAvailable(dataFlavor))
		{
			Object text = systemClipboard.getData(dataFlavor);
			return (String) text;
		}

		return null;
	}
	private static Clipboard getSystemClipboard()
	{
		Toolkit defaultToolkit = Toolkit.getDefaultToolkit();
		Clipboard systemClipboard = defaultToolkit.getSystemClipboard();

		return systemClipboard;
	}

}
