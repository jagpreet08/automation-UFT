package com.techm.ups.ttg.config;

import java.util.List;

import org.testng.annotations.BeforeClass;

import com.techm.ups.ttg.utils.Read_xls;

public class Creation_ExcelSheet {

	
	Read_xls read= new Read_xls("D:\\Chandrakanth\\TTG\\TTG_FRAMEWORK_3.xls");
	
	@BeforeClass
	public void createExcel()
	{
		
		List<String> ListofSegments=read.getSheetNames();
		System.out.println(ListofSegments);
		for(int i=0;i<ListofSegments.size();i++)
		{
			
		}
	}
}
