package com.techm.ups.ttg.glue;




import static org.testng.Assert.fail;
import gherkin.formatter.Formatter;
import gherkin.formatter.Reporter;
import gherkin.formatter.model.Background;
import gherkin.formatter.model.Examples;
import gherkin.formatter.model.Feature;
import gherkin.formatter.model.Match;
import gherkin.formatter.model.Result;
import gherkin.formatter.model.ScenarioOutline;
import gherkin.formatter.model.Step;

import java.awt.Dimension;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.junit.AfterClass;
import org.openqa.selenium.Alert;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.internal.ElementScrollBehavior;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
/*
import static org.monte.media.AudioFormatKeys.*;
import static org.monte.media.VideoFormatKeys.*;

import org.monte.media.Format;
import org.monte.media.math.Rational;
import org.monte.screenrecorder.ScreenRecorder;*/



















import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;











import com.google.common.collect.Lists;
//import com.techm.ups.ttg.utils.SpecializedScreenRecorder;
import com.techm.ups.ttg.utils.Wrapper;
import com.techm.ups.ttg.utils.DataHelper;;

public class BaseClass 
{
	public static Scenario scenario;
	static StringBuilder verificationErrors;
	static StringBuilder createHTMLFile = new StringBuilder();
	static Boolean status;
	Wrapper mywrap= new Wrapper();
	String CurrentMarket;
	int index=0;
	public static int tempindex;
	public static List<HashMap<String,String>> datamap;
	private Logger oLog = Logger.getLogger(BaseClass.class);
	//private ScreenRecorder screenRecorder;
	public static WebDriver driver;
	public static String testResultsFIle;
//	public List<HashMap<String,String>> datamap;
	
	File file,file2,file3;
	public static Properties CONFIG ;
	public static Properties OBJECT;
	public static Properties CONSTANTS;
	public BaseClass() throws ClassNotFoundException
	{
		
	//	System.out.println(ClassLoader.getSystemResource("log4j2.yml")); //Check if file is available in CP
		ClassLoader cl = Thread.currentThread().getContextClassLoader(); //Code as in log4j2 API. Version: 2.8.1
		 String [] classes = {"com.fasterxml.jackson.databind.ObjectMapper",
		 "com.fasterxml.jackson.databind.JsonNode",
		 "com.fasterxml.jackson.core.JsonParser",
		 "com.fasterxml.jackson.dataformat.yaml.YAMLFactory"};

		 for(String className : classes) {
		     cl.loadClass(className);
		 }
		PropertyConfigurator.configure(System.getProperty("user.dir")+"/src/main/java/com/techm/ups/ttg/config/log4j.properties");
		file = new File(System.getProperty("user.dir")+"/src/main/java/com/techm/ups/ttg/config/config.properties");
		file2 = new File(System.getProperty("user.dir")+"/src/test/resources/Applicationconfig/object.properties");
		file3 = new File(System.getProperty("user.dir")+"/src/main/java/com/techm/ups/ttg/config/constant.properties");
		FileInputStream fis = null;
		FileInputStream fis2 = null;
		FileInputStream fis3 = null;
		try {
			fis = new FileInputStream(file);
			fis2 = new FileInputStream(file2);
			fis3 = new FileInputStream(file3);
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
		CONFIG = new Properties();
		OBJECT= new Properties();
		CONSTANTS= new Properties();
		try {
			CONFIG.load(fis);
			OBJECT.load(fis2);
			CONSTANTS.load(fis3);
		} catch (IOException e) {

			e.printStackTrace();
		}

	}
	


	
		
	
    public static String getCurrentDateTime() {

		DateFormat dateFormat = new SimpleDateFormat("_yyyy-MM-dd_HH-mm-ss");
		Calendar cal = Calendar.getInstance();
		String time = "" + dateFormat.format(cal.getTime());
		return time;
	}

	public static String getCurrentDate() {
		return getCurrentDateTime();
	}
    
	public WebDriver standAloneStepUp(String bType) throws Exception {
		try {
			oLog.info(bType);

			switch (bType) {

			case "Chrome":
				driver= getChromeDriver(getChromeCapabilities());
				return driver;
			case "Firefox":
				driver= getFirefoxDriver(getFirefoxCapabilities());
				return driver;

			case "ie":
			case "IE":
			//	driver= getIExplorerDriver(getIExplorerCapabilities());
				driver= getIExplorerDriver(getIExplorerCapabilities());
				return driver;
				

			default:
				/*throw new NoSutiableDriverFoundException(" Driver Not Found : "
						+ ObjectRepo.reader.getBrowser());*/
				return driver;
			}
		} catch (Exception e) {
			oLog.equals(e);
			throw e;
		}
	}
	
	@Before
	public void before(Scenario scenario) throws Exception {
		Wrapper.killIEProcess();
		BaseClass.scenario=scenario;
		System.out.println(BaseClass.scenario.getName());
		
		/*  List<Step> stepList = Lists.newArrayList(); 
          
          for (Step step : stepList) 
        	  System.out.println( step.getName());*/

		oLog.info("Upcoming Test: "+scenario.getSourceTagNames());
		System.out.println("Upcoming Test: "+scenario.getSourceTagNames());
		verificationErrors  = new StringBuilder();
		createHTMLFile= new StringBuilder();
		status=false;
		
		/* newtable(createHTMLFile.toString());*/
		setUpDriver(CONFIG.getProperty("Browser"));
		oLog.info(CONFIG.getProperty("Browser"));
	//	startRecording();
	}

	public static void newtable() throws IOException
	{
		createHTMLFile= new StringBuilder();
	    //verificationErrors.append(a);
		
	//	createHTMLFile.append("<html><body bgcolor=\"#E6E6FA\">");
		createHTMLFile.append("<h1> <center><b> VALIDATION WITH REPECTIVE TO FLAT FILE VALUE WITH BDM APPLICATION </b></center> </h1>");
		createHTMLFile.append("<table border=\"2\" bordercolor=\"#000000\">");
		createHTMLFile.append("<tr bgcolor=\"yellow\"><th><b>Field Name</b></th>");
		createHTMLFile.append("<th><b>Flat File Value </b></th>");
		createHTMLFile.append("<th><b>BDM Application Value</b></th>");
		createHTMLFile.append("<th><b>Status</b></th></tr>");
		//createHTMLFile.append("</body></html>");
	//    addrow(createHTMLFile.toString());
	      WriteToFile(createHTMLFile.toString(),"Validation.html");
	}	
	
	public static void newtable_BDMValues() throws IOException
	{
	//	createHTMLFile= new StringBuilder();
	    //verificationErrors.append(a);
		
	//	createHTMLFile.append("<html><body bgcolor=\"#E6E6FA\">");
		createHTMLFile.append("<h1> <center><b> Fields Present in the BDM Application</b></center> </h1>");
		createHTMLFile.append("<table border=\"2\" bordercolor=\"#000000\">");
		createHTMLFile.append("<tr bgcolor=\"yellow\"><th><b>Field Name</b></th>");
		createHTMLFile.append("<th><b>BDM Application Value</b></th>");
		//createHTMLFile.append("</body></html>");
	//    addrow(createHTMLFile.toString());
	      WriteToFile(createHTMLFile.toString(),"Validation.html");
	}	
	public static void addrow(String ColumnName,Object object2,String BDMApplicationValue,String Status) throws IOException
	{
		createHTMLFile.append("<tr><td><b>"+ColumnName+"</b></td>");
		createHTMLFile.append("<td><center>"+object2+"</center></td>");
		createHTMLFile.append("<td><center>"+BDMApplicationValue+"</center></td>");
		if(Status.equalsIgnoreCase("pass"))
		{
		createHTMLFile.append("<td bgcolor=\"green\"><b><center>"+Status+"</center></b></td></tr>");
		}
		else if(Status.equalsIgnoreCase("fail"))
		{
			createHTMLFile.append("<td bgcolor=\"red\"><b><center>"+Status+"</center></b></td></tr>");
		}
		
	        WriteToFile(createHTMLFile.toString(),"Validation.html");
	   
	}

	public static void addrowBDMValues(String ColumnName,String BDMApplicationValue) throws IOException
	{
		createHTMLFile.append("<tr><td><b>"+ColumnName+"</b></td>");
		createHTMLFile.append("<td><center>"+BDMApplicationValue+"</center></td>");
        WriteToFile(createHTMLFile.toString(),"Validation.html");
	}
	
	public static void WriteToFile(String fileContent, String fileName) throws IOException {
	  
	    String workspaceFolder=System.getProperty("user.dir")+"/target/";
	    System.out.println(workspaceFolder);
	    String tempFile = workspaceFolder + File.separator+fileName;
	  //  FileOutputStream fos =new FileOutputStream(tempFile, true) ;
	    File file = new File(tempFile);
	    // if file does exists, then delete and create a new file
	          //write to file with OutputStreamWriter
	    OutputStream outputStream = new FileOutputStream(file.getAbsoluteFile());
	    Writer writer=new OutputStreamWriter(outputStream);
	    writer.write(fileContent);
	    writer.close();

	}

	/*public static void newtable(String a) throws IOException
	{
	   
	    //verificationErrors.append(a);
		createHTMLFile.append("<h1> Issues Found </h1>");
		createHTMLFile.append("<table border=\"1\" bordercolor=\"#000000\">");
		createHTMLFile.append("<tr><td><b>Column Name</b></td>");
		createHTMLFile.append("<td><b>Flat File Value </b></td>");
		createHTMLFile.append("<td><b>BDM Application Value</b></td></tr>");
	//    addrow(createHTMLFile.toString());
	      WriteToFile(createHTMLFile.toString(),"log.html");
	}	
	public static void addrow(String ColumnName,Object object2,String BDMApplicationValue,String Status)
	{
	        verificationErrors.append("<tr><td><b>"+ColumnName+"</b></td>");
	        verificationErrors.append("<tr><td><b>"+object2+"</b></td>");
	        verificationErrors.append("<tr><td><b>"+BDMApplicationValue+"</b></td>");
	        verificationErrors.append("<tr><td><b>"+Status+"</b></td>");
	     //   WriteToFile(verificationErrors.toString(),"log.html");
	   
	}

	
	public static void WriteToFile(String fileContent, String fileName) throws IOException {
	    String projectPath = "/home/abc";
	    String tempFile = projectPath + File.separator+fileName;
	    File file = new File(tempFile);
	    // if file does exists, then delete and create a new file
	          //write to file with OutputStreamWriter
	    OutputStream outputStream = new FileOutputStream(file.getAbsoluteFile());
	    Writer writer=new OutputStreamWriter(outputStream);
	    writer.write(fileContent);
	    writer.close();

	}*/
	@After
	public void after(Scenario scenario) throws Exception {
		tearDownDriver(scenario);
		 scenario.write(verificationErrors.toString());
		 
		if (!(verificationErrors.length()==0)) 
		{
			 scenario.write(verificationErrors.toString());
			 if(!status)
			 {
				 fail(verificationErrors.toString());
			 }
			
		}
		oLog.info("Test Complete: " + scenario.getSourceTagNames() + " Status: " + scenario.getStatus());
		System.out.println("Test Complete: " + scenario.getSourceTagNames() + " Status: " + scenario.getStatus());
		oLog.info("*******Completed Scenerio**********");
	//	stopRecording();
		Wrapper.killIEProcess();
	}
	


	public void setUpDriver(String bType) throws Exception 
	{
		driver = standAloneStepUp(bType);
		oLog.debug("InitializeWebDrive : " + driver.hashCode());
		System.out.println("InitializeWebDrive : " + driver.hashCode());
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(Long.parseLong(CONFIG.getProperty("PageLoadTimeOut")),TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(Long.parseLong(CONFIG.getProperty("ImplcitWait")),TimeUnit.SECONDS);
		mywrap.setImplicitWait(driver, Long.parseLong(CONFIG.getProperty("ImplcitWait")), TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}

	public void tearDownDriver(Scenario scenario) throws Exception 
	{
		try 
		{
			if (driver != null) 
			{

				/*if(scenario.isFailed())
				{
					scenario.write(takeScreenShot(scenario.getName()));
				}*/
				scenario.write(takeScreenShot(scenario.getName()));
				 try {  
	                 byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);  
	                 scenario.embed(screenshot, "image/png");  
	             } catch (WebDriverException wde) {  
	                 System.err.println(wde.getMessage());  
	             } catch (ClassCastException cce) {  
	                 cce.printStackTrace();  
	             }  

				driver.quit();
				oLog.info("Shutting Down the driver");
			}
			driver = null;
		}
		catch (org.openqa.selenium.UnhandledAlertException e) 
		{             
			File destDir = new File(CONFIG.getProperty("ScreenshotLocation")+getCurrentDate());
			if (!destDir.exists())
				destDir.mkdir();

			String destPath = destDir.getAbsolutePath()+ System.getProperty("file.separator") + scenario.getName() + ".jpg";
			BufferedImage image = new Robot().createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));

			ImageIO.write(image, "png", new File(destPath)); 
			System.out.println("The Robo Class Screenshot Location is \t:\t["+destPath+"]");
			oLog.error("The Robo Class Screenshot Location is \t:\t["+destPath+"]");
			Alert alert = driver.switchTo().alert(); 
			String alertText = alert.getText().trim();
			oLog.error("Alert Present and the text Present in the Alert Popup window ["+ alertText+"]");
			alert.accept();
			driver.switchTo().defaultContent();
			/*if(scenario.isFailed())
			{
				scenario.write(destPath);
			}*/
			scenario.write(destPath);
			driver.quit();
			oLog.info("Shutting Down the driver");

		}
		catch (Exception e) 
		{
			oLog.error(e);
			throw e;
		}
	}
    
	
	
	public Capabilities getChromeCapabilities() {
		ChromeOptions option = new ChromeOptions();
		option.addArguments("start-maximized");
		option.addArguments("--test-type");
		DesiredCapabilities chrome = DesiredCapabilities.chrome();
		chrome.setJavascriptEnabled(true);
		chrome.setCapability(ChromeOptions.CAPABILITY, option);
		return chrome;
	}

	public WebDriver getChromeDriver(Capabilities cap) {
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"/drivers/chrome/2.26/chromedriver.exe");
		return new ChromeDriver(cap);
	}
    
	
	
	public Capabilities getIExplorerCapabilities() {
		DesiredCapabilities cap = DesiredCapabilities.internetExplorer();
		//cap.setCapability(CapabilityType.BROWSER_NAME, "IE");
		cap.setCapability(CapabilityType.BROWSER_NAME, "internet explorer");
		cap.setCapability(InternetExplorerDriver.ELEMENT_SCROLL_BEHAVIOR,ElementScrollBehavior.BOTTOM);
		cap.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
		cap.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
		cap.setCapability(InternetExplorerDriver.UNEXPECTED_ALERT_BEHAVIOR,UnexpectedAlertBehaviour.IGNORE);
		cap.setCapability(InternetExplorerDriver.REQUIRE_WINDOW_FOCUS,true);
		cap.setCapability("ignoreProtectedModeSettings", true);
		cap.setJavascriptEnabled(true); 
		cap.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
		
		return cap;
	}
	
	public WebDriver getIExplorerDriver(Capabilities cap)
	{
		System.setProperty("webdriver.ie.driver", System.getProperty("user.dir")+"/drivers/IE/2.53.1/IEDriverServer.exe");
		return new InternetExplorerDriver(cap);
	}
	public WebDriver getIExplorerDriver()
	{
		 DesiredCapabilities ieCapabilities = DesiredCapabilities.internetExplorer();      
	      
	    ieCapabilities.setCapability("ignoreProtectedModeSettings", true);    
		System.setProperty("webdriver.ie.driver", System.getProperty("user.dir")+"/drivers/IE/2.53.1/IEDriverServer.exe");
		return new InternetExplorerDriver(ieCapabilities);
	}
	public Capabilities getFirefoxCapabilities() {
		DesiredCapabilities firefox = DesiredCapabilities.firefox();
		FirefoxProfile profile = new FirefoxProfile();
		profile.setAcceptUntrustedCertificates(true);
		profile.setAssumeUntrustedCertificateIssuer(true);
		firefox.setCapability(FirefoxDriver.PROFILE, profile);
		firefox.setCapability("marionette", true);
		return firefox;
	}
	
	public WebDriver getFirefoxDriver(Capabilities cap) {
		System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir")+"/drivers/firefox/geckodriver.exe");
		return new FirefoxDriver(cap);
	}
	
	
	public String takeScreenShot(String name) throws IOException {

		if (driver instanceof HtmlUnitDriver) 
		{
			oLog.fatal("HtmlUnitDriver Cannot take the ScreenShot");
			return "";
		}

		File destDir = new File(CONFIG.getProperty("ScreenshotLocation")+getCurrentDate());
		if (!destDir.exists())
			destDir.mkdir();

		File destPath = new File(destDir.getAbsolutePath()+ System.getProperty("file.separator") + name + ".jpg");
		try 
		{
			FileUtils.copyFile(((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE), destPath);
		} catch (IOException e)
		{
			oLog.error(e);
			throw e;
		}
		oLog.info(destPath.getAbsolutePath());
		return destPath.getAbsolutePath();
	}

	public String takeScreenShot() 
	{
		oLog.info("Going to Take the ScreenShot");
		return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);
	}
	
	
	
	 @When("^that Launch Application '(.+)' URL$")
	    public void sampleUserDefinedOpenLink(String url) {
		 	oLog.info("The Configuration WebSite URL is \t:\t"+CONFIG.getProperty(url));
		 	System.out.println("The Configuration WebSite URL is \t:\t"+CONFIG.getProperty(url));
	        driver.get(CONFIG.getProperty(url));
	        
	    }
		
	/* public void startRecording() throws Exception
	 {    
		 File file = new File(CONFIG.getProperty("VideosLocation"));

		 Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		 int width = screenSize.width;
		 int height = screenSize.height;

		 Rectangle captureSize = new Rectangle(0,0, width, height);

		 GraphicsConfiguration gc = GraphicsEnvironment
				 .getLocalGraphicsEnvironment()
				 .getDefaultScreenDevice()
				 .getDefaultConfiguration();

		 this.screenRecorder = new SpecializedScreenRecorder(gc, captureSize,
				 new Format(MediaTypeKey, MediaType.FILE, MimeTypeKey, MIME_AVI),
				 new Format(MediaTypeKey, MediaType.VIDEO, EncodingKey, ENCODING_AVI_TECHSMITH_SCREEN_CAPTURE,
						 CompressorNameKey, ENCODING_AVI_TECHSMITH_SCREEN_CAPTURE,
						 DepthKey, 24, FrameRateKey, Rational.valueOf(15),
						 QualityKey, 1.0f,
						 KeyFrameIntervalKey, 15 * 60),
						 new Format(MediaTypeKey, MediaType.VIDEO, EncodingKey, "black",
								 FrameRateKey, Rational.valueOf(30)),
								 null, file, "MyVideo");
		 this.screenRecorder.start();

	 }

     public void stopRecording() throws Exception
     {
       this.screenRecorder.stop();
       oLog.info("Stopped the Video");
     }*/
	

 	
 	@Then("^Store Data from the \"(.*?)\" and the \"(.*?)\" for the Rows \"(.*?)\" dataset$")
     public void gettheNumberofRowsinEachTestScript(String FileName,String SheetName,String rowindex) throws Throwable {
 		 index=0;
         index = Integer.parseInt(rowindex)-1;
         System.out.println("Printing current data set..."+index);
         
         
         System.out.println(System.getProperty("user.dir")+"/src/test/resources/testData/"+FileName+".xlsx");
         datamap = DataHelper.data(System.getProperty("user.dir")+"/src/test/resources/testData/"+FileName+".xlsx",SheetName);
         for(HashMap h:datamap)
         {
             System.out.println(h.keySet());
             System.out.println(h.values());
         }
         tempindex=index;
      

     }






	


	
	
}

