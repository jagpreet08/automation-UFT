package com.techm.ups.ttg.utils;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Function;
import com.itextpdf.text.log.SysoCounter;
import com.techm.ups.ttg.glue.BaseClass;


public class Wrapper {

	/****** Object Definition for Log4j ******/
	private Logger oLog = Logger.getLogger(Wrapper.class);

	/****** Object Definition for Actions ******/
	Actions action;

	/****** Wait ******/

	public void setImplicitWait(WebDriver driver, long timeout, TimeUnit unit) {
		oLog.info(timeout);
		oLog.info("Currently we are in the setImplicitWait method");
		System.out.println("Currently we are in the setImplicitWait method");
		driver.manage().timeouts().implicitlyWait(timeout, unit);
	}

	private WebDriverWait getWait(WebDriver driver, int timeOutInSeconds,int pollingEveryInMiliSec) 
	{
		oLog.info("Currently we are in the getWait method");
		System.out.println("Currently we are in the getWait method");
		oLog.debug("");
		WebDriverWait wait = new WebDriverWait(driver, timeOutInSeconds);
		wait.pollingEvery(pollingEveryInMiliSec, TimeUnit.MILLISECONDS);
		wait.ignoring(NoSuchElementException.class);
		wait.ignoring(ElementNotVisibleException.class);
		wait.ignoring(StaleElementReferenceException.class);
		wait.ignoring(NoSuchFrameException.class);
		return wait;
	}

	public void waitForElementVisible(WebDriver driver, String xpathExpression)
	{
		oLog.info("Currently we are in the waitForElementVisible method");
		System.out.println("Currently we are in the waitForElementVisible method");
		oLog.info(xpathExpression);
		//WebDriverWait wait = getWait(driver, timeOutInSeconds,pollingEveryInMiliSec);
		WebDriverWait wait =new WebDriverWait(driver,Long.parseLong(BaseClass.CONFIG.getProperty("ExplicitWait")));
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(xpathExpression))));

	}

	public void waitForAlertPresent(WebDriver driver) 
	{
		oLog.info("Currently we are in the waitForAlertPresent method");
		System.out.println("Currently we are in the waitForAlertPresent method");
		//WebDriverWait wait = getWait(driver, timeOutInSeconds,	pollingEveryInMiliSec);
		WebDriverWait wait =new WebDriverWait(driver,Long.parseLong(BaseClass.CONFIG.getProperty("ExplicitWait")));
		wait.until(ExpectedConditions.alertIsPresent());
	}

	public void waitForElementClickable(WebDriver driver,String xpathExpression)
	{
		oLog.info("Currently we are in the waitForElementClickable method");
		System.out.println("Currently we are in the waitForElementClickable method");
		oLog.info(xpathExpression);
		setImplicitWait(driver,1, TimeUnit.SECONDS);
		//WebDriverWait wait = getWait(driver, timeOutInSeconds,pollingEveryInMiliSec);
		WebDriverWait wait =new WebDriverWait(driver,Long.parseLong(BaseClass.CONFIG.getProperty("ExplicitWait")));
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath(xpathExpression))));
		setImplicitWait(driver,Long.parseLong(BaseClass.CONFIG.getProperty("ImplcitWait")), TimeUnit.SECONDS);
	}

	
	public void waitForElementInvisibility(WebDriver driver,String xpathExpression, int timeOutInSeconds,int pollingEveryInMiliSec)
	{
		oLog.info("Currently we are in the waitForElementClickable method");
		System.out.println("Currently we are in the waitForElementClickable method");
		oLog.info(xpathExpression);
		setImplicitWait(driver,1, TimeUnit.SECONDS);
		//WebDriverWait wait = getWait(driver, timeOutInSeconds,pollingEveryInMiliSec);
		WebDriverWait wait =new WebDriverWait(driver,Long.parseLong(BaseClass.CONFIG.getProperty("ExplicitWait")));
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(xpathExpression)));
		setImplicitWait(driver,Long.parseLong(BaseClass.CONFIG.getProperty("ImplcitWait")), TimeUnit.SECONDS);
	}

	public void waitForElementtobeSelected(WebDriver driver,String xpathExpression, int timeOutInSeconds,int pollingEveryInMiliSec)
	{
		oLog.info("Currently we are in the waitForElementClickable method");
		System.out.println("Currently we are in the waitForElementClickable method");
		oLog.info(xpathExpression);
		setImplicitWait(driver,1, TimeUnit.SECONDS);
		WebDriverWait wait = getWait(driver, timeOutInSeconds,pollingEveryInMiliSec);
		wait.until(ExpectedConditions.elementToBeSelected(By.xpath(xpathExpression)));
		setImplicitWait(driver,Long.parseLong(BaseClass.CONFIG.getProperty("ImplcitWait")), TimeUnit.SECONDS);
	}
	public void hardWait(int timeOutInMiliSec) throws InterruptedException 
	{
		oLog.info("Currently we are in the hardWait method");
		System.out.println("Currently we are in the hardWait method");
		oLog.info(timeOutInMiliSec);
		Thread.sleep(timeOutInMiliSec);
	}

	public void elementExits(WebDriver driver, By locator,	int timeOutInSeconds, int pollingEveryInMiliSec) 
	{
		oLog.info("Currently we are in the elementExits method");
		System.out.println("Currently we are in the elementExits method");
		oLog.info(locator);
		//setImplicitWait(driver,1, TimeUnit.SECONDS);
		WebDriverWait wait = getWait(driver, timeOutInSeconds,	pollingEveryInMiliSec);
		wait.until(elementLocatedBy(locator));
		//setImplicitWait(driver,Long.parseLong(BaseClass.CONFIG.getProperty("ImplcitWait")), TimeUnit.SECONDS);
	}

	public void elementExistAndVisible(WebDriver driver, By locator, int timeOutInSeconds, int pollingEveryInMiliSec) 
	{
		oLog.info("Currently we are in the elementExistAndVisible method");
		System.out.println("Currently we are in the elementExistAndVisible method");
		oLog.info(locator);
		WebDriverWait wait = getWait(driver, timeOutInSeconds,	pollingEveryInMiliSec);
		wait.until(elementLocatedBy(locator));
		scrollIntoView(driver, locator);
		wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
	}

	public void waitForIframe(WebDriver driver, By locator,	int timeOutInSeconds, int pollingEveryInMiliSec) 
	{
		oLog.info("Currently we are in the waitForIframe method");
		System.out.println("Currently we are in the waitForIframe method");
		oLog.info(locator);
	//	setImplicitWait(driver,1, TimeUnit.SECONDS);
		WebDriverWait wait = getWait(driver, timeOutInSeconds,	pollingEveryInMiliSec);
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(locator));
		driver.switchTo().defaultContent();
		//setImplicitWait(driver,Long.parseLong(BaseClass.CONFIG.getProperty("ImplcitWait")),TimeUnit.SECONDS);
	}

	/****** Retry count for specific tag ******/

	public WebElement handleStaleElement(WebDriver driver,	String xpathexpression, int retryCount, int delayInSeconds)	throws InterruptedException 
	{
		oLog.info("Currently we are in the handleStaleElement method");
		System.out.println("Currently we are in the handleStaleElement method");
		oLog.info(xpathexpression);
		WebElement element = null;

		while (retryCount >= 0) 
		{
			try
			{
				element = driver.findElement(By.xpath(xpathexpression));
				return element;
			} catch (StaleElementReferenceException e) {
				hardWait(delayInSeconds);
				retryCount--;
			}
		}
		throw new StaleElementReferenceException("Element cannot be recovered");
	}

	/****** Function ******/

	private Function<WebDriver, Boolean> elementLocatedBy(final By locator)
	{
		return new Function<WebDriver, Boolean>() {

			public Boolean apply(WebDriver driver) {
				oLog.debug(locator);
				return driver.findElements(locator).size() >= 1;
			}
		};
	}

	/****** Execute Script ******/

	public Object executeScript(WebDriver driver, String script) 
	{
		oLog.info("Currently we are in the executeScript method");
		System.out.println("Currently we are in the executeScript method");
		JavascriptExecutor exe = (JavascriptExecutor) driver;
		oLog.info(script);
		return exe.executeScript(script);
	}

	public Object executeScript(WebDriver driver, String script, Object... args) 
	{
		oLog.info("Currently we are in the executeScript method");
		System.out.println("Currently we are in the executeScript method");
		JavascriptExecutor exe = (JavascriptExecutor) driver;
		oLog.info(script);
		return exe.executeScript(script, args);
	}

	/****** Scroll To Element ******/

	public void scrollToElement(WebDriver driver, WebElement element) 
	{
		oLog.info("Currently we are in the scrollToElement method");
		System.out.println("Currently we are in the scrollToElement method");
		executeScript(driver, "window.scrollTo(arguments[0],arguments[1])",
				element.getLocation().x, element.getLocation().y);
		oLog.info(element);
	}

	public void scrollToElement(WebDriver driver, By locator) 
	{
		oLog.info("Currently we are in the scrollToElement method");
		System.out.println("Currently we are in the scrollToElement method");
		scrollToElement(driver, driver.findElement(locator));
		oLog.info(locator);
	}

	public void scrollToElemetAndClick(WebDriver driver, By locator)
	{
		oLog.info("Currently we are in the scrollToElemetAndClick method");
		System.out.println("Currently we are in the scrollToElemetAndClick method");
		WebElement element = driver.findElement(locator);
		scrollToElement(driver, element);
		element.click();
		oLog.info(locator);
	}

	public void scrollToElemetAndClick(WebDriver driver, WebElement element) {
		oLog.info("Currently we are in the scrollToElemetAndClick method");
		System.out.println("Currently we are in the scrollToElemetAndClick method");
		scrollToElement(driver, element);
		element.click();
		oLog.info(element);
	}

	public void scrollIntoView(WebDriver driver, WebElement element) {
		oLog.info("Currently we are in the scrollIntoView method");
		System.out.println("Currently we are in the scrollIntoView method");
		executeScript(driver, "arguments[0].scrollIntoView()", element);
		oLog.info(element);
	}

	public void scrollIntoView(WebDriver driver, By locator) 
	{
		oLog.info("Currently we are in the scrollIntoView method");
		System.out.println("Currently we are in the scrollIntoView method");
		scrollIntoView(driver, driver.findElement(locator));
		oLog.info(locator);
	}

	public void scrollIntoViewAndClick(WebDriver driver, By locator)
	{
		oLog.info("Currently we are in the scrollIntoViewAndClick method");
		System.out.println("Currently we are in the scrollIntoViewAndClick method");
		WebElement element = driver.findElement(locator);
		scrollIntoView(driver, element);
		element.click();
		oLog.info(locator);
	}

	public void scrollIntoViewAndClick(WebDriver driver, WebElement element) 
	{
		oLog.info("Currently we are in the scrollIntoViewAndClick method");
		System.out.println("Currently we are in the scrollIntoViewAndClick method");
		scrollIntoView(driver, element);
		element.click();
		oLog.info(element);
	}

	/****** Alert ******/

	public Alert getAlert(WebDriver driver)
	{
		Alert alert;
		oLog.info("Currently we are in the getAlert method");
		System.out.println("Currently we are in the getAlert method");
		alert = driver.switchTo().alert();
		return alert;

	}

	public void AcceptAlert(WebDriver driver) 
	{
		// Alert alert;
		oLog.info("Currently we are in the AcceptAlert method");
		System.out.println("Currently we are in the AcceptAlert method");
		getAlert(driver).accept();
		// alert.accept();
	}

	public void DismissAlert(WebDriver driver) 
	{
		oLog.info("Currently we are in the DismissAlert method");
		System.out.println("Currently we are in the DismissAlert method");
		oLog.info("");
		getAlert(driver).dismiss();
		// alert.dismiss();
	}

	public String getAlertText(WebDriver driver) 
	{
		waitForAlertPresent(driver);
		oLog.info("Currently we are in the getAlertText method");
		System.out.println("Currently we are in the getAlertText method");
		String text = getAlert(driver).getText();
		oLog.info(text);
		return text;
	}

	public boolean isAlertPresent(WebDriver driver) {
		oLog.info("Currently we are in the isAlertPresent method");
		System.out.println("Currently we are in the isAlertPresent method");
		try {
			waitForAlertPresent(driver);
			driver.switchTo().alert();
			oLog.info("true");
			return true;
		} catch (NoAlertPresentException e) {
			// Ignore
			oLog.info("false");
			return false;
		}
	}

	public void AcceptAlertIfPresent(WebDriver driver) throws Exception 
	{
		try{
		
		if (!isAlertPresent(driver))
			return;
		else
		{
			hardWait(1000);
			AcceptAlert(driver);
			oLog.info("Accepted the Alert Popup window");
		}
	}
	catch(TimeoutException e)
	{
		oLog.info("No Alert Present");
	}
	}

	public void DismissAlertIfPresent(WebDriver driver) 
	{
		waitForAlertPresent(driver);
		if (!isAlertPresent(driver))
			return;
		DismissAlert(driver);
		oLog.info("");
	}

	public void AcceptPrompt(WebDriver driver, String text) {

		try {

			if (!isAlertPresent(driver))
				return;

			Alert alert = getAlert(driver);
			driver.switchTo().alert().sendKeys(text);
			alert.sendKeys(text);
			hardWait(1000);
			alert.accept();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		oLog.info(text);
	}

	public void AlertPresentWait(WebDriver driver, int timeOutInSeconds,
			int pollingEveryInMiliSec) {
		try {
			oLog.info("Currently we are in the AlertPresentWait method");
			System.out
			.println("Currently we are in the AlertPresentWait method");
			WebDriverWait wait = getWait(driver, timeOutInSeconds,
					pollingEveryInMiliSec);
			wait.until(ExpectedConditions.alertIsPresent());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/****** Click ******/

	public void click(WebDriver driver, String xpathExpression) {
		oLog.info("Currently we are in the click method");
		waitForElementClickable(driver, xpathExpression);
		WebElement element = getElement(driver, xpathExpression);
		highlightElement(driver, xpathExpression);
		element.click();
		System.out.println("Element clicked"+xpathExpression);
		oLog.info(element);
	}
	public void javascriptEx_Click(WebDriver driver, String xpathExpression)
	{
		WebElement element = getElement(driver, xpathExpression);		
		//highlightElement(driver, xpathExpression);
		((JavascriptExecutor)driver).executeScript("arguments[0].click();", element); 
	}
	/****** Check Box and Radio Button ******/

	public boolean isIselected(WebDriver driver, String xpathExpression) {
		boolean flag = driver.findElement(By.xpath(xpathExpression))
				.isSelected();
		oLog.info(flag);
		return flag;
	}

	public void selectCheckBox(WebDriver driver, String xpathExpression) {
		if (!isIselected(driver, xpathExpression))
			driver.findElement(By.xpath(xpathExpression)).click();
		oLog.info(driver.findElement(By.xpath(xpathExpression)));
	}

	public void unSelectCheckBox(WebDriver driver, String xpathExpression) {
		WebElement element = driver.findElement(By.xpath(xpathExpression));
		if (isIselected(driver, xpathExpression))
			element.click();
		oLog.info(element);
	}

	/****** Browser related methods ******/

	public void navigateTo(WebDriver driver, String url) {
		oLog.info(url);
		driver.get(url);
	}

	public void naviagteTo(WebDriver driver, URL url) {
		
		oLog.info(url.getPath());
		driver.get(url.getPath());
	}

	public String getTitle(WebDriver driver) {
		String title = driver.getTitle();
		oLog.info(title);
		return driver.getTitle();
	}

	public String getCurrentUrl(WebDriver driver) {
		String url = driver.getCurrentUrl();
		oLog.info(url);
		return driver.getCurrentUrl();
	}

	public void goBack(WebDriver driver) {
		driver.navigate().back();
		oLog.info("Back the WebPage Successfully");
	}

	public void goForward(WebDriver driver) {
		driver.navigate().forward();
		oLog.info("Forward the WebPage Successfully");
	}

	public void refresh(WebDriver driver) {
		driver.navigate().refresh();
		oLog.info("Refresh the webPage successfully");
	}

	public void close(WebDriver driver) {
		driver.close();
		oLog.info("Closed the Current Opened Window Successfully");
	}

	/****** Drop down selection ******/

	public void SelectUsingVisibleValue(WebDriver driver,
			String xpathExpression, String visibleValue) {
		WebElement element = getElement(driver, xpathExpression);
		highlightElement(driver, xpathExpression);
		SelectUsingVisibleValue(driver, getElement(driver, xpathExpression),
				visibleValue);
	}

	public void SelectUsingVisibleValue(WebDriver driver, WebElement element,
			String visibleValue) {
		
		
		oLog.info("Currently we are in the SelectUsingVisibleValue method");
		System.out.println("Currently we are in the SelectUsingVisibleValue method");
		Select select = new Select(element);
		select.selectByVisibleText(visibleValue);
		oLog.info("Locator : " + element + " Value : " + visibleValue);
	}
	
	public void SelectUsingValue(WebDriver driver,String xpathExpression,String value) {
	/*	WebElement element = getElement(driver, xpathExpression);
		highlightElement(driver, xpathExpression);*/
		Select select = new Select(getElement(driver, xpathExpression));
		select.selectByValue(value);
		oLog.info("Locator : " + xpathExpression + " Value : " + value);
	}
	
	public void SelectUsingText(WebDriver driver,String xpathExpression,String value) {
		/*	WebElement element = getElement(driver, xpathExpression);
			highlightElement(driver, xpathExpression);*/
			Select select = new Select(getElement(driver, xpathExpression));
			select.selectByVisibleText(value);
			oLog.info("Locator : " + xpathExpression + " Value : " + value);
		}
	public void SelectUsingIndex(WebDriver driver,String xpathExpression,int index) {
		Select select = new Select(getElement(driver, xpathExpression));
		select.selectByIndex(index);
		oLog.info("Locator : " + xpathExpression + " Index : " + index);
	}

	public String getSelectedValue(WebDriver driver, String xpathExpression) {
		oLog.info(xpathExpression);
		return getSelectedValue(driver, getElement(driver, xpathExpression));
	}

	public String getSelectedValue(WebDriver driver, WebElement element) {
		String value = new Select(element).getFirstSelectedOption().getText();
		oLog.info("WebELement : " + element + " Value : " + value);
		return value;
	}

	public List<String> getAllDropDownValues(WebDriver driver,
			String xpathExpression) {
		Select select = new Select(getElement(driver, xpathExpression));
		List<WebElement> elementList = select.getOptions();
		List<String> valueList = new LinkedList<String>();

		for (WebElement element : elementList) {
			oLog.info(element.getText());
			valueList.add(element.getText());
		}
		return valueList;
	}

	/****** Get Element ******/

	public WebElement getElement(WebDriver driver, String xpathExpression) {
		oLog.info("Currently we are in the getElement method");
		System.out.println("Currently we are in the getElement method");
		oLog.info(xpathExpression);
		if (IsElementPresentQuick(driver, xpathExpression))
			return driver.findElement(By.xpath(xpathExpression));

		try {
			throw new NoSuchElementException("Element Not Found : " + xpathExpression);
		} catch (RuntimeException re) {
			oLog.error(re);
			throw re;
		}
	}
	
	public String getText(WebDriver driver, String xpathExpression) {
		oLog.info("Locator : " + xpathExpression);
		return getElement(driver, xpathExpression).getText();
	}

	/**
	 * Check for element is present based on locator If the element is present
	 * return the web element otherwise null
	 * 
	 * @param locator
	 * @return WebElement or null
	 */
	
	public WebElement getElementWithNull(WebDriver driver,String xpathExpression) {
		oLog.info(xpathExpression);
		try {
			return driver.findElement(By.xpath(xpathExpression));
		} catch (NoSuchElementException e) {
			// Ignore
		}
		return null;
	}

	public boolean IsElementPresentQuick(WebDriver driver,String xpathExpression) {
		boolean flag;
		oLog.info("Currently we are in the IsElementPresentQuick method");
		System.out.println("Currently we are in the IsElementPresentQuick method");
		try
		{
			flag = driver.findElements(By.xpath(xpathExpression)).size() >= 1;
			oLog.info(flag);
			System.out.println(flag);
		}
		catch(NoSuchElementException e)
		{
			flag=false;	
			System.out.println("There is no Such Element is present in the WebPage\t:\t");
			oLog.info("There is no Such Element is present in the WebPage\t:\t");
		}
		catch(Exception e)
		{
			flag=false;	
			System.out.println("There is Exception["+e.toString()+"]");
			oLog.info("There is Exception["+e.toString()+"]");
		}
		return flag;
	}

	/****** Take Screenshot ******/

	public String takeScreenShot(WebDriver driver, String name)
			throws IOException {

		if (driver instanceof HtmlUnitDriver) {
			oLog.fatal("HtmlUnitDriver Cannot take the ScreenShot");
			return "";
		}

		File destDir = new File(
				BaseClass.CONFIG.getProperty("ScreenshotLocation")
						+ getCurrentDate());
		if (!destDir.exists())
			destDir.mkdir();

		File destPath = new File(destDir.getAbsolutePath()
				+ System.getProperty("file.separator") + name + ".jpg");
		try {
			FileUtils
					.copyFile(((TakesScreenshot) driver)
							.getScreenshotAs(OutputType.FILE), destPath);
		} catch (IOException e) {
			oLog.error(e);
			throw e;
		}
		oLog.info(destPath.getAbsolutePath());
		return destPath.getAbsolutePath();
	}

	public String takeScreenShot(WebDriver driver) {
		oLog.info("Going to Take the Screenshot");
		return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);
	}

	/****** Get Current Date & Time ******/

	public static String getCurrentDateTime() {

		DateFormat dateFormat = new SimpleDateFormat("_yyyy-MM-dd_HH-mm-ss");
		Calendar cal = Calendar.getInstance();
		String time = "" + dateFormat.format(cal.getTime());
		return time;
	}

	public static String getCurrentDate() {
		return getCurrentDateTime().substring(0, 11);
	}

	/****** Methods related to Text box ******/

	public void clearAndSendKeys(WebDriver driver, String xpathExpression,
			String value) {
		oLog.info("Currently we are in the clearAndSendKeys method");
		waitForElementVisible(driver, xpathExpression);
		WebElement element = getElement(driver, xpathExpression);
		highlightElement(driver, xpathExpression);
		element.click();
		element.clear();
		
		
		element.getText();
		element.sendKeys(value);
		oLog.info("Locator : " + xpathExpression + " Value : " + value);
		System.out.println("Locator : " + xpathExpression + " Value : " + value);
	}
	
	public void onlySendKeys(WebDriver driver, String xpathExpression,
			String value) {
		oLog.info("Currently we are in the clearAndSendKeys method");
		waitForElementVisible(driver, xpathExpression);
		WebElement element = getElement(driver, xpathExpression);
		highlightElement(driver, xpathExpression);
		element.getText();
		element.sendKeys(value);
		oLog.info("Locator : " + xpathExpression + " Value : " + value);
		System.out.println("Locator : " + xpathExpression + " Value : " + value);
	}
	
	public String getTextBoxValue(WebDriver driver, String xpathExpression) 
	{
		oLog.info("Currently we are in the getTextBoxValue method");
		waitForElementVisible(driver, xpathExpression);
		WebElement element = getElement(driver, xpathExpression);
	//	highlightElement(driver, xpathExpression);
		String TextValue=element.getAttribute("value");
		oLog.info("Locator : " + xpathExpression + " Value : " + TextValue);
		System.out.println("Locator : " + xpathExpression + " Value : " + TextValue);
		return TextValue;
	}

	public void Keys_clearAndSendKeys(WebDriver driver, String xpathExpression,
			Keys key) {
		oLog.info("Currently we are in the Keys_clearAndSendKeys method");
		waitForElementVisible(driver, xpathExpression);
		WebElement element = getElement(driver, xpathExpression);
		highlightElement(driver, xpathExpression);
		element.click();
		element.sendKeys(key);
		oLog.info("Locator : " + xpathExpression + " Value : " + key);
		System.out.println("Locator : " + xpathExpression + " Value : " + key);
	}

	
	
	/**** Switch To Window ****/

	public Boolean SwitchToWindowViaWindowTitle(WebDriver driver, String Value) {
		/*	try {
			hardWait(2000);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}*/
		boolean flag = false;
		try {
			String parentWindowHandler = driver.getWindowHandle(); // Store your
																	// parent
																	// window
			System.out.println("Parent window Name :" + parentWindowHandler);
			String subWindowHandler = null;

			Set<String> handles = driver.getWindowHandles(); // get all window
																// handles
			Iterator<String> iterator = handles.iterator();

			while (iterator.hasNext()) {
				subWindowHandler = iterator.next();
				driver.switchTo().window(subWindowHandler);
				driver.manage().window().maximize();
				if (driver.getTitle().equalsIgnoreCase(Value)) 
				{
					System.out.println("Switched to window \t:\t["+Value+"]");
					oLog.info("Switched to window \t:\t["+Value+"]");
					flag = true;
					break;
				}

			}
			return flag;

		} catch (Exception e) {
			e.printStackTrace();
			return flag;
		}
	}

	public Set<String> getWindowHandlens(WebDriver driver) {
		oLog.info("Going to get the Number of Windows Opened by the Driver");
		return driver.getWindowHandles();
	}
	
	public String getWindowHandle(WebDriver driver) {
		oLog.info("Getting current window");
		return driver.getWindowHandle();
	}
	
	public void SwitchToWindow(WebDriver driver,String windowHandler) {
		driver.switchTo().window(windowHandler);
		driver.manage().window().maximize();

	}

	public void SwitchToWindow(WebDriver driver, int index) {

		LinkedList<String> windowsId = new LinkedList<String>(getWindowHandlens(driver));

		if (index < 0 || index > windowsId.size())
			throw new IllegalArgumentException("Invalid Index : " + index);

		driver.switchTo().window(windowsId.get(index));
		oLog.info("Switched to the Window of ["+index+"]");
	}

	public void SwitchToDefaultWindow(WebDriver driver) throws InterruptedException {
		hardWait(1000);
		driver.switchTo().defaultContent();
		oLog.info("Switched to the default Window");
		hardWait(1000);
	}

	public void switchToParentWindow(WebDriver driver) {
		LinkedList<String> windowsId = new LinkedList<String>(getWindowHandlens(driver));
		driver.switchTo().window(windowsId.get(0));
		oLog.info("Switched to Parent Window successfully");
	}

	public void switchToParentWithChildClose(WebDriver driver) {
		switchToParentWindow(driver);

		LinkedList<String> windowsId = new LinkedList<String>(
				getWindowHandlens(driver));

		for (int i = 1; i < windowsId.size(); i++) {
			oLog.info(windowsId.get(i));
			driver.switchTo().window(windowsId.get(i));
			driver.close();
		}

		switchToParentWindow(driver);
	}

	@SuppressWarnings("deprecation")
	public void NoOfWindows(WebDriver driver, int timeOutInSeconds,
			int pollingEveryInMiliSec, int expectedNumberOfWindows) {
		try {
			oLog.info("Currently we are in the NoOfWindows method");
			System.out.println("Currently we are in the NoOfWindows method");
			WebDriverWait wait = getWait(driver, timeOutInSeconds,
					pollingEveryInMiliSec);
			wait.until(ExpectedConditions
					.numberOfwindowsToBe(expectedNumberOfWindows));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**** Switch To Frame 
	 * @throws InterruptedException ****/

	public void switchToFrame(WebDriver driver, String name) throws InterruptedException {
		try 
		{
			hardWait(1000);
			driver.switchTo().frame(name);
			oLog.info("Switched the Frame sucessfully ["+name+"]");
		} 
		catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		hardWait(1000);
	}

	public List<WebElement> listofItem(WebDriver driver, String xpathExpression) {
		List<WebElement> lista = driver.findElements(By.xpath(xpathExpression));

		oLog.info("Get the List of Webelements [" + xpathExpression + "]");
		return lista;
	}

	/***** Actions - Mouse and Keys ****/

	public void MoveToElement(WebDriver driver, String locator) {
		try {
			oLog.info("Currently we are in the MoveToElement method");
			System.out.println("Currently we are in the MoveToElement method");
			WebElement element = getElement(driver, locator);
			action = new Actions(driver);
			action.moveToElement(element).build().perform();
			hardWait(1000);
			// ((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid red'",
			// element);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void MoveToElementAndClick(WebDriver driver, String locator) {
		try {
			oLog.info("Currently we are in the MoveToElementAndClick method");
			System.out
			.println("Currently we are in the MoveToElementAndClick method");
			WebElement element = getElement(driver, locator);
			action = new Actions(driver);
			action.moveToElement(element).click().build().perform();
			// hardWait(5000);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	
	public void MoveToElementAndClick(WebDriver driver, WebElement element) {
		try {
			oLog.info("Currently we are in the MoveToElementAndClick method");
			System.out
			.println("Currently we are in the MoveToElementAndClick method");
		//	WebElement element = getElement(driver, locator);
			action = new Actions(driver);
			action.moveToElement(element).click().build().perform();
			// hardWait(5000);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	public void DragAndDrop(WebDriver driver, String Src_locator,
			String Dest_locator) {
		try {
			oLog.info("Currently we are in the DragAndDrop method");
			System.out.println("Currently we are in the DragAndDrop method");
			WebElement src_element = getElement(driver, Src_locator);
			WebElement dest_element = getElement(driver, Dest_locator);
			action = new Actions(driver);
			action.dragAndDrop(src_element, dest_element).build().perform();
		}

		catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void ElementKeyDown(WebDriver driver, String locator, Keys key) {
		try {
			oLog.info("Currently we are in the ElementKeyDown method");
			System.out.println("Currently we are in the ElementKeyDown method");
			WebElement element = getElement(driver, locator);
			action = new Actions(driver);
			action.keyDown(element, key).build().perform();
		}

		catch (Exception e) {
			e.printStackTrace();
		}

	}


	public void ClickAndHold(WebDriver driver) {
		try {
			oLog.info("Currently we are in the ClickAndHold method");
			System.out.println("Currently we are in the ClickAndHold method");
			action = new Actions(driver);
			action.clickAndHold().build().perform();
		}

		catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void ClickAndHoldElement(WebDriver driver, String locator) {
		try {
			oLog.info("Currently we are in the ClickAndHoldElement method");
			System.out
					.println("Currently we are in the ClickAndHoldElement method");
			WebElement element = getElement(driver, locator);
			action = new Actions(driver);
			action.clickAndHold(element).build().perform();
		}

		catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void ReleaseElement(WebDriver driver, String locator) {
		try {
			oLog.info("Currently we are in the ReleaseElement method");
			System.out.println("Currently we are in the ReleaseElement method");
			WebElement element = getElement(driver, locator);
			action = new Actions(driver);
			action.release(element).build().perform();
		}

		catch (Exception e) {
			e.printStackTrace();
		}

	}


	public void DoubleClickElement(WebDriver driver, String locator) {
		try {
			oLog.info("Currently we are in the DoubleClick method");
			System.out.println("Currently we are in the DoubleClick method");
			WebElement element = getElement(driver, locator);
			action = new Actions(driver);
			action.doubleClick(element).build().perform();
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void RightClickElement(WebDriver driver, String locator) {
		try {
			oLog.info("Currently we are in the RightClickElement method");
			System.out.println("Currently we are in the RightClickElement method");
			WebElement element=getElement(driver,locator);
			action=new Actions(driver);
			action.contextClick(element).build().perform();
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void RightClick(WebDriver driver)
	{
		try
		{
			oLog.info("Currently we are in the RightClickElement method");
			System.out.println("Currently we are in the RightClickElement method");
			action=new Actions(driver);
			action.contextClick().build().perform();
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**** Action methods - not tested ****/
	
	public void KeyDown(WebDriver driver, Keys key) {
		try {
			oLog.info("Currently we are in the KeyDown method");
			System.out.println("Currently we are in the KeyDown method");
			action = new Actions(driver);
			action.keyDown(key).build().perform();
		}

		catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void Release(WebDriver driver) {
		try {
			oLog.info("Currently we are in the Release method");
			System.out.println("Currently we are in the Release method");
			action = new Actions(driver);
			action.release().build().perform();
		}

		catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public void ElementKeyUP(WebDriver driver, String locator, Keys key) {
		try {
			oLog.info("Currently we are in the ElementKeyUP method");
			System.out.println("Currently we are in the ElementKeyUP method");
			WebElement element = getElement(driver, locator);
			action = new Actions(driver);
			action.keyUp(element, key).build().perform();
		}

		catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void KeyUP(WebDriver driver, Keys key) {
		try {
			oLog.info("Currently we are in the KeyUP method");
			System.out.println("Currently we are in the KeyUP method");
			action = new Actions(driver);
			action.keyUp(key).build().perform();
		}

		catch (Exception e) {
			e.printStackTrace();
		}

	}


	/**** HighLight ****/

	public void highlightElement(WebDriver driver, String xpathExpression) {
		oLog.info("Currently we are in the highlightElement method");
		System.out.println("Currently we are in the highlightElement method");
		WebElement element = getElement(driver, xpathExpression);
		((JavascriptExecutor) driver).executeScript(
				"arguments[0].style.border='3px solid red'", element);
		oLog.info("Performed successfully highlightElement for the element"
				+ xpathExpression);
		System.out
		.println("Performed successfully highlightElement for the element"
				+ xpathExpression);
	}

	/***** File Upload ****/

	public void uploadSingleFileinIE(WebDriver driver, String autoitFileName,
			String uploadFileName) {
		String currentDir = System.getProperty("user.dir");
		String myuploadpath = "/src/test/resources/FileDownload/";
		String actualpath = "\"" + currentDir + myuploadpath + uploadFileName
				+ "\"";
		String autoitScriptpath = "\"" + currentDir
				+ "/src/test/resources/autoit/" + autoitFileName + "\"";
		System.out.println(actualpath);
		Process p = null;
		oLog.info("Currently we are in the uploadSingleFileinIE method");
		System.out
		.println("Currently we are in the uploadSingleFileinIE method");
		try {
			p = Runtime.getRuntime().exec(autoitScriptpath + " " + actualpath);
			try {
				p.waitFor();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (IOException e) {

			e.printStackTrace();
		}

	}

	/**** Make zip of reports ****/

	public void zip(String filepath, String destionationPath,
			String DestionationZipName) {
		try {
			String ZipFilePath = destionationPath + DestionationZipName;
			File inFolder = new File(filepath);
			File outFolder = new File(ZipFilePath);
			ZipOutputStream out = new ZipOutputStream(new BufferedOutputStream(
					new FileOutputStream(outFolder)));
			BufferedInputStream in = null;
			byte[] data = new byte[1000];
			String files[] = inFolder.list();
			for (int i = 0; i < files.length; i++) {
				in = new BufferedInputStream(new FileInputStream(
						inFolder.getPath() + "/" + files[i]), 1000);
				out.putNextEntry(new ZipEntry(files[i]));
				int count;
				while ((count = in.read(data, 0, 1000)) != -1) {
					out.write(data, 0, count);
				}
				out.closeEntry();
			}
			out.flush();
			out.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void javaScriptExec_clearAndSendKeys(WebDriver driver, String xpathExpression,String value) {
		oLog.info("Currently we are in the clearAndSendKeys method");
		waitForElementVisible(driver, xpathExpression);
		WebElement element = getElement(driver, xpathExpression);
		highlightElement(driver, xpathExpression);
		element.click();
		element.clear();
		((JavascriptExecutor)driver).executeScript("arguments[0].value = '"+value+"'", element);
		oLog.info("Locator : " + xpathExpression + " Value : " + value);
		System.out.println("Locator : " + xpathExpression + " Value : " + value);
	}

	public void javaScriptExec_SendKeys(WebDriver driver, String xpathExpression,String value) {
		oLog.info("Currently we are in the clearAndSendKeys method");
		waitForElementVisible(driver, xpathExpression);
		WebElement element = getElement(driver, xpathExpression);
		highlightElement(driver, xpathExpression);
		element.click();

		element.sendKeys(value);
		((JavascriptExecutor)driver).executeScript("arguments[0].value = '"+value+"'", element);
		oLog.info("Locator : " + xpathExpression + " Value : " + value);
		System.out.println("Locator : " + xpathExpression + " Value : " + value);
	}
public String replaceData(WebDriver driver, String xpathExpression ,String datarequired)
	{
		xpathExpression=xpathExpression.replace("**data**", datarequired);
		return xpathExpression;
	}
	
	public void Sendkeys_Tab(WebDriver driver, String xpathExpression,Keys key)
	{
		driver.findElement(By.xpath(xpathExpression)).sendKeys(key);
	}
	
	
	
	
	public void customTakeScreenShot(WebDriver driver)
	{
		try {  
            byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);  
            System.out.println(BaseClass.scenario.getName());
            BaseClass.scenario.embed(screenshot, "image/png");  
          
        } catch (WebDriverException wde) {  
            System.err.println(wde.getMessage());  
        } catch (ClassCastException cce) {  
            cce.printStackTrace();  
        }  
	}
	
	public static void killIEProcess()
	{
		try 
		{
			 System.out.println("Going to kill the IEDriverServer Process");
		   Process p= Runtime.getRuntime().exec("taskkill /F /IM IEDriverServer.exe");
		   try 
		   {
			p.waitFor();
		   } 
		   catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		} catch (IOException e) {
		    e.printStackTrace();
		}
		  System.out.println("Killed the IEDriverServer process Sucessfully");
		  try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

