package com.techm.ups.ttg.utils;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

public class SendEmailwithAttachment {
    public static void main(String[] args) {
        SendEmailwithAttachment demo = new SendEmailwithAttachment();
        demo.sendEmail();
    }

    @Test
    public void sendEmail() {
        // Defines the E-Mail information.
        String from = "automation@ups.com";
        String to = "ckanamarlapudi@ups.com";
        String subject = "Automation Test Build Result";
        String bodyText = "This is a important message with attachment.";

        // The attachment file name.
       // String attachmentName = "C:\\Download_Jenkins_Jobs\\msg_spec\\target\\cucumber-results-test-results.html";
List<String> attachNames=textFiles("C:\\Download_Jenkins_Jobs\\msg_spec\\target");
String FilePath="C:\\Download_Jenkins_Jobs\\msg_spec\\target\\";
String[] attachNames_Value=new String[4];
attachNames_Value[0]="cucumber-results-feature-overview.html";
attachNames_Value[1]="cucumber-results-charts-report.html";
attachNames_Value[2]="cucumber-results-system-info.html";
attachNames_Value[3]="cucumber-results-test-results.html";


        // Creates a Session with the following properties.
        Properties props = new Properties();
        props.put("mail.smtp.host", "rpc-mah.ups.com");
        props.put("mail.transport.protocol", "smtp");
        props.put("mail.smtp.starttls.enable", "false");
        props.put("mail.smtp.port", "25");
        Session session = Session.getDefaultInstance(props);

        try {
            InternetAddress fromAddress = new InternetAddress(from);
            InternetAddress toAddress = new InternetAddress(to);

            // Create an Internet mail msg.
            MimeMessage msg = new MimeMessage(session);
            msg.setFrom(fromAddress);
            msg.setRecipient(Message.RecipientType.TO, toAddress);
            msg.setSubject(subject);
            msg.setSentDate(new Date());

            // Set the email msg text.
            MimeBodyPart messagePart = new MimeBodyPart();
            messagePart.setText(bodyText);
            
            
            
            
            BodyPart messageBodyPart = new MimeBodyPart();
            Multipart multipart = new MimeMultipart();
          
        
            DataSource source = new FileDataSource(FilePath+attachNames_Value[3]);
            messageBodyPart.setDataHandler(new DataHandler(source));
            messageBodyPart.setFileName(attachNames_Value[3]);
            multipart.addBodyPart(messageBodyPart);
            msg.setContent(multipart);
            
           /* source = new FileDataSource(FilePath+attachNames_Value[1]);
            messageBodyPart.setDataHandler(new DataHandler(source));
            messageBodyPart.setFileName(FilePath+attachNames_Value[1]);
            multipart.addBodyPart(messageBodyPart);
            
            source = new FileDataSource(FilePath+attachNames_Value[2]);
            messageBodyPart.setDataHandler(new DataHandler(source));
            messageBodyPart.setFileName(FilePath+attachNames_Value[2]);
            multipart.addBodyPart(messageBodyPart);
            msg.setContent(multipart);
            
            source = new FileDataSource(FilePath+attachNames_Value[3]);
            messageBodyPart.setDataHandler(new DataHandler(source));
            messageBodyPart.setFileName(FilePath+attachNames_Value[3]);
            multipart.addBodyPart(messageBodyPart);*/
            
            msg.setContent(multipart);

            // Set the email attachment file
            
          /*  for(int i=0;i<attachNames.size();i++)
            {
            FileDataSource fileDataSource = new FileDataSource("C:\\Download_Jenkins_Jobs\\msg_spec\\target\\"+attachNames.get(i));

       		MimeBodyPart attachmentPart = new MimeBodyPart();
            Multipart multipart = new MimeMultipart();
            attachmentPart.setDataHandler(new DataHandler(fileDataSource));
            attachmentPart.setFileName(fileDataSource.getName());
            // Create Multipart E-Mail.
         
            multipart.addBodyPart(messagePart);
            multipart.addBodyPart(attachmentPart);
            }
            msg.setContent(multipart);*/
         

          

            // Send the msg. Don't forget to set the username and password
            // to authenticate to the mail server.
         //   Transport.send(msg, "vhy0fml", "oct@2017");
            Transport.send(msg);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }
    
    
    
    List<String> textFiles(String directory) 
	{
		  List<String> textFiles = new ArrayList<String>();
		  File dir = new File(directory);
		  for (File file : dir.listFiles()) 
		  {
		    if ((file.getName().endsWith(".html") ) && (!file.getName().endsWith(".bak.html"))&& (!file.getName().contains("cucumber-results-usage")) /*|| file.getName().endsWith(".pdf")*/) {
		      textFiles.add(file.getName());
		    }
		  }
		  return textFiles;
		}

}