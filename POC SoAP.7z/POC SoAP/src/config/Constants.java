package config;

import java.text.SimpleDateFormat;
//import java.time.LocalDateTime;
import java.util.Date;

public class Constants {
	
	//System Variables
	
	public static final String Path_TestCases = "src\\dataEngine\\ExecutionSheet.xlsx";
	public static final String Path_TestData = "src\\dataEngine\\DataSheet.xlsx";

	public static final String File_TestData = "DataEngine.xlsx";
	public static final String KEYWORD_FAIL = "FAIL";
	public static final String KEYWORD_PASS = "PASS";
	
	//Data Sheet Column Numbers
	public static final int Col_TestCaseID = 0;	
	public static final int Col_TestSteps=1 ;
	public static final int Col_TestDesc=2 ;
	public static final int Col_PageObject =5 ;
	public static final int Col_ActionKeyword =1 ;
	public static final int Col_RunMode =3 ;
	public static final int Col_Result =4 ;
	public static final int Col_DataSet =2 ;
	public static final int Col_TestStepResult =3 ;
		
	// Data Engine Excel sheets
	public static final String Sheet_TestSteps = "Test Steps";
	public static final String Sheet_TestCases = "Test Cases";
	public static String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
	public static String reportPath = "src\\Reporting\\ExecutionResultReport_"+ timeStamp+".html";
	//public static String currentDate = new SimpleDateFormat("dd/MM/yyyy").format(new Date());
   // public static String reportPath = "src\\Reporting\\ExecutionResultReport_" + currentDate+"_" + LocalDateTime.now().getHour()+"-"+LocalDateTime.now().getMinute()+"-" + LocalDateTime.now().getSecond()+".html";
	//public static String reportPath = "src\\Reporting\\ExecutionResultReport_" + currentDate +".html";

	

}
