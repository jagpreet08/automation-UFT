package config;
//import java.io.FileInputStream;
import executionEngine.DriverScript;
import utility.ExcelUtils;
//import utility.Log;


import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import Reporting.Reporter;

public class ActionKeywords {

	
	
	public static void SoapRequestsResponses() throws Exception{
		
		try {
			// Create SOAP Connection
			// System.setProperty("java.net.useSystemProxies", "true");
			Reporter.initialize();
			SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
			SOAPConnection soapConnection = soapConnectionFactory.createConnection();

			// Send SOAP Message to SOAP Server
			String url = ExcelUtils.getParameterValue("EndPoint");
			SOAPMessage soapResponse = soapConnection.call(createSOAPRequest(), url);

			// Process the SOAP Response
			printSOAPResponse(soapResponse);
			readXMLFile();

			soapConnection.close();
		} catch (Exception e) {
			System.err.println("Error occurred while sending SOAP Request to Server");
			e.printStackTrace();
		}
	}

	private static SOAPMessage createSOAPRequest() throws Exception {

		String path = ExcelUtils.getParameterValue("RequestXML");
		File file = new File(System.getProperty("user.dir") + File.separator + path);

		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		dbFactory.setNamespaceAware(true);
		DocumentBuilder builder = dbFactory.newDocumentBuilder();
		Document document = builder.parse(file);
		DOMSource domSource = new DOMSource(document);

		MessageFactory messageFactory = MessageFactory.newInstance();
		SOAPMessage soapMessage = messageFactory.createMessage();
		SOAPPart soapPart = soapMessage.getSOAPPart();
		soapPart.setContent(domSource);

		soapMessage.saveChanges();

		/* Print the request message */
		System.out.print("Request SOAP Message = ");
		soapMessage.writeTo(System.out);
		System.out.println();

		return soapMessage;

	}

	/**
	 * Method used to print the SOAP Response
	 */
	private static void printSOAPResponse(SOAPMessage soapResponse) throws Exception {

		try {
			String path = ExcelUtils.getParameterValue("Response");

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			Source sourceContent = soapResponse.getSOAPPart().getContent();
			System.out.print("\nResponse SOAP Message = ");
			StreamResult result = new StreamResult(new File(path));// ("D:/SoapMsgs/Responses/InventoryAvailabilitySummaryWithoutWarehouseCode.xml"));
			transformer.transform(sourceContent, result);

			System.out.println("File saved!");
		} catch (TransformerException tfe) {
			tfe.printStackTrace();
		}
	}

	public static void readXMLFile() {
		boolean Status = true;

		try {
			String dbUrl = ExcelUtils.getParameterValue("DBURL");

			// Database Username
			String username = ExcelUtils.getParameterValue("DBUser");

			// Database Password
			String password = ExcelUtils.getParameterValue("DBPwd");

			// Query to Execute
			String query = ExcelUtils.getParameterValue("DBQuery");

			// Load oracle jdbc driver
			Class.forName("oracle.jdbc.OracleDriver");

			// Create Connection to DB
			Connection con = DriverManager.getConnection(dbUrl, username, password);

			// Create Statement Object
			Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);

			// Execute the SQL Query. Store results in ResultSet
			ResultSet rs = stmt.executeQuery(query);
            
			int rowcount = 0;
			rs.last();
			rowcount = rs.getRow();
			System.out.println("Total rows"+rowcount);
			rs.beforeFirst();
			
			String path = ExcelUtils.getParameterValue("Response");
			File fXmlFile = new File(path);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			
			doc.getDocumentElement().normalize();

		    System.out.println("Root element :" + doc.getDocumentElement().getNodeName());

		    NodeList nList = doc.getElementsByTagName("ns2:WarehouseAvailabilitySummary");  //DataColumn
		    
		    int NoOfMsgs =0;
		  
		    
				if (rowcount > 0) {
					if (rs.next()) {
						
						for (int temp = 0; temp < nList.getLength(); temp++) {
					        
						    org.w3c.dom.Node nNode = nList.item(temp);

						   if (nNode.getNodeType() == Node.ELEMENT_NODE) {

						    Element eElement = (Element) nNode;
						    
						    System.out.println("----------------------------");
						        
						        if(eElement.getElementsByTagName("ns2:warehouseCode").item(0)==null){
						    System.out.println("No warehouseCode");
						    }else{    
						 
						    System.out.println("warehouseCode : " + eElement.getElementsByTagName("ns2:warehouseCode").item(0).getTextContent());
						  
						if (eElement.getElementsByTagName("ns2:warehouseCode").item(0).getTextContent().equalsIgnoreCase(rs.getString("DEPOT_CODE").toString())){			
						    System.out.println("Node ns2:warehouseCode value is matching with the value from DB");
						    Reporter.HTMLTCSteps("Node 'ns2:warehouseCode' should exist in response xml and the value in DB should match", "Node 'ns2:warehouseCode' exists and the value is '<b>"+ eElement.getElementsByTagName("ns2:warehouseCode").item(0).getTextContent()+"</b>'", "Node 'ns2:warehouseCode' should exist and the value should be '<b>"+ rs.getString("DEPOT_CODE")+"</b>'", "Pass");
						
						    if (Status == false) {
								Status = false;
							} else {
								Status = true;
							}
						} else {
							Status = false;
						    System.out.println("Node ns2:warehouseCode value is not matching with the value from DB");
						    Reporter.HTMLTCSteps("Node 'ns2:warehouseCode' should exist in response xml and the value in DB should match", "Node 'ns2:warehouseCode' exists and the value is '<b>" + eElement.getElementsByTagName("ns2:warehouseCode").item(0).getTextContent()+"</b>'", "Node 'ns2:warehouseCode' should exist and the value should be '<b>"+ rs.getString("DEPOT_CODE")+"</b>'", "Fail");
							}
						    }
						        
						        if(eElement.getElementsByTagName("ns2:availableQuantity").item(0)==null){
						    System.out.println("No availableQuantity");
						    }else{    
						 
						    System.out.println("availableQuantity : " + eElement.getElementsByTagName("ns2:availableQuantity").item(0).getTextContent());
						    String PhysicalQuantity = Integer.toString(rs.getInt("PHYSICAL_QTY"));			   
						   if (Integer.parseInt(eElement.getElementsByTagName("ns2:availableQuantity").item(0).getTextContent()) == rs.getInt("PHYSICAL_QTY")) {
						       
						    	System.out.println("Node ns2:availableQuantity value is matching with the value from DB");
						    	Reporter.HTMLTCSteps("Node 'ns2:availableQuantity' should exist in response xml and the value in DB should match", "Node 'ns2:availableQuantity' exists and the value is '<b>"+  eElement.getElementsByTagName("ns2:availableQuantity").item(0).getTextContent()+"</b>'", "Node 'ns2:availableQuantity' should exist and the value should be '<b>"+ PhysicalQuantity+"</b>'", "Pass");
						    	
								if (Status == false) {
									Status = false;
								} else {
									Status = true;
								}
							} else {
								Status = false;
								System.out.println("Node ns2:availableQuantity value is not matching with the value from DB");
								Reporter.HTMLTCSteps("Node 'ns2:availableQuantity' should exist in response xml and the value in DB should match", "Node 'ns2:availableQuantity' exists and the value is '<b>"+  eElement.getElementsByTagName("ns2:availableQuantity").item(0).getTextContent()+"</b>'", "Node 'ns2:availableQuantity' should exist and the value should be '<b>"+ PhysicalQuantity+"</b>'", "Fail");
							}
						    
						    }
						     
						    if(eElement.getElementsByTagName("ns3:value").item(0)==null){
						    System.out.println("No Disposition Value");
						    }else{    
						 
						    System.out.println("Disposition Value: " + eElement.getElementsByTagName("ns3:value").item(0).getTextContent());			   
						    if (eElement.getElementsByTagName("ns3:value").item(0).getTextContent().equalsIgnoreCase(rs.getString("DISPOSITION1").toString())){
						    	System.out.println("Node ns3:Disposition value is matching with the value from DB");
						    	
								Reporter.HTMLTCSteps("Node 'ns3:Disposition' should exist in response xml and the value in DB should match", "Node 'ns3:Disposition' exists and the value is '<b>"+   eElement.getElementsByTagName("ns3:value").item(0).getTextContent()+"</b>'", "Node 'ns3:Disposition' should exist and the value should be '<b>"+  rs.getString("DISPOSITION1")+"</b>'", "Pass");
								if (Status == false) {
									Status = false;
								} else {
									Status = true;
								}
							} else {
								Status = false;
								System.out.println("Node ns3:Disposition value is not matching with the value from DB");
								Reporter.HTMLTCSteps("Node 'ns3:Disposition' should exist in response xml and the value in DB should match", "Node 'ns3:Disposition' exists and the value is '<b>"+   eElement.getElementsByTagName("ns3:value").item(0).getTextContent()+"</b>'", "Node 'ns3:Disposition' should exist and the value should be '<b>"+  rs.getString("DISPOSITION1")+"</b>'", "Fail");
							}
					        }
						    if(eElement.getElementsByTagName("ns3:rank").item(0)==null){
						    System.out.println("No Rank");
						    }else{    
						 
						    System.out.println("rank: " + eElement.getElementsByTagName("ns3:rank").item(0).getTextContent());
						    String Rank = Integer.toString(rs.getInt("RANK"));
						    if (Integer.parseInt(eElement.getElementsByTagName("ns3:rank").item(0).getTextContent()) == rs.getInt("RANK")) {						    
						    	System.out.println("Node ns3:rank value is matching with the value from DB");
						    	
								Reporter.HTMLTCSteps("Node 'ns3:rank' should exist in response xml and the value in DB should match","Node 'ns3:rank' exists and the value is '<b>"+   eElement.getElementsByTagName("ns3:rank").item(0).getTextContent()+"</b>'","Node 'ns3:rank' should exist and the value should be '<b>"+  Rank+"</b>'", "Pass");
								if (Status == false) {
									Status = false;
								} else {
									Status = true;
								}
							} else {
								Status = false;
								System.out.println("Node ns3:rank value is not matching with the value from DB");
								
								Reporter.HTMLTCSteps("Node 'ns3:rank' should exist in response xml and the value in DB should match","Node 'ns3:rank' exists and the value is '<b>"+   eElement.getElementsByTagName("ns3:rank").item(0).getTextContent()+"</b>'","Node 'ns3:rank' should exist and the value should be '<b>"+  Rank+"</b>'", "Fail");
							}
						    }
						          
						    
						    if(eElement.getElementsByTagName("ns3:excludeFromAllocation").item(0)==null){
						    System.out.println("No excludeFromAllocation");
						    }else{    
						 
						    System.out.println("excludeFromAllocation: " + eElement.getElementsByTagName("ns3:excludeFromAllocation").item(0).getTextContent());						  
						    if (eElement.getElementsByTagName("ns3:excludeFromAllocation").item(0).getTextContent().equalsIgnoreCase(rs.getString("EXCLUDE_FROM_ALLOCATION").toString())){
						    	System.out.println("Node ns3:excludeFromAllocation value is matching with the value from DB");
						    	
								Reporter.HTMLTCSteps("Node 'ns3:excludeFromAllocation' should exist in response xml and the value in DB should match", "Node 'ns3:excludeFromAllocation' exists and the value is '<b>"+    eElement.getElementsByTagName("ns3:excludeFromAllocation").item(0).getTextContent()+"</b>'","Node 'ns3:excludeFromAllocation' should exist and the value should be '<b>"+    rs.getString("EXCLUDE_FROM_ALLOCATION")+"</b>'", "Pass");
							if (Status == false) {
								Status = false;
							} else {
								Status = true;								
							}
						} else {
							Status = false;
							System.out.println("Node ns3:excludeFromAllocation value is not matching with the value from DB");
							Reporter.HTMLTCSteps("Node 'ns3:excludeFromAllocation' should exist in response xml and the value in DB should match", "Node 'ns3:excludeFromAllocation' exists and the value is '<b>"+    eElement.getElementsByTagName("ns3:excludeFromAllocation").item(0).getTextContent()+"</b>'","Node 'ns3:excludeFromAllocation' should exist and the value should be '<b>"+    rs.getString("EXCLUDE_FROM_ALLOCATION")+"</b>'", "Fail");
						}
						    }
						  
						       
				}
			    NoOfMsgs = NoOfMsgs+1;
						   	  
				rs.next();	   	     
				}
				}
				}else {
					System.out.println("DB Returns Zero Rows");
					System.out.println("There are no nodes to check");
					Status = true;
				}
				 
				
				if (Status == true & NoOfMsgs == rowcount){
					DriverScript.bResult = true;
					System.out.println("Test Case is Passed"); 

				} else {
					DriverScript.bResult = false;
					System.out.println("Test Case is Failed");
				}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			DriverScript.bResult = false;

		}
		}
	
	
	
	
	
}
	