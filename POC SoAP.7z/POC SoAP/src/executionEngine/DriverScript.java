package executionEngine;

import java.io.FileInputStream;
import java.io.FileOutputStream;
//import java.io.FileInputStream;
import java.lang.reflect.Method;
//import java.util.Properties;
import java.nio.charset.Charset;
//import java.text.SimpleDateFormat;
//import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.xml.DOMConfigurator;

//import com.sun.jna.platform.FileUtils;

import Reporting.Reporter;
import config.ActionKeywords;
import config.Constants;
import utility.ExcelUtils;
import utility.Log;


public class DriverScript {
	
	
	public static ActionKeywords actionKeywords;
	public static String sActionKeyword;
	public static String sPageObject;
	public static Method method[];
		
	public static int iTestStep;
	public static int iTestLastStep;
	public static String sTestCaseID;
	public static String sTestStep;
	public static String sTestDesc ;
	public static String sRunMode;
	public static String sData;
	public static boolean bResult;
	public static int TestDataRow;
	
	public DriverScript() throws NoSuchMethodException, SecurityException{
		actionKeywords = new ActionKeywords();
		method = actionKeywords.getClass().getMethods();	
	}
	
    public static void main(String[] args) throws Exception {
    	ExcelUtils.setExcelFile(Constants.Path_TestCases);
    	DOMConfigurator.configure("log4j.xml");
    	
		
		DriverScript startEngine = new DriverScript();
		startEngine.execute_TestCase();
		
    }
		
    private void execute_TestCase() throws Exception {
    	    int TotalTestCases = 0;
    	    int TotalPassed = 0;
    	    int TotalFailed =0;
    	    long Start = System.nanoTime();
    	    
    	    Reporter.HTMLHeader();
	    	int iTotalTestCases = ExcelUtils.getRowCount(Constants.Sheet_TestCases);
			for(int iTestcase=1;iTestcase<iTotalTestCases;iTestcase++){
				bResult = true;
				sTestCaseID = ExcelUtils.getCellData(iTestcase, Constants.Col_TestCaseID, Constants.Sheet_TestCases); 
				sRunMode = ExcelUtils.getCellData(iTestcase, Constants.Col_RunMode,Constants.Sheet_TestCases);
				sTestStep = ExcelUtils.getCellData(iTestcase, Constants.Col_TestSteps, Constants.Sheet_TestCases);
				sTestDesc = ExcelUtils.getCellData(iTestcase, Constants.Col_TestDesc, Constants.Sheet_TestCases);
				
				if (sRunMode.equals("Yes")){
					Log.startTestCase(sTestCaseID);
					iTestStep = ExcelUtils.getRowContains(sTestCaseID, Constants.Col_TestCaseID, sTestStep);
					iTestLastStep = ExcelUtils.getTestStepsCount(sTestStep, sTestCaseID, iTestStep);
					bResult=true;
					long startTime = System.nanoTime();
					for (;iTestStep<iTestLastStep;iTestStep++){
			    		sActionKeyword = ExcelUtils.getCellData(iTestStep, Constants.Col_ActionKeyword,sTestStep);
			    		sData = ExcelUtils.getCellData(iTestStep, Constants.Col_DataSet, sTestStep);
			    		Reporter.HTMLTCDetails(sTestCaseID,sTestDesc );
			    		Reporter.HTMLTStepsHeading(sTestCaseID);
			    		execute_Actions();
			    		Reporter.HTMLTEnd();				
						}
					
					
					TotalTestCases=TotalTestCases+1;
					if(bResult==true){
					ExcelUtils.setCellData(Constants.KEYWORD_PASS,iTestcase,Constants.Col_Result,Constants.Sheet_TestCases);
					Log.endTestCase(sTestCaseID);
					String OldResult= "<th width=\"15%\" align=left valign=center colspan=4><font color=black face=Arial><small><b>TC Status: </b></small></font></th>";
					String UpdateResult= "<th width=\"15%\" align=left valign=center colspan=4><font color=black face=Arial><small><b>TC Status: </b></small></font><font color=\"#008000\" face=Arial><small><b>PASS</b></small></font></th>";
					FileInputStream fis = new FileInputStream(Constants.reportPath);
				    String content = IOUtils.toString(fis, Charset.defaultCharset());
				    content = content.replaceAll(OldResult, UpdateResult);
				    FileOutputStream fos = new FileOutputStream(Constants.reportPath);
				    IOUtils.write(content, new FileOutputStream(Constants.reportPath), Charset.defaultCharset());
				    fis.close();
				    fos.close();
				    TotalPassed=TotalPassed+1;

					}	
					else{
						ExcelUtils.setCellData(Constants.KEYWORD_FAIL,iTestcase,Constants.Col_Result,Constants.Sheet_TestCases);
						Log.endTestCase(sTestCaseID);
						String OldResult= "<th width=\"15%\" align=left valign=center colspan=4><font color=black face=Arial><small><b>TC Status: </b></small></font></th>";
						String UpdateResult="<th width=\"15%\" align=left valign=center colspan=4><font color=black face=Arial><small><b>TC Status: </b></small></font><font color=\"#FF0000\" face=Arial><small><b>FAIL</b></small></font></th>";
						FileInputStream fis = new FileInputStream(Constants.reportPath);
					    String content = IOUtils.toString(fis, Charset.defaultCharset());
					    content = content.replaceAll(OldResult, UpdateResult);
					    FileOutputStream fos = new FileOutputStream(Constants.reportPath);
					    IOUtils.write(content, new FileOutputStream(Constants.reportPath), Charset.defaultCharset());
					    fis.close();
					    fos.close();
					    TotalFailed=TotalFailed+1;
						//break;
						}	
					
					
					
					long endTime = System.nanoTime();
					
                    long ActualTime = endTime - startTime;
					String Duration= "<th width=\"20%\" align=left valign=center colspan=4><font color=black face=Arial><small><b>TC Duration: </b></small></font></th>";
					String FinalDuration= "<th width=\"20%\" align=left valign=center colspan=4><font color=black face=Arial><small><b>TC Duration: </b>"+ ActualTime/1000000000+" seconds</b></small></font></th>";
					FileInputStream fis = new FileInputStream(Constants.reportPath);
				    String content = IOUtils.toString(fis, Charset.defaultCharset());
				    content = content.replaceAll(Duration, FinalDuration);
				    FileOutputStream fos = new FileOutputStream(Constants.reportPath);
				    IOUtils.write(content, new FileOutputStream(Constants.reportPath), Charset.defaultCharset());
				    fis.close();
				    fos.close();
					}
				}
			
			String OldTotalTC= "<td align=\"left\" valign=\"top\"><font color=\"black\" face=\"Arial\"><small><b>Total Test Cases Execution: </b></small></font></td>";
			String UpdateTotalTC= "<td align=\"left\" valign=\"top\"><font color=\"black\" face=\"Arial\"><small><b>Total Test Cases Execution: "+TotalTestCases+"</b></small></font></td>";
			String OldTCPassed ="<td align=\"left\" valign=\"top\"><font color=\"black\" face=\"Arial\"><small><b>Total Test Cases Passed: </b></small></font></td>";
			String UpdateTCPassed="<td align=\"left\" valign=\"top\"><font color=\"black\" face=\"Arial\"><small><b>Total Test Cases Passed: "+TotalPassed+"</b></small></font></td>";
			String OldTCFailed="<td align=\"left\" valign=\"top\"><font color=\"black\" face=\"Arial\"><small><b>Total Test Cases Failed: </b></small></font></td>";
			String UpdateTCFailed="<td align=\"left\" valign=\"top\"><font color=\"black\" face=\"Arial\"><small><b>Total Test Cases Failed: "+TotalFailed+"</b></small></font></td>";
			
			Date date = new Date();
		    SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");
		    String strDate = sdf.format(date);
			String ExecEndTime = "<td align=\"left\" valign=\"top\"><font color=\"black\" face=\"Arial\"><small><b>Execution End Time: </b></small></font></td>";
		    String UpdateExecEndTime = "<td align=\"left\" valign=\"top\"><font color=\"black\" face=\"Arial\"><small><b>Execution End Time: "+strDate+" </b></small></font></td>";
			long end = System.nanoTime();
			long timeElapsed = end - Start;
			String OldTCDuration="<td align=\"left\" valign=\"top\"><font color=\"black\" face=\"Arial\"><small><b>Total Execution Time: </b></small></font></td>";
			String UpdateTCDuration="<td align=\"left\" valign=\"top\"><font color=\"black\" face=\"Arial\"><small><b>Total Execution Time: "+timeElapsed/1000000000+" seconds</b></small></font></td>";
			
			FileInputStream fis = new FileInputStream(Constants.reportPath);
		    String content = IOUtils.toString(fis, Charset.defaultCharset());
		    content = content.replaceAll(OldTotalTC, UpdateTotalTC);
		    content = content.replaceAll(OldTCPassed, UpdateTCPassed);
		    content = content.replaceAll(OldTCFailed, UpdateTCFailed);
		    content = content.replaceAll(ExecEndTime, UpdateExecEndTime);
		    content = content.replaceAll(OldTCDuration, UpdateTCDuration);
		    FileOutputStream fos = new FileOutputStream(Constants.reportPath);
		    IOUtils.write(content, new FileOutputStream(Constants.reportPath), Charset.defaultCharset());
		    fis.close();
		    fos.close();
		    
    		}	
     
     private static void execute_Actions() throws Exception {
    	 ExcelUtils.setExcelFile(Constants.Path_TestData);
    	 if (sData.isEmpty()==false) {
    	 TestDataRow = ExcelUtils.getRowContains(sTestCaseID, Constants.Col_TestCaseID, sData);
    	 }
    	 for(int i=0;i<method.length;i++){
			
			if(method[i].getName().equals(sActionKeyword)){
				method[i].invoke(actionKeywords, null);
				
				if(bResult==true){
					ExcelUtils.setCellData(Constants.KEYWORD_PASS, iTestStep, Constants.Col_TestStepResult, sTestStep);
					break;
				}else{
					ExcelUtils.setCellData(Constants.KEYWORD_FAIL, iTestStep, Constants.Col_TestStepResult, sTestStep);
					break;
					}
				}
			}
     }
     
}