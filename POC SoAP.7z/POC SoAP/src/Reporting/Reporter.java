package Reporting;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
//import java.sql.Date;
import java.text.SimpleDateFormat;
//import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

//import com.gargoylesoftware.htmlunit.javascript.host.dom.Document;

import config.Constants;


public class Reporter {
	
	private static List<Result> details;
	private static final String resultPlaceholder = "<!-- INSERT_RESULTS -->";
	//private static final String templatePath = "src\\Reporting\\report_template.html";
	
	
	public Reporter() {
	}
	
	public static void initialize() {
		details = new ArrayList<Result>();
	}
	
	public static void report(String actualValue,String expectedValue) {
		if(actualValue.equals(expectedValue)) {
			Result r = new Result("Pass","Actual value '" + actualValue + "' matches expected value");
			details.add(r);
		} else {
			Result r = new Result("Fail","Actual value '" + actualValue + "' does not match expected value '" + expectedValue + "'");
			details.add(r);
		}
	}
	
	public static void reportInt(int actualValue,int expectedValue) {
		if(actualValue == expectedValue) {
			Result r = new Result("Pass","Actual value '" + actualValue + "' matches expected value");
			details.add(r);
		} else {
			Result r = new Result("Fail","Actual value '" + actualValue + "' does not match expected value '" + expectedValue + "'");
			details.add(r);
		}
	}
	
	
	public static void showResults() {
		for (int i = 0;i < details.size();i++) {
			System.out.println("Result " + Integer.toString(i) + ": " + details.get(i).getResult());
		}
	}
	
	
	public static void writeResults() {
		try {
			String reportIn = new String(Files.readAllBytes(Paths.get(Constants.reportPath)));
			for (int i = 0; i < details.size();i++) {
				reportIn = reportIn.replaceFirst(resultPlaceholder,"<tr><td>" + Integer.toString(i+1) + "</td><td>" + details.get(i).getResult() + "</td><td>" + details.get(i).getResultText() + "</td></tr>" + resultPlaceholder);
			}
			
			//String reportPath = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
			//String reportPath = "src\\Reporting\\report_" + currentDate + ".html";
			Files.write(Paths.get(Constants.reportPath),reportIn.getBytes(),StandardOpenOption.CREATE);
			
		} catch (Exception e) {
			System.out.println("Error when writing report file:\n" + e.toString());
		}
	}
	
	public static void HTMLTCSteps(String SD, String AR, String ER, String Status ) throws IOException {
		
		try
	    {
	       
	        File file = new File(Constants.reportPath);

	        FileWriter fileWriter = new FileWriter(file,true);

	        BufferedWriter bufferFileWriter  = new BufferedWriter(fileWriter);
	        //String TCNO = DriverScript.sTestCaseID;
	       // fileWriter.append("<div id=\""+TCNO+"\" style=display:none >");
	       //fileWriter.append("<TABLE ALIGN=Center BORDER=0 WIDTH=\"100%\" CELLPADDING=1>");
	       //fileWriter.append("<tbody><tr bgcolor=#ffcc66>");
	       fileWriter.append("<tr bgcolor=#ffcc66>");

	        fileWriter.append("<td width=\"30%\" align=left valign=center colspan=4><font color=\"#003399\"  face=Arial><small><b>" + SD +"</b></small></font></td>");
	        fileWriter.append("<td width=\"30%\" align=left valign=center colspan=4><font font color=\"#003399\" face=Arial><small><b>" + ER +" </b></small></font></td>");
	        fileWriter.append("<td width=\"30%\" align=left valign=center colspan=8><font color=\"#003399\"font color=\"#003399\" face=Arial><small><b>" + AR +"</b></small></font></td>");
	       
	        if (Status.equalsIgnoreCase("Pass")){
	        fileWriter.append("<td width=\"10%\" align=left valign=center colspan=4><font color=\"#008000\" face=Arial><small><b>" + Status +"</b></small></font></td>");
	        }
	        else{
	        fileWriter.append("<td width=\"10%\" align=left valign=center colspan=4><font color=\"#FF0000\" face=Arial><small><b>" + Status +"</b></small></font></td>");	
	        }
	       
	        bufferFileWriter.close();
	        	        
	    }catch(Exception ex)
	    {
	        System.out.println(ex);
	    }

				
	}
	
public static void HTMLTEnd() throws IOException {
		
		try
	    {
	       
	        File file = new File(Constants.reportPath);

	        FileWriter fileWriter = new FileWriter(file,true);

	        BufferedWriter bufferFileWriter  = new BufferedWriter(fileWriter);
	         
	        fileWriter.append("</tr>");
	        fileWriter.append("</tbody>");
	        fileWriter.append("</TABLE>");
	        fileWriter.append("</div>");
	        fileWriter.append("</center>");
	        fileWriter.append("</body>");
	        fileWriter.append("</html>");
	        bufferFileWriter.close();
	        
	    }catch(Exception ex)
	    {
	        System.out.println(ex);
	    }

				
	}
	
	
	
	
	
	
	
public static void HTMLTStepsHeading(String TCNO) throws IOException {
		
		try
	    {
	       
	        File file = new File(Constants.reportPath);

	        FileWriter fileWriter = new FileWriter(file,true);

	        BufferedWriter bufferFileWriter  = new BufferedWriter(fileWriter);
	         
	        fileWriter.append("<div id=\""+TCNO+"\" style=display:none >");
	       
	        fileWriter.append("<TABLE ALIGN=Center BORDER=0 WIDTH=\"100%\" CELLPADDING=1 >");
	        fileWriter.append("<tbody><tr bgcolor=#85cd66>");

	        fileWriter.append("<th width=\"30%\" align=left valign=center colspan=4><font color=black face=Arial><small><b>Step Details</b></small></font></th>");
	        fileWriter.append("<th width=\"30%\" align=left valign=center colspan=4><font color=black face=Arial><small><b>Expected Result</b></small></font></th>");
	        fileWriter.append("<th width=\"30%\" align=left valign=center colspan=8><font color=black face=Arial><small><b>Actual Result</b></small></font></th>");
	       
	        fileWriter.append("<th width=\"10%\" align=left valign=center colspan=4><font color=black face=Arial><small><b>Status</b></small></font></th>");
	        fileWriter.append("</tr>");
	        //fileWriter.append("</tbody>");
	        //fileWriter.append("</TABLE>");
	       // fileWriter.append("</div>");
	        bufferFileWriter.close();
	        


	    }catch(Exception ex)
	    {
	        System.out.println(ex);
	    }

				
	}
	
	
	
	
	
	public static void HTMLTCDetails(String TCNO, String TCDesc  ) throws IOException {
				
		try
	    {
	       
	        File file = new File(Constants.reportPath);

	        FileWriter fileWriter = new FileWriter(file,true);

	        BufferedWriter bufferFileWriter  = new BufferedWriter(fileWriter);
	       
	     
            
	        fileWriter.append("<TABLE ALIGN=Center BORDER=0 WIDTH=\"100%\" CELLPADDING=1>");
	        fileWriter.append("<tbody><tr bgcolor=#daaaaa>");

	        fileWriter.append("<th width=\"15%\" align=left valign=center colspan=4><font color=black face=Arial><small><b>TC ID:<a href=\"#\" onClick=\"scr_LaunchApplication(\'"+TCNO+"\')\">" + TCNO +"</a></b></small></font></th>");
	        
	        fileWriter.append("<th width=\"25%\" align=left valign=center colspan=6><font color=black face=Arial><small><b>TC Description: " + TCDesc +"</b></small></font></th>");
	        fileWriter.append("<th width=\"20%\" align=left valign=center colspan=4><font color=black face=Arial><small><b>TC Duration: </b></small></font></th>");
	        fileWriter.append("<th width=\"15%\" align=left valign=center colspan=4><font color=black face=Arial><small><b>TC Status: </b></small></font></th>");
	        fileWriter.append("</tbody>");
	        fileWriter.append("</TABLE>");
	        bufferFileWriter.close();
	        

	    }catch(Exception ex)
	    {
	        System.out.println(ex);
	    }
				
	}
	
	
	
	
	
	public static void HTMLHeader() throws IOException {
		
		try
	    {   
			Date date = new Date();
		  

		    SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");
		    String strDate = sdf.format(date);

			
			
			StringBuilder sb = new StringBuilder();
		    sb.append("<html>");
		    sb.append("<head>");
		    sb.append("<script type=text/javascript>");
	        sb.append("function scr_LaunchApplication(it) {");
	        sb.append("var vis = document.getElementById(it).style.display;");
	        sb.append(" if (vis == \"block\") { document.getElementById(it).style.display = \"none\"; }");
	        sb.append("else { document.getElementById(it).style.display = \"block\"; } }</script></head>");
		 
		    sb.append("<title>");
		    sb.append("</title>");
		    //sb.append("</head>");
		    sb.append("<body bgcolor=\"#ededff\"><center>");
		    sb.append("<h1><font color=\"#638b06\" face=\"Arial\">Automation Result Log</font></h1><br>");
		    sb.append("<table width=\"40%\" align=\"Center\" border=\"0\" cellpadding=\"0\">");
		    sb.append("<tbody><tr bgcolor=\"#aababa\">");
		    sb.append("<td align=\"left\" valign=\"top\"><font color=\"black\" face=\"Arial\"><small><b>Total Test Cases Execution: </b></small></font></td>");
		    sb.append("</tr>");
		    sb.append("</tbody><table width=\"40%\" align=\"Center\" border=\"0\" cellpadding=\"0\">");
		    sb.append("<tr bgcolor=\"#aababa\">");
		    sb.append("<td align=\"left\" valign=\"top\"><font color=\"black\" face=\"Arial\"><small><b>Total Test Cases Passed: </b></small></font></td>");
		    sb.append("</tr>");
		    sb.append("<tr bgcolor=\"#aababa\">");
		    sb.append("<td align=\"left\" valign=\"top\"><font color=\"black\" face=\"Arial\"><small><b>Total Test Cases Failed: </b></small></font></td>");
		    sb.append("</tr>");
		    sb.append("<tr bgcolor=\"#aababa\">");
		    sb.append("<td align=\"left\" valign=\"top\"><font color=\"black\" face=\"Arial\"><small><b>Execution Start Time: "+strDate+ "</b></small></font></td>");
		    sb.append("</tr>");
		    sb.append("<tr bgcolor=\"#aababa\">");
		    sb.append("<td align=\"left\" valign=\"top\"><font color=\"black\" face=\"Arial\"><small><b>Execution End Time: </b></small></font></td>");
		    sb.append("</tr>");
		    sb.append("<tr bgcolor=\"#aababa\">");
		    sb.append("<td align=\"left\" valign=\"top\"><font color=\"black\" face=\"Arial\"><small><b>Total Execution Time: </b></small></font></td>");
		    sb.append("</tr>");
		    sb.append("<tr>");
		    sb.append("</tr>");
		    sb.append("<tr>");
		    sb.append("</tr>");
		    sb.append("</tr>");
		    sb.append("<tr>");
		    sb.append("</tr>");
		    sb.append("<tr>");
		    sb.append("</tr>");
		    //sb.append("</tbody>");
		    sb.append("</table>");
		    sb.append("<table width=\"40%\" align=\"Center\" border=\"0\" cellpadding=\"0\">");
		    sb.append("<tr>");
		    sb.append("</tr>");
		    sb.append("</table>");
		    
		   // sb.append("</body>");
		    //sb.append("</html>");
		    FileWriter fstream = new FileWriter(Constants.reportPath);
		    BufferedWriter out = new BufferedWriter(fstream);
		    out.write(sb.toString());
		    out.close();
	    }

	        
	       catch(Exception ex)
	    {
	        System.out.println(ex);
	    }
	
	}

	public static void EmptyResultFile() {
		try
	    {
		FileOutputStream writer = new FileOutputStream(Constants.reportPath);
		writer.write(("").getBytes());
		writer.close();
	    }

        
	       catch(Exception ex)
	    {
	        System.out.println(ex);
	    }
	
	}
		
	
	
	
}